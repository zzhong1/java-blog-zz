package org.finra.automation.crd.junit.pageobjectmodel;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.httpclient.HttpException;
import org.finra.automation.crd.junit.common.RunConfigManager;
import org.finra.automation.crd_automation.common.DownloadClass;
import org.finra.automation.crd_automation.common.NRQGenerator;
import org.finra.automation.crd_automation.common.UploadClass;
import org.finra.automation.crd_automation.common.XMLUtility;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.radautomationcommon.datagen.RandomDataGeneratorExtended;
import org.finra.commonform.datagen.DataGeneratorException;
import org.junit.Assert;

import qc.automation.framework.utilities.Base64EncoderDecoder;

public class FormFiling{
	private RunConfigManager runConfig;
	private String webEFTURL;
	private String downloadlocation="testdata";
	private RandomDataGeneratorExtended dataGen = new RandomDataGeneratorExtended();
	private NRQGenerator nrqGen = new NRQGenerator();
	private String sourceTestDataFilePath;
	private String nrqFilePath;
	private String nrsFilePath;
	private String resultNRQFileName;
	private String submitDate;
	
	private String indvl_pk;
	private String flng_pk;
	private String brnch_ofc_pk;
	
	public void submitU4Initial() throws Throwable{
		String ssn_nb = getRandomSSN();
		nrqGen.generate(sourceTestDataFilePath, resultNRQFileName + ".nrq", ssn_nb, ssn_nb, submitDate);
		filingProcess();
	}
		
	public void submitU4Amendment(String indvl_pk, String ssn_nb) throws Throwable{
		submitU4AmendU5PartialU5Full(indvl_pk, ssn_nb);
	}

	public void submitU5Partial(String indvl_pk, String ssn_nb, String rgltr_cd, String pstn) throws Throwable{
		nrqGen.generate_U5Partial(sourceTestDataFilePath, resultNRQFileName + ".nrq", indvl_pk, ssn_nb, rgltr_cd, pstn, submitDate);
		filingProcess();
	}
	
	public void submitU5Full(String indvl_pk, String ssn_nb) throws Throwable{
		submitU4AmendU5PartialU5Full(indvl_pk, ssn_nb);
	}
		
	public void submitNRFInitial() throws Throwable{
		String ssn_nb = getRandomSSN();
		String barcode = getRandomBarcode();
		nrqGen.generate_NRF_initial(sourceTestDataFilePath, resultNRQFileName + ".nrq", ssn_nb, barcode, submitDate);
		filingProcess();
	}
	
	public void submitNRFAmendment(String indvl_pk, String ssn_nb) throws Throwable{
		String barcode = getRandomBarcode();
		nrqGen.generate_NRF_amend(sourceTestDataFilePath, resultNRQFileName + ".nrq", indvl_pk, ssn_nb, barcode, submitDate);
		filingProcess();
	}
	
	public void submitBRInitial(String supervisor, String associate, String org_pk) throws Throwable{
		nrqGen.generate_BR(sourceTestDataFilePath, resultNRQFileName + ".nrq", supervisor, associate, org_pk, submitDate);
		filingProcess();
	}
	
	public void submitBRAmendment(String brnch_ofc_pk, String org_pk, String SEC_Reg) throws Throwable{
		nrqGen.generate_BR_amend(sourceTestDataFilePath, resultNRQFileName + ".nrq", brnch_ofc_pk, org_pk, SEC_Reg, submitDate);
		filingProcess();
	}
	
	public FormFiling(String testDataFilePath) throws DataGeneratorException{
		if(testDataFilePath != null){
			if(testDataFilePath.startsWith("testdata"))
				this.sourceTestDataFilePath = testDataFilePath;
			else{
				String fileName = testDataFilePath.toUpperCase();
				this.sourceTestDataFilePath = "testdata/template_NRQ/default/" + fileName + ".nrq";
			}
		}
		
		createNRQResultFilePath();
	}
	
	public String getRandomSSN() throws DataGeneratorException{
		return dataGen.ssn();
	}

	public String getRandomBarcode(){
		return dataGen.number(10);
	}

	public void setSubmitDateAsCurrentDate(){
		this.submitDate = dataGen.currentDate();
	}

	public void setSubmitDate(int offset){
		this.submitDate = dataGen.currentDate(offset);
	}
	
	public void setSubmitDate(String format, int offset){
		this.submitDate = dataGen.currentDate(format, offset);
	}
	
	private void submitU4AmendU5PartialU5Full(String indvl_pk, String ssn) throws Throwable{
		nrqGen.generate(sourceTestDataFilePath, resultNRQFileName + ".nrq", indvl_pk, ssn, submitDate);
		filingProcess();
	}
	
	private void createNRQResultFilePath(){
		String[] source = sourceTestDataFilePath.split("/");
		String fileName = source[source.length-1].replace(".nrq", "").trim();
		
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		resultNRQFileName = fileName + "_" + sdf.format(now);
		nrqFilePath ="testdata/result_NRQ/"+resultNRQFileName+".nrq";
	}
	
	private void filingProcess() throws Exception{
		uploadAndDownloadThroughWebEFT("MONITOR");
		verifyNRSFiling();
		removeNRQResultFile();
	}
	
	private void uploadAndDownloadThroughWebEFT(String userPrefix) throws IOException, InterruptedException{
		String pwd = null;
		runConfig = BaseTest.getRunConfig();
		webEFTURL = runConfig.getApplicationUrl("FSGApplication.url");
		String userName = runConfig.getUserPrefix(userPrefix + ".username");
		String password = runConfig.getUserPrefix(userPrefix + ".password");  
		String s = runConfig.isPasswordEncoded("passwordsEncoded");
		boolean encoded = (s != null && s.equals("true"));
		
		if(encoded)
			 pwd = Base64EncoderDecoder.decodeString(password);

		uploadNRQThroughWebEFT(userName, pwd);
		downloadThroughWebEFT(userName, pwd);
	}
	
	private void uploadNRQThroughWebEFT(String eftUserName, String eftPwd) throws IOException{
		File readyToUploadFile = new File(nrqFilePath);
		URL fsgURL = new URL(webEFTURL);
		
		if(nrqFilePath == null)
			System.out.println("No new NRQ is generated. Please create a new NRQ first.");
		else{
			new UploadClass(fsgURL, readyToUploadFile, eftUserName, eftPwd);
		}
	}
	
	private void downloadThroughWebEFT(String eftUserName, String eftPwd) throws HttpException, IOException, InterruptedException{
		String linkName = resultNRQFileName + ".nrs";
		String downloadURL = webEFTURL + "archive/" + linkName;
		URL fsgURL = new URL(downloadURL);
		new DownloadClass(fsgURL, eftUserName, eftPwd , downloadlocation);
		this.nrsFilePath = downloadlocation + "/" + resultNRQFileName + ".nrs";
	}
	
	private void verifyNRSFiling() throws Exception {
		String status = null;
		String flngpk = null;
		String crdNumber = null;
		String brnchPK = null;
		XMLUtility xmlUtil = new XMLUtility(nrsFilePath);
		status = xmlUtil.getNodeAtttribute("CRDFormResults", "status");
		checkStatus(xmlUtil, status);
		
		//U4-INITIAL, U4-AMEND, NRF-INITIA, NRF-AMEND, U5-PARTIAL, U5-FULL, U5-AMEND 
		if(!xmlUtil.getNodeAtttribute("CRDFormResults", "individualCRDNumber").equals("")){
			crdNumber = xmlUtil.getNodeAtttribute("CRDFormResults", "individualCRDNumber");
			flngpk= xmlUtil.getNodeAtttribute("CRDFormResults", "FilingPK");
			if(crdNumber!=null && !crdNumber.equals("0") && !crdNumber.equals("")){
				this.indvl_pk = crdNumber;
				this.flng_pk = flngpk;
				System.out.println("INDVL_PK = " + crdNumber);
				System.out.println("FLNG_PK = " + flngpk);
				}
		}
		// BR_INITIAL, BR_AMEND
		else if(!xmlUtil.getNodeAtttribute("CRDFormResults", "brnchPK").equals("")){
			brnchPK = xmlUtil.getNodeAtttribute("CRDFormResults", "brnchPK");
			flngpk = xmlUtil.getNodeAtttribute("CRDFormResults", "FilingPK");
			if(brnchPK!=null && !brnchPK.equals("0") && !brnchPK.equals("")){
				this.brnch_ofc_pk = brnchPK;
				this.flng_pk = flngpk;
				System.out.println("BRNCH_OFC_PK = " + brnchPK);
				System.out.println("FLNG_PK = " + flngpk);
			}
		}
		else
			throw new Exception("This filing did not go through in FSG.");
	}
	
	private void checkStatus(XMLUtility xmlUtil, String status) throws IOException {
		if(status.equalsIgnoreCase("Failed")){
			String errorMsg = xmlUtil.getNodeAtttribute("CRDFormError", "errorMessage");
			Assert.assertTrue("NRS file shows the error message : " + errorMsg, errorMsg == null);
		}
	}

	private void removeNRQResultFile() throws IOException{
		File nrqFile = new File(nrqFilePath);
		File nrsFile = new File(nrsFilePath);

		if(nrqFile.exists() && nrsFile.exists()){
			nrqFile.delete();
			nrsFile.delete();
			if(!nrqFile.exists() && !nrsFile.exists())
				System.out.println("Both NRQ and NRS filings are removed");
			else
				System.out.println("Both NRQ and NRS filings are failed to remove");
		}
		else{
			System.out.println("Both NRQ or NRS filings are not existed");
		}
	}

	
	public String getIndvl_pk() {
		return indvl_pk;
	}

	public void setIndvl_pk(String indvl_pk) {
		this.indvl_pk = indvl_pk;
	}

	public String getFlng_pk() {
		return flng_pk;
	}

	public void setFlng_pk(String flng_pk) {
		this.flng_pk = flng_pk;
	}

	public String getBrnch_ofc_pk() {
		return brnch_ofc_pk;
	}

	public void setBrnch_ofc_pk(String brnch_ofc_pk) {
		this.brnch_ofc_pk = brnch_ofc_pk;
	}
}
