/**
 * $Id: CompositeDataComparator.java,v 1.0, 2012-01-03 22:58:15Z, Koo Daniel $
 * Copyright 2011 Financial Industry Regulatory Authority.
 * All Rights Reserved.
 */
package org.finra.automation.crd.junit.common;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.Assert;
import junit.framework.AssertionFailedError;

/**
 * Utility class to perform comparison of lists and maps
 * 
 * @author Daniel Koo
 * @version $Revision: 1$ $Date: 1/3/12 5:58:15 PM EST$
 */
public class CompositeDataComparator {

	public List<String> errorList;
	public boolean accumulateErrors;

	public CompositeDataComparator() {
		accumulateErrors = false;
	}

	public CompositeDataComparator(boolean accumulateErrors) {
		super();
		this.accumulateErrors = accumulateErrors;
		errorList = new ArrayList<String>();
	}

	public void compareMap(String title, String element, Map expComp,
			Map actualComp) {
		String prefix = getPrefix(title, element);
		Set keySet = expComp.keySet();

		for (Iterator iter = keySet.iterator(); iter.hasNext();) {
			String obj = (String) iter.next();

			Object eValue = expComp.get(obj);

			if (!actualComp.containsKey(obj)) {
				reportError(prefix + " Couldn't find Element [" + obj
						+ "] in Actual Data");

			}
			Object aValue = actualComp.get(obj);

			assessAndCompare(prefix, obj, eValue, aValue);
		}
	}

	public List<String> getErrorList() {
		return errorList;
	}

	private void reportError(String error) {
		if (!accumulateErrors)
			throw new AssertionFailedError(error);
		else
			errorList.add(error);

	}

	private String getPrefix(String title, String element) {
		return (element == null && !"".equals(element)) ? title : title + "-> "
				+ element + " : ";
	}

	public void compareList(String title, String element, List expList,
			List actualList) {
		String prefix = getPrefix(title, element);

		if (compareSize(prefix, expList, actualList)) {

			for (int i = 0; i < expList.size(); i++) {
				Object expected = expList.get(i);
				Object actual = actualList.get(i);

				assessAndCompare(prefix + "[position : " + (i + 1) + "]", null,
						expected, actual);
			}
		}
	}

	// FIXME: This recursive step should not automatically throw assertions.
	private void assessAndCompare(String title, String element,
			Object expected, Object actual) {
		String prefix = getPrefix(title, element);

		if (expected == null && actual == null) {
			return;
		} else if (expected == null || actual == null) {
			if ("".equals(expected) || "".equals(actual))
				return;
			reportError(prefix + " didn't match. Expected Value[" + expected
					+ "] and Actual Value [" + actual + "].");
		} else if (expected instanceof Map) {
			compareMap(title, element, (Map) expected, (Map) actual);
		} else if (expected instanceof List) {
			compareList(title, element, (List) expected, (List) actual);
		} else if (expected instanceof Timestamp) {
			Timestamp expTimestamp = (Timestamp) expected;
			if (!(actual instanceof Timestamp))
				reportError(prefix + " Expected value [" + expTimestamp
						+ "] and Actual Value [" + actual + "].");

			else
				compareObject(prefix, expTimestamp, (Timestamp) actual);
		} else if (expected instanceof String[]) {
			String e[] = (String[]) expected;
			String a[] = (String[]) actual;

			if (e.length != a.length)
				reportError(prefix
						+ " Length of string array didn't match. Expected ["
						+ e.length + "] and Actual [" + a.length + "].");

			for (int i = 0; i < e.length; i++) {
				try {
					Double expD = Double.valueOf((String) e[i]);
					Double actD = Double.valueOf((String) a[i]);

					compareObject(prefix, expD, actD);
				} catch (NumberFormatException ignore) {
					compareObject(prefix, e[i], a[i]);
				}
			}
		} else if (expected instanceof String) {

			try {
				Double expD = Double.valueOf((String) expected);
				Double actD = Double.valueOf((String) actual);

				compareObject(prefix, expD, actD);
			} catch (NumberFormatException ignore) {
				compareObject(prefix, expected, actual);
			}
		} else if (expected instanceof Boolean && actual instanceof String) {

			try {

				String actualString = Boolean.FALSE.toString();
				if ("y".equalsIgnoreCase((String) actual)
						|| "true".equalsIgnoreCase((String) actual)) {
					actualString = Boolean.TRUE.toString();
				}

				compareObject(prefix, expected.toString(), actualString);
			} catch (NumberFormatException ignore) {
				compareObject(prefix, expected, actual);
			}
		} else if (expected instanceof Integer && actual instanceof BigDecimal) {
			BigDecimal expectedBigDecimal = new BigDecimal((Integer) expected);
			compareObject(prefix, expectedBigDecimal, actual);

		}
	}

	private void compareObject(String prefix, Object expected, Object actual) {
		if (!expected.equals(actual)) {
			reportError(prefix + " didn't match. Expected Value[" + expected
					+ "] and Actual Value [" + actual + "].");
		}
	}

	private boolean compareSize(String comp, List expSessions, List actualSessions) {
		boolean equal = true;
		if (expSessions.size() != actualSessions.size()) {
			reportError(comp + "didn't match; Expected List size: "
					+ expSessions.size() + " -- Actual List size: "
					+ actualSessions.size());
			equal = false;
		}
		return equal;
	}

	public void printCheckErrorList(List<String> errors) {
		if (errorList != null && !errorList.isEmpty()) {
			String errorString = "";
			for (int x = 0; x < errors.size(); x++) {
				errorString += "\n" + errors.get(x);
			}
			Assert.fail(errorString);
		}
	}
}
