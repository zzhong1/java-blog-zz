package org.finra.automation.crd.junit.ui.widgets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.jexl2.parser.JexlNode.Literal;
import org.apache.log4j.Logger;
import org.finra.automation.crd_automation.ui.widget.CRDRadioButton;
import org.finra.automation.crd_automation.ui.widget.CheckBoxImage;
import org.finra.automation.crd_automation.ui.widget.YesNoRadioButtonGroup;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.jtaf.ewd.session.SessionManager;
import org.finra.jtaf.ewd.widget.IElement;
import org.finra.jtaf.ewd.widget.WidgetException;
import org.finra.jtaf.ewd.widget.element.Element;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.rules.ErrorCollector;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/*
 * This ReadOnlyPageWidget class is going to verify Form PF read-only contents against with the data in the database
 * by parameters are given
 */
public class PFReadOnlyPageWidget extends Element implements IElement
{	
	 final  static GUIProperties gp = new GUIProperties("pfrd/pf.gui.properties");
	 private static final Logger logger = Logger.getLogger(PFReadOnlyPageWidget.class);

	@Rule
	ErrorCollector errCollector=new ErrorCollector();
	
    public PFReadOnlyPageWidget(String locator) throws WidgetException {
        super(locator);
    }

/*
 * Verify read-only text on UI based on xpath and xpath Param are given 
 * and compare the read-only text with the text of the columnName in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * $param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyDataWithUI(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam)	throws Exception {
	boolean found = false;
	String tesxtResult = null;
	String dbResult = resultSet.get(0).get(columnName).toString().trim();

		Element e = new Element(gp.getPropertyValue(xpath, xpathParam));
		if(e.isElementPresent())
		{
			tesxtResult = e.getText().toString().trim().replace(" ","").replace("$","");
			found = tesxtResult.contains(dbResult.replace(" ","").replace("\r", "").replace("\n", ""));
			logger.info("Verified " + columnName + " matches with " +e.getText());
		}
		else if(dbResult.equalsIgnoreCase(""))
			found = true;

		Assert.assertTrue("Mismatch! The text result of " + columnName + " from UI is " + tesxtResult +  " but from DB is " + dbResult , found);

}

/*
 * Verify read-only text on UI based on xpath and xpath Param are given 
 * and compare the read-only text with the text of the columnName in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * $param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyTdDataWithUI(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam)	throws Exception {
	boolean found = false;
	String tesxtResult = null;
	String dbResult = resultSet.get(0).get(columnName).toString().trim();

		Element e = new Element(gp.getPropertyValue(xpath, xpathParam));
		if(e.isElementPresent())
		{
			tesxtResult = e.getText().toString().trim().replace(" ","").replace("$","");
			found = tesxtResult.contains(dbResult.replace(" ","").replace("\r", "").replace("\n", ""));
			logger.info("Verified " + columnName + " matches with " +e.getText());
		}
		else if(dbResult.equalsIgnoreCase(""))
			found = true;

		Assert.assertTrue("Mismatch! The text result of " + columnName + " from UI is " + tesxtResult +  " but from DB is " + dbResult , found);
	}

/*
 * 
 */
public void verifyTdDataWithUI(String dbColumn, String dbData, String xpath, String... xpathParam)	throws Exception {
	boolean found = false;
	String tesxtResult = null;

		Element e = new Element(gp.getPropertyValue(xpath, xpathParam));
		if(e.isElementPresent())
		{
			tesxtResult = e.getText().toString().trim().replace(" ","").replace("$","").replace("%", "");
			found = tesxtResult.contains(dbData.replace(" ","").replace("\r", "").replace("\n", ""));
			logger.info("Verified " + dbData + " matches with " + e.getText());
		}

		Assert.assertTrue("Mismatch! The text result of " + dbColumn + " from UI is " + tesxtResult +  " but from DB is " +  dbData, found);
	}


/*
 * Verify either Yes or No radio button is selected on UI based on xpath and xpath Param are given
 * and compare it with the FLAG in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * @param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyYesNoButtonGroup(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam) throws Exception {
	String expected=null;
	String resultFromUI = null;
	YesNoRadioButtonGroup yg = new YesNoRadioButtonGroup(gp.getPropertyValue(xpath, xpathParam));
	yg.waitForElementPresent();
	resultFromUI = yg.getValue();
	if (resultFromUI == "No")
		expected = "N";
	
	else if(resultFromUI == "Yes")
		expected = "Y";
	
	else 
		expected ="";
	
	Assert.assertEquals("Mismatch! The Yes/No radio button result from UI is " + expected + " but from DB is " + resultSet.get(0).get(columnName) , expected, resultSet.get(0).get(columnName));
	logger.info("Verified " + resultSet.get(0).get(columnName)+ " matches with " + expected);
}




}