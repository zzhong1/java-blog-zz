package org.finra.automation.crd.junit.common;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelParser {
	private static final String EMPTY = "$EMPTY$";
	
	public static List<Map<String, Object>> parseDataFileExcel(String fileName) throws Exception {
		return ExcelParser.parseDataFileExcel(fileName, null);
	}
	
	public static List<Map<String, Object>> parseDataFileExcel(String fileName, String sheetName) throws Exception {
		File dataFile = new File(fileName);
		List<Map<String, Object>> dataOnSheet = new ArrayList<Map<String, Object>>();
		FileInputStream inStream = null;
		
		try{
			inStream = new FileInputStream(dataFile);
			XSSFWorkbook wb = new XSSFWorkbook(inStream);
			XSSFSheet page = null;
			if(sheetName != null) {
				page = wb.getSheet(sheetName);
			}else {
				page = wb.getSheetAt(0);
			}
			
			String currentColumn = null;
			Row firstRow = null;
			for(int i = 0; i < page.getLastRowNum()+1; i++){
				Row r = page.getRow(i);
				if(i == 0) {
					firstRow = r;
				}else {
					Map<String,Object> rowData = new HashMap<String,Object>();
					List<String> value = new ArrayList<String>();
					for(int j = 0; j < 1; j++){
						Cell c = r.getCell(j);
						if(c != null) {
							if(firstRow.getCell(j) != null) {
								if(j != 0) {
									if(value.size() != 0) {
										rowData.put(currentColumn, value);
									}else {
										rowData.put(currentColumn, null);
									}
									value = new ArrayList<String>();
								}
								currentColumn = r.getCell(j).toString();
							}
							//String val = c.getStringCellValue();
							DataFormatter dataFormatter = new DataFormatter();
							String val = dataFormatter.formatCellValue(r.getCell(j+1));
							
							if(val != null){
								if (val.trim().equals("")){
									val = null;
								}
								else if (val.equals(EMPTY)){
									val = "";
								}
							}
							value.add(val);
						}
					}
					rowData.put(currentColumn, value);
					dataOnSheet.add(rowData);
				}
			}
		}catch(Exception e){
			throw e;
		}
		
		return dataOnSheet;
	}
}
