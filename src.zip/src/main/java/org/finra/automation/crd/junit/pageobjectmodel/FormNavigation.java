package org.finra.automation.crd.junit.pageobjectmodel;

import java.util.HashMap;
import java.util.Map;

import org.finra.automation.crd_automation.ui.widget.CRDSiteMap;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.SearchPanel;
import org.finra.automation.crd_automation.ui.widget.TopNavigation;
import org.finra.automation.crd_automation.ui.widget.TopNavigation.MenuBar;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.FormTable;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.jtaf.ewd.widget.IHyperLink;
import org.finra.jtaf.ewd.widget.element.Element;
import org.finra.jtaf.ewd.widget.element.html.HyperLink;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import qc.automation.framework.widget.WidgetException;

/*
 * This FormFilingNavigation class is used for landing different form filing pages. 
 * 
 */
/**
 * @author KoshyA
 *
 */
public class FormNavigation {

	private TopNavigation tn = new TopNavigation();
	private LeftNavigation leftNav = new LeftNavigation();
	private MenuBar mb;
	private FormTable ft = new FormTable();
	private CRDSiteMap siteMap = new CRDSiteMap();
	
	/*
	 * Go to CRD Forms 
	 * @param form Type could be Form U4, U5, U6, BR, BD, BDW, or NRF
	 */
	public void goToCRDForm(String formType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("Forms");
		mb = tn.getSubMenuBar();
		mb.selectItem(formType);
	}
	
	/*
	 * Go to IARD Forms 
	 * @param form Type could be Form ADV, ADV-W, or ADV-E
	 */
	public void goToIARDForm(String formType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("IARD Main");
		mb.selectItem("Forms");
		mb = tn.getSubMenuBar();
		mb.selectItem(formType);
	}
	
	/*
	 * Go to PFRD Forms 
	 * @param form Type could be Form PF
	 */
	public void goToPFRDPage(String site, String pageLink) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("PFRD Main");
		siteMap.clickLink(site, pageLink);
	}	
	
	/*
	 * Go to create a Form U4
	 * @param filing Type could be Initial, Amendment, Concurrence, Page 2 for BD Schedule A/B, Page 2 Amendment for BD Schedule A/B,
	 * Dual Registration, Relicense All Registrations or transfer within 30 days, Relicense Only CRD Registrations or transfer within 30 Days
	 * , or Relicense Only IA Registrations or transfer within 30 Days
	 */
	public void goToFormU4(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U4");
		ft.openPageInSameBrowser(filingType);
	}
	
	/*
	 * Go to create a Form U5
	 * @param filingType could be Full, Partial, or Amendment
	 */	
	public void goToFormU5(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U5");
		ft.openPageInSameBrowser(filingType);
	}
	
	/*
	 * Go to create a  Form U6
	 * @param filingType could be CRD Individual, Disclosure Only Individual, CRD/IARD Organization, or Disclosure Only Organization
	 */
	public void goToFormU6(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U6");
		ft.openPageInSameBrowser(filingType);
	}
	
	/*
	 * Go to create a  Form BR
	 * @param filingType could be Initial, Amendment, or Closing/Withdrawal
	 */
	public void goToFormBR(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BR");
		ft.openPageInSameBrowser(filingType);
	}

	/*
	 * Go to create a  Form BD 
	 * @param filingType could be Initial or Amendment
	 */
	public void goToFormBD(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BD");
		ft.openPageInSameBrowser(filingType);
	}
	
	/*
	 * Go to create a  Form BDW
	 * @param filingType could be Full or Partial 
	 */
	public void goToFormBDW(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BDW");
		ft.openPageInSameBrowser(filingType);
	}
	
	/*
	 * Go to create a  Form NRF 
	 * @param filingType could be Initial, Amendment, or Bulk Termination
	 */
	public void goToFormNRF(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form NRF");
		ft.openPageInSameBrowser(filingType);
	}
	
	/*
	 * Go to create a  Form ADV 
	 */
	public void goToFormADV() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToIARDForm("Form ADV");
	}
	
	/*
	 * Go to create a  Form ADV-W 
	 */
	public void goToFormADVW() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToIARDForm("Form ADV-W");
	}
	
	/*
	 * Go to create a  Form ADV-E 
	 */
	public void goToFormADVE() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToIARDForm("Form ADV-E");
	}
	
	/*
	 * Go to create a  Form FP 
	 */
	public void goToFormFP() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("FPRD Main");
	}
	
	/*
	 * Go to Pending U4 Filings page
	 */
	public void goToPendingU4Filings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U4");
		leftNav.selectItem("Pending U4 Filings");
	}
	
	/*
	 * Go to Pending U5 Filings page
	 */
	public void goToPendingU5Filings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U5");
		leftNav.selectItem("Pending U5 Filings");
	}	

	/*
	 * Go to Pending U6 Filings page
	 */
	public void goToPendingU6Filings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U6");
		leftNav.selectItem("Pending U6 Filings");
	}

	/*
	 * Go to Pending BR Filings page
	 */
	public void goToPendingBRFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BR");
		leftNav.selectItem("Pending BR Filings");
	}
	
	/*
	 * Go to Pending BD Filings page
	 */
	public void goToPendingBDFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BD");
		leftNav.selectItem("Pending BD Filings");
	}	
	
	/*
	 * Go to Pending BDW Filings page
	 */
	public void goToPendingBDWFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BDW");
		leftNav.selectItem("Pending BDW Filings");
	}
	
	/*
	 * Go to Pending NRF Filings page
	 */
	public void goToPendingNRFFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form NRF");
		leftNav.selectItem("Pending NRF Filings");
	}

	/*
	 * Go to Historical U4 Filings page
	 */
	public void goToHistoricalU4Filings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U4");
		leftNav.selectItem("Historical U4 Filings");
	}
	
	/*
	 * Go to Historical U5 Filings page
	 */
	public void goToHistoricalU5Filings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U5");
		leftNav.selectItem("Historical U5 Filings");
	}
	
	/*
	 * Go to Historical U6 Filings page
	 */
	public void goToHistoricalU6Filings(String filingType) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form U6");
		leftNav.selectItem("Historical U6 Filings");
		ft.openPageInSameBrowser(filingType);
	}
	
	public void goToCRDIndvl() throws Exception{
		 GUIProperties gp = new GUIProperties("crd/gui.properties");

			IHyperLink e4 = new HyperLink(gp.getPropertyValue(
					"crd.sitemap.sitemapsite", "CRD Individual"));
			e4.click();
			
		
	}
	/*
	 * Go to Historical BR Filings page
	 */
	public void goToHistoricalBRFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BR");
		leftNav.selectItem("Historical BR Filings");
	}	

	/*
	 * Go to Historical BD Filings page
	 */
	public void goToHistoricalBDFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BD");
		leftNav.selectItem("Historical BD Filings");
	}	
	
	/*
	 * Go to Historical BDW Filings page
	 */
	public void goToHistoricalBDWFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form BDW");
		leftNav.selectItem("Historical BDW Filings");
	}
	
	/*
	 * Go to Historical NRF Filings page
	 */
	public void goToHistoricalNRFFilings() throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException{
		goToCRDForm("Form NRF");
		leftNav.selectItem("Historical NRF Filings");
	}
	
	/*
	 * Go to Filing page when the flng_pk is known
	 */
	public void goToFilingPage(String flng_pk, String pageName) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException, InterruptedException{
		ft.openPageInSameBrowser(flng_pk);
		leftNav.selectItem(pageName);
	}
	/*
	 * Go to VII and do a simple Search
	 */
	public void goToVII(String IndvlID) throws WidgetException, org.finra.jtaf.ewd.widget.WidgetException, InterruptedException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("Individual");
		mb = tn.getSubMenuBar();
		mb.selectItem("View Individual");
		FormMainContent fmc = new FormMainContent();
		fmc.waitForPageLoading();
		
		SearchPanel sp = new SearchPanel();
		sp.selectTab("Simple Search");
		
		Map<String, String> searchCriteriaMap =  new HashMap<String,String>();
		searchCriteriaMap.put("Short Text", "249");
		
		if(searchCriteriaMap != null){
			sp.enterSearchCriteriaData(searchCriteriaMap);
			sp.clickSearchButton();
		}
	}
	
	
	
	/*
	 * go to FPRD in Firm Gateway
	 */
	public void goToFirmGatewayFPRD() throws org.finra.jtaf.ewd.widget.WidgetException{
		Element base = new Element("/");
		WebDriver driver = base.getGUIDriver().getWrappedDriver();
		int maxTry = 10;
		int countTry = 0;
		boolean failed = true;
		while (failed && countTry < maxTry) {
			try {
			WebElement link =driver.findElement(By.linkText("FPRD"));
			link.click();
			failed = false;
			}catch(Exception e ){
			//do nothing
			}
			
		}
		driver.switchTo().frame("fprdWorkspacei");

	}
	/*
	 * go to FPRD/View Fingerprint in Firm Gate Way
	 */
	public void goToFirmGatewayFPRD_fpCard() throws org.finra.jtaf.ewd.widget.WidgetException{
		goToFirmGatewayFPRD();
		Element base = new Element("/");
		WebDriver driver = base.getGUIDriver().getWrappedDriver();
		WebElement link = driver.findElement(By.linkText("View Fingerprints"));
		link.click();
	}
	
	/*
	 * go to FPRD/View Fingerprint in Firm Gate Way
	 */
	public void goToFirmGatewayFPRD_SDEvents() throws org.finra.jtaf.ewd.widget.WidgetException{
		goToFirmGatewayFPRD();
		Element base = new Element("/");
		WebDriver driver = base.getGUIDriver().getWrappedDriver();
		WebElement link = driver.findElement(By.linkText("Statutory Disqualification Events"));
		link.click();
	}
	
	/*
	 * go to Accounting Page
	 */
	public void goToAccountingPage() throws org.finra.jtaf.ewd.widget.WidgetException, WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("Accounting");
	}
	/*
	 * go to Org page
	 */
	public void goToOrganizationPage() throws org.finra.jtaf.ewd.widget.WidgetException, WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("Organization");
	}
	/*
	 * go to Individual page
	 */
	public void goToIndividualPage() throws org.finra.jtaf.ewd.widget.WidgetException, WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("Individual");
	}
	
	/*
	 * go to Reports
	 */
	public void goToReports() throws org.finra.jtaf.ewd.widget.WidgetException, WidgetException{
		mb = tn.getFinraPrimaryMenuBar();
		mb.selectItem("Reports");
	}
}
