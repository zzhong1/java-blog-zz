package org.finra.automation.crd.junit.pageobjectmodel;

import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.jtaf.ewd.widget.IElement;
import org.finra.jtaf.ewd.widget.element.Element;

public class CommonControls extends Element implements IElement {
	public CommonControls(String locator) {
		super(locator);		
	}

	final  static GUIProperties GUI = new GUIProperties("crd/gui.properties");
	
	public String getTitle(String xpath) throws Exception {
		Element e = new Element(xpath);
		if(e.isElementPresent())
		{
			return e.getText().toString();
		}
		return null;
	}

	
	
	
}
