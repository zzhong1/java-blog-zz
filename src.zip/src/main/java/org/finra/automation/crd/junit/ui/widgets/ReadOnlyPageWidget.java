package org.finra.automation.crd.junit.ui.widgets;

import java.util.ArrayList;
import org.finra.automation.junit.base.BaseTest;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.finra.automation.crd_automation.ui.widget.CRDRadioButton;
import org.finra.automation.crd_automation.ui.widget.CheckBoxImage;
import org.finra.automation.crd_automation.ui.widget.YesNoRadioButtonGroup;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.jtaf.ewd.widget.IElement;
import org.finra.jtaf.ewd.widget.WidgetException;
import org.finra.jtaf.ewd.widget.element.Element;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.rules.ErrorCollector;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/*
 * This ReadOnlyPageWidget class is going to verify read-only contents against with the data in the database
 * by parameters are given
 */
public class ReadOnlyPageWidget extends Element implements IElement
{	
	 final  static GUIProperties gp = new GUIProperties("crd/gui.properties");
	 //private static final Logger logger = Logger.getLogger(ReadOnlyPageWidget.class);

		
    public ReadOnlyPageWidget(String locator) throws WidgetException {
        super(locator);
    }

/*
 * Verify read-only text on UI based on xpath and xpath Param are given 
 * and compare the read-only text with the text of the columnName in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * $param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyDataWithUI(List<Map<String, String>> resultSet,	String columnName, String xpath, String... xpathParam)	throws Exception {
	boolean found = false;
	String tesxtResult = null;
	String dbResult = resultSet.get(0).get(columnName).toString().trim();

		Element e = new Element(gp.getPropertyValue(xpath, xpathParam));
		if(e.isElementPresent())
		{
			tesxtResult = e.getText().toString().trim().replace(" ","").replace("$","");
			found = tesxtResult.contains(dbResult.replace(" ","").replace("\r", "").replace("\n", ""));
			BaseTest.getLogger().info("Verified " + columnName + " matches with " +e.getText());
		}
		else if(dbResult.equalsIgnoreCase(""))
			found = true;

		Assert.assertTrue("Mismatch! The text result of " + columnName + " from UI is " + tesxtResult +  " but from DB is " + dbResult , found);


}

/*
 * Verify any check box result on UI based on xpath and xpath Param are given
 * and compare it with the result of the FLAG in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * @param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyCheckBoxFlag(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam) throws Exception {
	boolean found=false;
	String checkboxAtt = null;
	
	CheckBoxImage  cb = new CheckBoxImage (gp.getPropertyValue(xpath, xpathParam));
	cb.waitForElementPresent();
	checkboxAtt = cb.getImageAttribute();
	if(checkboxAtt.equalsIgnoreCase("check") && resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase("Y"))
	{
		found=true;
		BaseTest.getLogger().info( "Verified " + columnName + " matches with " +cb.getImageAttribute().toString());
	}
	else if(checkboxAtt.equalsIgnoreCase("uncheck") && resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase("N")
			|| checkboxAtt.equalsIgnoreCase("uncheck") && resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase(""))
	{
		found=true;
		BaseTest.getLogger().info( "Verified " + columnName + " matches with " +cb.getImageAttribute().toString());
	}
	
	Assert.assertTrue("Mismatch! The check box result of " + columnName + " from UI is " + checkboxAtt +  " but from DB is " + resultSet.get(0).get(columnName).toString().trim() , found);
}

/*
 * Verify any check box result on UI based on xpath and xpath Param are given
 * and compare it with the selected NAME in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * @param xpath the name of the xpath to find these web elements on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyCheckBoxItem(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam) throws Exception {
	List<String> dbList = new ArrayList<String>();
	List<String> uiList = new ArrayList<String>();
	
	if(resultSet.size()>0){
		for(Map<String,String> map: resultSet){
			dbList.add(map.get(columnName));
		}	
	}else
		dbList = null;

	try{
		List<WebElement> checkBoxItemList =  getGUIDriver().getWrappedDriver().findElements(By.xpath(gp.getPropertyValue(xpath, xpathParam)));
		if(checkBoxItemList.size() > 0){
			for(WebElement elem : checkBoxItemList){
				uiList.add(elem.getText());
			}
		}else
			uiList = null;
	}
	catch(WidgetException e){
		uiList = null;
	}
		
	Assert.assertTrue("Mismatch! The check box item lists from UI and DB are mismatched! " , uiList.equals(dbList));
	
}

/*
 * Verify any radio button result on UI based on xpath and xpath Param are given
 * and compare it with the result of the FLAG in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * @param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyRadioButtonGroup(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam) throws Exception {
	boolean found=false;
	CRDRadioButton  cb = new CRDRadioButton (gp.getPropertyValue(xpath, xpathParam));
	if(cb.isElementPresent()){
		if(cb.getImageAttribute().equalsIgnoreCase("check") && resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase("Y")){
			found=true;
			BaseTest.getLogger().info( "Verified " + columnName + " matches with " +cb.getImageAttribute().toString());
		}
		else if(cb.getImageAttribute().equalsIgnoreCase("uncheck") && resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase("N")){
			found=true;	
			BaseTest.getLogger().info( "Verified " + columnName + " matches with " +cb.getImageAttribute().toString());
		}
	}
	else if(resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase(""))
		found = true;
	
	Assert.assertTrue("Mismatch! The radio button group result of " + columnName , found);
}

/*
 * Verify either exact or explanation radio button is selected on UI based on xpath and xpath Param are given
 * and compare it with the FLAG in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * @param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyExactExplanationRadioButtonGroup (List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam) throws Exception {
	boolean found=false;
	CRDRadioButton exactRadioButton = new CRDRadioButton("("+gp.getPropertyValue(xpath, xpathParam)+")[1]");
	CRDRadioButton explanationRadioButton = new CRDRadioButton("("+gp.getPropertyValue(xpath, xpathParam)+")[2]");
	
	if(exactRadioButton.getImageAttribute().equalsIgnoreCase("check") && resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase("Y") )
	{
		found = true;
		BaseTest.getLogger().info( "Verified " + columnName + " matches with " +exactRadioButton.getImageAttribute());
	}
		
	else if(explanationRadioButton.getImageAttribute().equalsIgnoreCase("check") && resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase("N") )
	{
		found = true;
		BaseTest.getLogger().info( "Verified " + columnName + " matches with " +explanationRadioButton.getImageAttribute());
	}
		
	else if (exactRadioButton.getImageAttribute().equalsIgnoreCase("uncheck") 
			&& explanationRadioButton.getImageAttribute().equalsIgnoreCase("uncheck") 
			&& resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase(""))
		found = true;
	
	Assert.assertTrue("Mismatch! The Exact/Explanation radio button of " + columnName , found);
}

/*
 * Verify optional radio button is selected on UI based on xpath and xpath Param are given
 * and compare it with the option result in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * @param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyOptionalRadioButtonGroup(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam) throws Exception {
	boolean found=false;
	Element  elem = new Element (gp.getPropertyValue(xpath, xpathParam));
	
	if(elem.isElementPresent()){
		if(elem.getText().equalsIgnoreCase(resultSet.get(0).get(columnName).toString().trim())){
			found = true;
			BaseTest.getLogger().info( "Verified " + columnName+ " matches with " +elem.getText());
		}
		else
			Assert.assertTrue("Mismatch! The optional radio button result from UI is " + elem.getText() + " but from DB is " + resultSet.get(0).get(columnName) , found);
	}
	else {
		if(resultSet.get(0).get(columnName).toString().trim().equalsIgnoreCase("") ){
			found = true;
			BaseTest.getLogger().info( "Verified " + columnName+ " matches with null");
		}
		else
			Assert.assertTrue("Mismatch! The optional radio button result from UI is null but from DB is " + resultSet.get(0).get(columnName) , found);
	}
	
}	

/*
 * Verify either Yes or No radio button is selected on UI based on xpath and xpath Param are given
 * and compare it with the FLAG in the database
 * @param resultSet the result set from executing a query. The format of the result set is List<Map>
 * @param columnName the column name in the table
 * @param xpath the name of the xpath to find specific web element on UI
 * @xpath xpathParam the String[] of the parameters to xpath
 */
public void verifyYesNoButtonGroup(List<Map<String, String>> resultSet, String columnName, String xpath, String... xpathParam) throws Exception {
	String expected=null;
	String resultFromUI = null;
	YesNoRadioButtonGroup yg = new YesNoRadioButtonGroup(gp.getPropertyValue(xpath, xpathParam));
	yg.waitForElementPresent();
	resultFromUI = yg.getValue();
	if (resultFromUI == "No")
		expected = "N";
	
	else if(resultFromUI == "Yes")
		expected = "Y";
	
	else 
		expected ="";
	
	Assert.assertEquals("Mismatch! The Yes/No radio button result from UI is " + expected + " but from DB is " + resultSet.get(0).get(columnName) , expected, resultSet.get(0).get(columnName));
	BaseTest.getLogger().info("Verified " + resultSet.get(0).get(columnName)+ " matches with " + expected);
}

}