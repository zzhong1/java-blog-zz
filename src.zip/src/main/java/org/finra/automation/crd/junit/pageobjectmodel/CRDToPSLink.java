package org.finra.automation.crd.junit.pageobjectmodel;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.FormTable;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.junit.Assert;

import qc.automation.framework.widget.element.Element;
import qc.automation.framework.widget.element.html.Button;

public class CRDToPSLink {
	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private LeftNavigation leftNav = new LeftNavigation();
	
	
	public void goCRDToPSLink(String OccuranceID, String DocketID) throws Exception {
		FormTable ft = new FormTable();
		FormMainContent fmc = new FormMainContent();
		
		ft.clickLink(OccuranceID, "1");
		ft.clickLink(DocketID,"1");
		
		fmc.selectCheckBox("TermsOfUse");
		Button b = new Button(gp.getPropertyValue("crd.button", "Search"));
		b.click();
				
		Thread.sleep(6000);
		
		Element e = new Element(gp.getPropertyValue("verify.result.count", ""));
		e.waitForElementPresent();
		String result = e.getText();
		System.out.println("Result of Search as : " + result);
		
		Pattern intsOnly = Pattern.compile("\\d+");
		Matcher makeMatch = intsOnly.matcher(result);
		makeMatch.find();
		String inputInt = makeMatch.group();
		
		int DocumentsNum = Integer.parseInt(inputInt);
		Assert.assertTrue("No document is found, please check your seach criteria!", DocumentsNum > 0);	
	}
	
	
}
