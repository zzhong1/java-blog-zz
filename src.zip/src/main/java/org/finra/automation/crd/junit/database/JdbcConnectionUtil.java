package org.finra.automation.crd.junit.database;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * The behavior of the jdbc connection utility.
 * 
 * @author kood
 *
 */
public interface JdbcConnectionUtil {
	/**
	 * Returns a connection to the DB
	 * @return Connection DB Connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException;

}
