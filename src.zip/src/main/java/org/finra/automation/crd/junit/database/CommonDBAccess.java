package org.finra.automation.crd.junit.database;

import java.io.IOException;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

/**
 * Parent class for all DB Access classes
 * 
 * @author Daniel Koo
 * @version $Revision: 1$ $Date: 1/3/12 5:58:15 PM EST$
 */
public class CommonDBAccess {
	protected void closeResources(Statement s, ResultSet r) {
        closeResources(s, r, true);
    }
	
	protected void closeResources(Statement s, ResultSet r, boolean closeConnection) {
        try {
            if (s != null)
                s.close();
        } catch (SQLException e) {
            //ignore
        }
        
        try {
            if (r != null)
                r.close();
        } catch (SQLException e) {
            //ignore
        }

        if(closeConnection) {
	        ConnectionManager.closeConnections();
        }
    }

	public String readClobColumn(ResultSet rs, String columnName) throws SQLException, IOException {
		Clob clob = rs.getClob(columnName);
		if(clob == null)
			return null;
		long clobLength = clob.length();
		
		return clob.getSubString(1, (int)clobLength);
	}
	
	public String readBlobColumn(ResultSet rs, String columnName) throws SQLException, IOException {
		Blob blob = rs.getBlob(columnName);
		if(blob == null)
			return null;
		
		byte[] bytes = blob.getBytes(1, (int) blob.length());
		
		return new String(bytes);
	}
	
	/**
	 * Executes SQL without any parameters
	 * @param sql
	 * @return Result set in a List of Maps. Map [Key=Column Name, Value=Value object].
	 * @throws Exception
	 */
	public List<Map<String,Object>> executeQueryForList(String sql) throws Exception {
		try {
			SimpleJdbcTemplate sjt = JdbcConnectionUtilImpl.getInstance().getSimpleJdbcTemplate();
			return sjt.queryForList(sql);
		} catch (Exception e) {
			throw new Exception("Error executing query: " + sql, e);
		}
	}
	
	
	/**
	 * Executes SQL with parameters
	 * @param sql SQL query (parameterized with '?')
	 * @param params List of objects as parameters
	 * @return Result set in a List of Maps. Map [Key=Column Name, Value=Value object].
	 * @throws Exception
	 */
	public List<Map<String,Object>> executeQueryForList(String sql, List<Object> params) throws Exception {
		try {
			SimpleJdbcTemplate sjt = JdbcConnectionUtilImpl.getInstance().getSimpleJdbcTemplate();
			return sjt.queryForList(sql, params.toArray());
		} catch (Exception e) {
			throw new Exception("Error executing query: " + sql, e);
		}
	}
	
	/**
	 * Executes SQL updates (insert/delete/update)
	 * @param sql
	 * @throws Exception
	 */
	public void executeQueryForUpdate(String sql) throws Exception {
		try {
			SimpleJdbcTemplate sjt = JdbcConnectionUtilImpl.getInstance().getSimpleJdbcTemplate(true);
			sjt.update(sql);
		} catch (Exception e) {
			throw new Exception("Error executing update: " + sql, e);
		}
	}
	
	/**
	 * Executes SQL updates (insert/delete/update) with parameters
	 * @param sql SQL query (parameterized with '?')
	 * @param params params List of objects as parameters
	 * @throws Exception
	 */
	public void executeQueryForUpdate(String sql, List<Object> params) throws Exception {
		try {
			SimpleJdbcTemplate sjt = JdbcConnectionUtilImpl.getInstance().getSimpleJdbcTemplate(true);
			sjt.update(sql, params.toArray());
		} catch (Exception e) {
			throw new Exception("Error executing update: " + sql, e);
		}
	}
}
