package org.finra.automation.crd.junit.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

import qc.automation.framework.properties.PropertiesReader;

/**
 * The implementation of the JdbcConnectionUtil behavior.
 * 
 * @author harrism
 */
public class JdbcConnectionUtilImpl implements JdbcConnectionUtil {
	private static final String DRIVER   = "database.driver";
	private static final String URL      = "database.url";
	private static final String USER     = "database.username";
	private static final String PASSWORD = "database.password";

	
	private final String url;
	private final String username;
	private final String password;

	
	private JdbcConnectionUtilImpl() {
		this.url               = PropertiesReader.getString(URL);
		this.username          = PropertiesReader.getString(USER);
		this.password          = PropertiesReader.getString(PASSWORD);

		final String className = PropertiesReader.getString(DRIVER);
		try {
			Class.forName(className);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Could not locate database driver", e);
		}
	}
	
	public static JdbcConnectionUtilImpl getInstance() {
		return new JdbcConnectionUtilImpl();
	}
	
	/**
	 * Returns a connection to the DB
	 * 
	 * @return Connection DB Connection
	 * @throws SQLException 
	 */
	public Connection getConnection() throws SQLException {
		Connection connection = DriverManager.getConnection(this.url, this.username, this.password);
		//connection.setAutoCommit(true);

		/*
		if(url.contains("jdbc:oracle")) {
			Statement s = connection.createStatement();		
			s.execute("{call set_procuser_context.set_user('QA', TRUE)}");
			s.close();
		}
		*/

		return connection;
	}

	/**
     * Returns a Spring Framework SimpleJdbcTemplate.
     *
     * @return a Spring Framework SimpleJdbcTemplate.
     */
    public SimpleJdbcTemplate getSimpleJdbcTemplate() {

        SingleConnectionDataSource dataSource = new SingleConnectionDataSource();
        dataSource.setAutoCommit(false);
        dataSource.setDriverClassName(PropertiesReader.getString(DRIVER));
        dataSource.setUrl(this.url);
        dataSource.setUsername(this.username);
        dataSource.setPassword(this.password);

        SimpleJdbcTemplate jdbcTemplate = new SimpleJdbcTemplate(dataSource);
        //jdbcTemplate.getJdbcOperations().execute("{call set_procuser_context.set_user('" + "testu1" + "', TRUE) }");

        return jdbcTemplate;
    }
    
    /**
     * Returns a Spring Framework SimpleJdbcTemplate.
     *
     * @return a Spring Framework SimpleJdbcTemplate.
     */
    public SimpleJdbcTemplate getSimpleJdbcTemplate(boolean setAutoCommit) {

        SingleConnectionDataSource dataSource = new SingleConnectionDataSource();
        dataSource.setAutoCommit(setAutoCommit);
        dataSource.setDriverClassName(PropertiesReader.getString(DRIVER));
        dataSource.setUrl(this.url);
        dataSource.setUsername(this.username);
        dataSource.setPassword(this.password);

        SimpleJdbcTemplate jdbcTemplate = new SimpleJdbcTemplate(dataSource);
        //jdbcTemplate.getJdbcOperations().execute("{call set_procuser_context.set_user('" + "testu1" + "', TRUE) }");

        return jdbcTemplate;
    }
}
