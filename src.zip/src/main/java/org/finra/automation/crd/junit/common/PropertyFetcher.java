package org.finra.automation.crd.junit.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.PropertyResourceBundle;

public final class PropertyFetcher
{
	private final PropertyResourceBundle PROPERTY_RESOURCE_BUNDLE;
	
	public PropertyFetcher(String filePath) throws IOException
	{
		InputStream inputStream = PropertyFetcher.class.getClassLoader().getResourceAsStream(filePath);
		if(inputStream == null)
		{
			inputStream = new FileInputStream(new File(filePath));
		}
		PROPERTY_RESOURCE_BUNDLE = new PropertyResourceBundle(inputStream);
	}
	
	public String fetchString(String propertyName, Object... parameters)
	{
		String unformattedString = System.getProperty(propertyName);
		if(unformattedString == null)
		{
			unformattedString = PROPERTY_RESOURCE_BUNDLE.getString(propertyName);
		}
		return MessageFormat.format(unformattedString, parameters);
	}
}
