package org.finra.automation.crd.junit.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import junit.framework.Assert;

/**
 * Manages oracle connections in a pool. Handles creation of connections, returning connections, release connections.
 * 
 * @author kood
 *
 */
public class ConnectionManager {
	// Maximium number of open connections
	private static final int MAX_RESOURCES = 5;
	
	// TODO: This will break if the backend is changed from Oracle.
	private static final String ORACLE_TIMESTAMP = "select sysdate from dual";

	private static Map<Connection,Boolean> connections = new HashMap<Connection, Boolean>(MAX_RESOURCES);

	private ConnectionManager() {

	}
	
	public static Connection getOracleConnection() throws SQLException {
		if (connections == null)
			throw new RuntimeException("Connection pool not initialized");

		Set<Connection> set = connections.keySet();

		Connection availableCon = null;
		for (Connection con : set) {
			Boolean available = connections.get(con);

			if (available.booleanValue()) {
				availableCon = con;
				break;
			}
		}

		if (availableCon != null) {
			connections.put(availableCon, new Boolean(false));
			return availableCon;
		}

		// If none of the sessions is available and if total no. of opened
		// sessions is equal to MAX_RESOURCES size then throw exception
		if (connections.size() == MAX_RESOURCES)
			throw new RuntimeException("Insufficient Connection Resources");

		availableCon = JdbcConnectionUtilImpl.getInstance().getConnection();

		connections.put(availableCon, new Boolean(false));

		return availableCon;
	} 
	
	public static void closeConnections() {
		if(connections != null) {
			Set<Connection> keys = connections.keySet();
			for(Connection con : keys) {
				if (con != null) {
					try {
						con.close();
					} catch (Exception ignore) {
					}
				}
			}
			while(!connections.isEmpty())
				connections.clear();		
		}
	}

	public static void setAutoCommit(Connection con, boolean autoCommit) {
		if (con != null) {
			try {
				con.setAutoCommit(autoCommit);
			} catch (Exception ignore) {
			}
		}
	}

	public static void rollback(Connection con) {
		if (con != null) {
			try {
				con.rollback();
			} catch (Exception ignore) {
			}
		}
	}

	/**
	 * Gets a timestamp from the Oracle server
	 * 
	 * @return
	 * @throws SQLException
	 */
	public static Timestamp getServerTime() throws SQLException {
		PreparedStatement ps = getOracleConnection().prepareStatement(
				ORACLE_TIMESTAMP);
		ResultSet result = ps.executeQuery();
		Assert.assertTrue("Could not query database for timestamp", result
				.next());
		Timestamp retval = result.getTimestamp("sysdate");
		result.close();
		ps.close();
		return retval;
	}
}
