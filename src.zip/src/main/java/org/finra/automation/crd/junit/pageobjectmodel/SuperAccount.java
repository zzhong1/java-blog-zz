package org.finra.automation.crd.junit.pageobjectmodel;

import org.apache.commons.lang.RandomStringUtils;
import org.finra.ews.http.apis.EwsClient;

import qc.automation.framework.common.UserCredentialsReader;
import qc.automation.framework.properties.UserPropertiesReader;
import qc.automation.framework.utilities.Base64EncoderDecoder;

public class SuperAccount {
	String superUser;
	String url;
	String newAccountID;
	String newAccountPass;
	String newAccountAnswer;
	public SuperAccount(String superUser, String url){
		this.superUser = superUser;
		this.url = url;
	}
	
	public void cloneAccount(String org_pk, String cloneAccountID) throws Throwable{
		String tempPassword = "Temp" + System.currentTimeMillis();
        String s = UserCredentialsReader.getInstance().getProperty("passwordsEncoded");
        boolean encoded = (s != null && s.equals("true"));
        String userName = UserCredentialsReader.getInstance().getProperty(superUser + ".username");
		String password = UserCredentialsReader.getInstance().getProperty(superUser + ".password");
		
		newAccountID = RandomStringUtils.randomAlphabetic(10);
		
		if(encoded)
			password = Base64EncoderDecoder.decodeString(password);
		
		String answer = UserPropertiesReader.getString(superUser + ".answer");
		
		String[] userDetails = createUserDetail(newAccountID, tempPassword, org_pk);
		
		EwsClient ews = new EwsClient(url); 
		
			ews.login(userName, password, answer);
			ews.getAccountManager().cloneAccount(cloneAccountID, userDetails);
			ews.logout();
			ews.firstLogin(newAccountID, tempPassword, password, answer);
			ews.logout();
			newAccountAnswer = answer;
			newAccountPass =  password;
			System.out.println("##########		" + newAccountID + " has been successfully created.		##########");
	
	}
	
	public String getNewAccountID() {
		return newAccountID;
	}

	public String getNewAccountPass() {
		return newAccountPass;
	}

	public String getNewAccountAnswer() {
		return newAccountAnswer;
	}
	private String[] createUserDetail(String newAccountID, String pwd, String org_pk) {
		String[] detail = {"userId=" + newAccountID, 
							"password=" + pwd ,
							"first=test",
							"last=test",
							"email=test@finra.org",
							"phone=123-456-7890",
							"orgClass=Firm", 
							"orgId=" + org_pk,
							"traceMpids=12345"};
		return detail; 
	}
}
