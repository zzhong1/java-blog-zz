package org.finra.automation.crd.junit.pageobjectmodel;

import java.util.Map;

import org.finra.automation.crd_automation.ui.widget.SearchPanel;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;

import qc.automation.framework.widget.WidgetException;

/*
 * The CRDSearch class is used for all kinds of searching in the CRD/IARD sites.
 * The SearchPanel widget class will select corresponding tab only if the search type is Simple Search, Advanced Search, or Pre-Registration Search, 
 * Based on the Map-based search criteria, the SearchPanel widget class can fill in data.
 *  
 */
public class CRDSearch {
	private SearchPanel sp;
	private String searchType;
	
	public CRDSearch(String searchType) throws WidgetException{
		sp = new SearchPanel();
		this.searchType = searchType;
	}
	
	/*
	 * @param searchCriteria the Map-based criteria is used for all CRD/IARD search criteria page
	 * Possible keys could be Short Text, CRD Number, SSN, Name, Last Name, First Name, Middle Name,
	 * Sounds Like, Firm Name, Firm CRD Number, Organization CRD#, Fingerprint Barcode, 
	 * Birthday, Number of Rows per Page, CRD/IARD Number, SEC Number, etc.
	 */
	public void doSearch(Map<String, String> searchCriteria) throws WidgetException{
		FormMainContent fmc = new FormMainContent();
		fmc.waitForPageLoading();
		
		if(getSearchType().equalsIgnoreCase("Simple Search") || 
		   getSearchType().equalsIgnoreCase("Advanced Search") || 
		   getSearchType().equalsIgnoreCase("Pre-Registration Search"))
			sp.selectTab(searchType);
		
		if(searchCriteria != null){
			sp.enterSearchCriteriaData(searchCriteria);
			sp.clickSearchButton();
		}
		else
			throw new WidgetException("Please give a valid seacrh criteria.");
	}
	
	/*
	 * @param searchCriteria the Map-based criteria is used for all branch office search criteria page
	 * Possible keys could be Firm CRD Number, CRD Branch Number, Firms, Predecessors, Firm Billing Code, Branch Code Number, Supervisor/Person-In-Charge CRD#, 
	 * City, State, Postal Code, Country.
	 */
	public void doBranchOfficeSearch(Map<String, String> searchCriteria) throws WidgetException{
		FormMainContent fmc = new FormMainContent();
		fmc.waitForPageLoading();
		
		if(searchCriteria != null){
			sp.enterBranchOfficeSearchCriteriaData(searchCriteria);
			sp.clickSearchButton();
		}
		else
			throw new WidgetException("Please give a valid branch seacrh criteria.");
	}
	
	public SearchPanel getSp() {
		return sp;
	}

	public void setSp(SearchPanel sp) {
		this.sp = sp;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
}
