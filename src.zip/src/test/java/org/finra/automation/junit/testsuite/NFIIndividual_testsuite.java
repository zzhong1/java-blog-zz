package org.finra.automation.junit.testsuite;

import org.finra.automation.crd.nfi.Fingerprints;
import org.finra.automation.crd.nfi.Sanctions;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({
	Fingerprints.class,
	Sanctions.class
	
	})
public class NFIIndividual_testsuite {

}
