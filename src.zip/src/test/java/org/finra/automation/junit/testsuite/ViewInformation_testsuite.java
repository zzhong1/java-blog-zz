package org.finra.automation.junit.testsuite;

import org.finra.automation.vii.VerifyCRDToPSLink_INDVL;
import org.finra.automation.voi.VerifyCRDToPSLink_ORG;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({
	VerifyCRDToPSLink_INDVL.class,
	VerifyCRDToPSLink_ORG.class	
	})
public class ViewInformation_testsuite {

}
