package org.finra.automation.junit.testsuite;

import org.finra.automation.firmgateway.fprd.FirmGateWay_FPRD_Firm_User;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	FirmGateWay_FPRD_Firm_User.class,
	
	
	})
public class FPRD_FG_testsuite {

}
