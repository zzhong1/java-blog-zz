package org.finra.automation.junit.base;

import org.finra.automation.crd.junit.common.RunConfigManager;
import org.finra.ews.ui.login.AdaptiveAuthLoginUI;
import org.finra.jtaf.ewd.ExtWebDriver;
import org.finra.jtaf.ewd.session.SessionManager;
import org.finra.test.tools.commons.utils.Base64EncoderDecoder;


public class Login {
	
	public static ExtWebDriver ewd;
	private static String userName;
	private static String password;
	private static String answer;
	private RunConfigManager runConfig;
	private String applicationURL;

	public void crdLogin(String url,String user) throws Exception
	{
		runConfig = BaseTest.getRunConfig();
		setApplicationURL(url);
		doLogin(runConfig.getApplicationUrl(url), user);
	}
	
	public void crdLogin(String url,String user, String extraUrl) throws Exception
	{   runConfig = BaseTest.getRunConfig();
		setApplicationURL(url);
		String totalURL = runConfig.getApplicationUrl(url) + extraUrl;
		doLogin(totalURL, user);
	}

	private void doLogin(String url, String user) throws Exception{
		
		ewd = SessionManager.getInstance().getNewSession("client", runConfig.getClientFilePath());
		ewd.manage().window().maximize();
		ewd.open(url);
		
		String s = runConfig.isPasswordEncoded("passwordsEncoded");
		boolean encoded = (s != null && s.equals("true"));

		String userPrefix = user;
		if (userPrefix != null) {
			userName = runConfig.getUserPrefix(userPrefix + ".username");
			password = runConfig.getUserPrefix(userPrefix + ".password");
			answer = runConfig.getUserPrefix(userPrefix + ".answer");
		} 
		if (encoded)
			password = Base64EncoderDecoder.decodeString(password);

		AdaptiveAuthLoginUI lgu = new AdaptiveAuthLoginUI();
		lgu.setDeleteCookies(true);
		lgu.login(userName, password, answer);
	}
	public void crdLogin(String url,String userID, String password, String answer) throws Exception{
		runConfig = BaseTest.getRunConfig(); 
		
		ewd = SessionManager.getInstance().getNewSession("client", runConfig.getClientFilePath());
		ewd.manage().window().maximize();
		ewd.open(runConfig.getApplicationUrl(url));
						
		String s = runConfig.isPasswordEncoded("passwordsEncoded");
		boolean encoded = (s != null && s.equals("true"));

		
		if (encoded)
			password = Base64EncoderDecoder.decodeString(password);
		AdaptiveAuthLoginUI lgu = new AdaptiveAuthLoginUI();
		lgu.setDeleteCookies(true);
		lgu.login(userID, password, answer);
	}
	
	public String getApplicationURL() {
		return applicationURL;
	}

	public void setApplicationURL(String url) {
		this.applicationURL = runConfig.getApplicationUrl(url);
	}
}

