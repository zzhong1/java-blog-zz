package org.finra.automation.junit.testsuite;

import org.finra.automation.pfrd.*;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	PF_Generate_Private_FundID.class,
	PF_New_UpdatePending_Delete_Filing.class,
	PF_OrgSearch.class,
	PF_Sample.class,
	PF_View_XML_History.class,
	PrintHistorical_New_Version.class,
	PrintHistorical_Old_Version.class
	
	})
public class PFRD_testsuite {

}
