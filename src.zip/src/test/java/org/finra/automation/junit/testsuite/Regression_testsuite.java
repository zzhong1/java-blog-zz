package org.finra.automation.junit.testsuite;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

	@RunWith(Suite.class)
	@SuiteClasses({ PrintHistorical_testsuite.class })
	public class Regression_testsuite {

	    @BeforeClass 
	    public static void setUpClass() {      
	        System.out.println("Test Starts..");

	    }

	    @AfterClass public static void tearDownClass() { 
	        System.out.println("Test End");
	    }

	}

