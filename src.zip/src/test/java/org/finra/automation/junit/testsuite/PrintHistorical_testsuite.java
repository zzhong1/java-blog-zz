package org.finra.automation.junit.testsuite;

import org.finra.automation.crd.printhistorical.bdbdw.PrintHistorical_BD;
import org.finra.automation.crd.printhistorical.bdbdw.PrintHistorical_BDW;
import org.finra.automation.crd.printhistorical.br.PrintHistorical_BR;
import org.finra.automation.crd.printhistorical.nrf.PrintHistorical_NRF;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_BankruptcyDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_BondDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_CivilJudicialDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_CriminalDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_CustomerComplaintDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_InvestigationDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_JudgmentLienDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_RegulatoryActionDRP;
import org.finra.automation.crd.printhistorical.u4.PrintHistorical_U4_TerminaionDRP;
import org.finra.automation.crd.printhistorical.u5.PrintHistorical_U5_CriminalDRP;
import org.finra.automation.crd.printhistorical.u5.PrintHistorical_U5_CustomerComplaintDRP;
import org.finra.automation.crd.printhistorical.u5.PrintHistorical_U5_InternalReviewDRP;
import org.finra.automation.crd.printhistorical.u5.PrintHistorical_U5_InvestigationDRP;
import org.finra.automation.crd.printhistorical.u5.PrintHistorical_U5_RegulatoryActionDRP;
import org.finra.automation.crd.printhistorical.u5.PrintHistorical_U5_TerminationDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Indvl_BankruptcyDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Indvl_CivilJudicialDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Indvl_CriminalDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Indvl_InvestigationDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Indvl_RegulatoryActionDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Org_BankruptcyDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Org_CivilJudicialDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Org_CriminalDRP;
import org.finra.automation.crd.printhistorical.u6.PrintHistorical_U6_Org_RegulatoryActionDRP;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;



@RunWith(Suite.class)
@SuiteClasses({
	PrintHistorical_U4_BankruptcyDRP.class,
	PrintHistorical_U4_BondDRP.class,
	PrintHistorical_U4_CivilJudicialDRP.class,
	PrintHistorical_U4_CriminalDRP.class,
	PrintHistorical_U4_CustomerComplaintDRP.class,
	PrintHistorical_U4_InvestigationDRP.class,
	PrintHistorical_U4_JudgmentLienDRP.class,
	PrintHistorical_U4_RegulatoryActionDRP.class,
	PrintHistorical_U4_TerminaionDRP.class,
	PrintHistorical_U5_CriminalDRP.class,
	PrintHistorical_U5_CustomerComplaintDRP.class, 
	PrintHistorical_U5_InternalReviewDRP.class,
	PrintHistorical_U5_InvestigationDRP.class,
	PrintHistorical_U5_RegulatoryActionDRP.class,
	PrintHistorical_U5_TerminationDRP.class,
	PrintHistorical_U6_Indvl_BankruptcyDRP.class,
	PrintHistorical_U6_Indvl_CivilJudicialDRP.class,
	PrintHistorical_U6_Indvl_CriminalDRP.class,
	PrintHistorical_U6_Indvl_InvestigationDRP.class,
	PrintHistorical_U6_Indvl_RegulatoryActionDRP.class,
	PrintHistorical_U6_Org_BankruptcyDRP.class,
	PrintHistorical_U6_Org_CivilJudicialDRP.class,
	PrintHistorical_U6_Org_CriminalDRP.class,
	PrintHistorical_U6_Org_RegulatoryActionDRP.class,
	PrintHistorical_BR.class,
	PrintHistorical_BD.class,
	PrintHistorical_BDW.class,
	PrintHistorical_NRF.class
	})
public class PrintHistorical_testsuite {

}
