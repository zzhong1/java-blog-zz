package org.finra.automation.dda;

import org.finra.automation.crd.junit.pageobjectmodel.CommonControls;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.junit.Rule;
import org.junit.Test;

import org.junit.Assert;
import qc.automation.framework.properties.GUIProperties;



public class FinraReport {
	
	@Rule
	public BaseTest base=new BaseTest(); 
	
	Login crd=new Login();		
	
    FormNavigation nav = new FormNavigation();
    
	FormMainContent fmc = new FormMainContent();
	private static final GUIProperties GUI = new GUIProperties("crd/gui.properties");
	
	@Test
	public void requestAccounting_AccountActivityFirms() throws Exception
	{
		
		String basepath=GUI.getPropertyValue("crd.base");
		String xpath=GUI.getPropertyValue("crd.report.title");
		CommonControls controls = new CommonControls(basepath);
		BaseTest.getLogger().info("***** Request report for Accounting Activity Firms as FINRA User***********");
		
		crd.crdLogin("crd.application.url", "ARTFINRAJR");
		nav.goToReports();
		fmc.clickHyperlink("monthly account activity", "Accounting - Account Activity - Firms");
		System.out.println(controls.getTitle(xpath));
		Assert.assertSame("Enter Parameters to Request : Accounting - Account Activity - Firms",controls.getTitle(xpath));
		fmc.inputText("PRIMARY", "249");
		fmc.inputText("USERINIT", "AUTO");
		fmc.clickButton("Submit", "1");
		// to be continued for future verification
		
	}
	
}
