package org.finra.automation.crd.printhistorical.u4;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_U4_BondDRP{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	/*
	 * cover 9/13 fields (70% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_BondDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.bond.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Bond DRP"));
		// Verify checkboxes of 14L
		rp.verifyCheckBoxFlag(resultSet, "U4_FNNCL_DSCLR_L_FL", "ph.u4.drp.question", "14L");
		
		// Verify question 1 Firm Name (Policy Holder)
		rp.verifyDataWithUI(resultSet,"PLCY_HLDR_NM","ph.u4.drp.input.span","Firm Name (Policy Holder)", gp.getPropertyValue("crd.formtable.container","Bond DRP"));
		
		// Verify question 2 Bonding Company Name
		rp.verifyDataWithUI(resultSet,"BONDG_CMPNY_NM","ph.u4.drp.input.span","Bonding Company Name", gp.getPropertyValue("crd.formtable.container","Bond DRP"));
	
		// Verify question 3
		rp.verifyOptionalRadioButtonGroup(resultSet,"BOND_PAYOT_DPSTN_TYPE_NM","ph.u4.drp.selected.optional.radio.button.item","Disposition Type");
		
		//Verify qustion 4
		rp.verifyDataWithUI(resultSet,"PH_DPSTN_DT","ph.u4.drp.input.span","Disposition Date", gp.getPropertyValue("crd.formtable.container","Bond DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"DPSTN_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Disposition Date");
		
		// Verify question 5
		rp.verifyDataWithUI(resultSet,"PH_BOND_PAYOT_DT","ph.u4.drp.input.span","Date Paid", gp.getPropertyValue("crd.formtable.container","Bond DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"BOND_PAYOT_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date Paid");
		
		// Verify question 6
		rp.verifyDataWithUI(resultSet,"SM_TX","ph.u4.drp.input.span","Comment", gp.getPropertyValue("crd.formtable.container","Bond DRP"));
	}

	
}
