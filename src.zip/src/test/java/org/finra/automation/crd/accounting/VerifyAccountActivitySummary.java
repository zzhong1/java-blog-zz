package org.finra.automation.crd.accounting;

import java.util.HashMap;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.FormTable;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;


public class VerifyAccountActivitySummary {
	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	
	@Rule
	public BaseTest basetest= new BaseTest();
	
	@Test
	public void verifyAccountActivitySummary() throws Exception {
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToAccountingPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Organization CRD#", "249");
		
		CRDSearch crdSearch = new CRDSearch("Organization Search");
		crdSearch.doSearch(searchCriteria);
		
		LeftNavigation leftNav = new LeftNavigation();
		leftNav.selectItem("Account Activity Summary");
		
		FormMainContent fmc = new FormMainContent();
		
		fmc.clickButton("Search", "2");

		FormTable ft = new FormTable();
		Assert.assertTrue("Account Activity summary does not displayed properly", ft.checkTable());		
		
	}
}
