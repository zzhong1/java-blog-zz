package org.finra.automation.crd.printhistorical.nrf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;

public class PrintHistorical_NRF {
	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private LeftNavigation leftNav = new LeftNavigation();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	/*
	 * cover 31/31 fields (100% coverage)
	 */
	@Test
	public void verifyPrintHistorical_NRF_Page() throws Exception {
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.nrf",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalNRFFilings();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);		
		/*
		 * Go to DRP page
		 */
		System.out.println("***** verifying Other Name - page *****");
		nav.goToFilingPage(flng_pk, "Other Names");		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.table","grdNRF_OtherNames"));		
		/*
		 * Prepare sql parameters and execute sql
		 */
		sqlParameters.put("FLNG_PK", flng_pk);
		se = new SqlExecutor("main", System.getProperty("target"));
		resultSet = se.executeForStrings("ph.nrf.othernames",sqlParameters);		
		rp.verifyDataWithUI(resultSet, "Other Names", "crd.table", "grdNRF_OtherNames");
		/*
		 * Prepare sql parameters and execute sql
		 */
		sqlParameters.put("FLNG_PK", flng_pk);
		se = new SqlExecutor("main", System.getProperty("target"));
		resultSet = se.executeForStrings("ph.nrf.personalinfo",sqlParameters);	
		
		System.out.println("***** verifying Personal Information - page *****");
		leftNav.selectItem("Personal Information");
		
		rp.verifyDataWithUI(resultSet, "First Name", "ph.nrf.info", "1");
		rp.verifyDataWithUI(resultSet, "Middle Name", "ph.nrf.info", "2");
		rp.verifyDataWithUI(resultSet, "Last Name", "ph.nrf.info", "3");
		rp.verifyDataWithUI(resultSet, "Suffix", "ph.nrf.info", "4");
		rp.verifyDataWithUI(resultSet, "Date Of Birth(MM/DD/YYYY)", "ph.nrf.info", "5");
		rp.verifyDataWithUI(resultSet, "State Of Birth", "ph.nrf.info", "6");
		rp.verifyDataWithUI(resultSet, "Province Of Birth", "ph.nrf.info", "7");
		rp.verifyDataWithUI(resultSet, "Country Of Birth", "ph.nrf.info", "8");
		rp.verifyDataWithUI(resultSet, "Height (ft)", "ph.nrf.info", "9");
		rp.verifyDataWithUI(resultSet, "Height (in)", "ph.nrf.info", "10");
		rp.verifyDataWithUI(resultSet, "Weight (lbs)", "ph.nrf.info", "11");
		rp.verifyDataWithUI(resultSet, "Hair Color", "ph.nrf.info", "12");
		rp.verifyDataWithUI(resultSet, "Eye Color", "ph.nrf.info", "13");		
		rp.verifyOptionalRadioButtonGroup(resultSet, "INDVL_SEX", "ph.u4.drp.selected.optional.radio.button.item", "Sex");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		sqlParameters.put("FLNG_PK", flng_pk);
		se = new SqlExecutor("main", System.getProperty("target"));
		resultSet = se.executeForStrings("ph.nrf.generalinfo",sqlParameters);
		
		System.out.println("***** verifying General Information - page *****");
		leftNav.selectItem("General Information");
		
		FormMainContent fmc = new FormMainContent();
		fmc.clickButton("View SSN", "1");
		
		rp.verifyDataWithUI(resultSet, "Firm CRD #", "ph.nrf.info", "FirmCRD");
		rp.verifyDataWithUI(resultSet, "Firm Name", "ph.nrf.info", "FirmName");
		rp.verifyDataWithUI(resultSet, "Employment Date", "ph.nrf.info", "1");
		rp.verifyDataWithUI(resultSet, "Firm Billing Code", "ph.nrf.info", "2");
		rp.verifyDataWithUI(resultSet, "Applicant CRD #", "ph.nrf.info", "IndividualCRD");
		rp.verifyDataWithUI(resultSet, "SSN", "ph.nrf.info", "3");
		rp.verifyDataWithUI(resultSet, "Employment Street Address 1", "ph.nrf.info", "4");
		rp.verifyDataWithUI(resultSet, "Employment Street Address 2", "ph.nrf.info", "5");
		rp.verifyDataWithUI(resultSet, "Employment City", "ph.nrf.info", "6");
		rp.verifyDataWithUI(resultSet, "Employment State", "ph.nrf.info", "7");
		rp.verifyDataWithUI(resultSet, "Employment Country", "ph.nrf.info", "8");
		rp.verifyDataWithUI(resultSet, "Employment Postal Code", "ph.nrf.info", "9");
		rp.verifyDataWithUI(resultSet, "Position in Firm", "ph.nrf.info", "10");
		rp.verifyDataWithUI(resultSet, "Fingerprint barcode #", "ph.nrf.info", "11");
		rp.verifyDataWithUI(resultSet, "Card Status", "ph.nrf.info", "12");
		rp.verifyDataWithUI(resultSet, "Status Date", "ph.nrf.info", "13");
	}
	
	
}
