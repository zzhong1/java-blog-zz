package org.finra.automation.crd.printhistorical.u4;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;



public class PrintHistorical_U4_RegulatoryActionDRP {

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	/*
	 * cover 81/113 fields (72% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_RegulatoryActionDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));		
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.regulatoryaction.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);

		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Regulatory Action DRP"));
		/*Verify checkboxes of 14C(1), 14C(2), 14C(3), 14C(4), 14C(5), 14C(6), 14C(7), 14C(8), 14D(1)(a), 14D(1)(b), 14D(1)(c), 14D(1)(d), 14D(1)(e), 14D(2)(a), 14D(2)(b), 
		14E(1), 14E(2), 14E(3), 14E(4), 14E(5), 14E(6), 14E(7), 14F, 14G(1)*/
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C1_FL", "ph.u4.drp.question", "14C(1)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C2_FL", "ph.u4.drp.question", "14C(2)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C3_FL", "ph.u4.drp.question", "14C(3)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C4_FL", "ph.u4.drp.question", "14C(4)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C5_FL", "ph.u4.drp.question", "14C(5)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C6_FL", "ph.u4.drp.question", "14C(6)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C7_FL", "ph.u4.drp.question", "14C(7)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_C8_FL", "ph.u4.drp.question", "14C(8)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_D1_FL", "ph.u4.drp.question", "14D(1)(a)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_D2_FL", "ph.u4.drp.question", "14D(1)(b)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_D3_FL", "ph.u4.drp.question", "14D(1)(c)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_D4_FL", "ph.u4.drp.question", "14D(1)(d)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_D5_FL", "ph.u4.drp.question", "14D(1)(e)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_D2A_FL", "ph.u4.drp.question", "14D(2)(a)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_D2B_FL", "ph.u4.drp.question", "14D(2)(b)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_E1_FL", "ph.u4.drp.question", "14E(1)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_E2_FL", "ph.u4.drp.question", "14E(2)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_E3_FL", "ph.u4.drp.question", "14E(3)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_E4_FL", "ph.u4.drp.question", "14E(4)");		
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_E5_FL", "ph.u4.drp.question", "14E(5)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_E6_FL", "ph.u4.drp.question", "14E(6)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_E7_FL", "ph.u4.drp.question", "14E(7)");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_F_FL", "ph.u4.drp.question", "14F");
		rp.verifyCheckBoxFlag(resultSet, "U4_RGLTY_DSCLR_G1_FL", "ph.u4.drp.question", "14G(1)");
		
		// Verify question 2
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_BAR_SNCTN_FL", "ph.u4.drp.question", "Bar");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_CEASE_FL", "ph.u4.drp.question", "Cease and Desist");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_CNSR_FL", "ph.u4.drp.question", "Censure");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_CIVIL_PNLTY_FL", "ph.u4.drp.question", "Civil and Administrative Penalty(ies)/Fine(s)");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_DNL_FL", "ph.u4.drp.question", "Denial");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_DSGRT_FL", "ph.u4.drp.question", "Disgorgement");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_XPLSN_FL", "ph.u4.drp.question", "Expulsion");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_OTHER_MNTRY_PNLTY_FL", "ph.u4.drp.question", "Monetary Penalty other than Fines");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_PHBTN_FL", "ph.u4.drp.question", "Prohibition");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_RPRMD_FL", "ph.u4.drp.question", "Reprimand");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_RQUAL_FL", "ph.u4.drp.question", "Requalification");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_RSSSN_FL", "ph.u4.drp.question", "Rescission");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_RSTTN_FL", "ph.u4.drp.question", "Restitution");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_NDTKG_FL", "ph.u4.drp.question", "Undertaking");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_RVCTN_FL", "ph.u4.drp.question", "Revocation");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_SPNSN_FL", "ph.u4.drp.question", "Suspension");
		
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"PH_INTTD_DT","ph.u4.drp.input.span","Date Initiated", gp.getPropertyValue("crd.formtable.container","Regulatory Action DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"INTTD_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date Initiated");
		
		// Verify question 6
		rp.verifyCheckBoxFlag(resultSet, "NO_PRDCT_FL", "ph.u4.regaction.drp.question.6", "No Product");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_CHTBL_FL", "ph.u4.regaction.drp.question.6", "Annuity-Charitable");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_FIXED_FL", "ph.u4.regaction.drp.question.6", "Annuity-Fixed");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_VRBL_FL", "ph.u4.regaction.drp.question.6", "Annuity-Variable");
		rp.verifyCheckBoxFlag(resultSet, "BANKG_PRDCT_NO_CD_FL", "ph.u4.regaction.drp.question.6", "Banking Products (other than CDs)");
		rp.verifyCheckBoxFlag(resultSet, "CMDTY_OPTN_FL", "ph.u4.regaction.drp.question.6", "Commodity Option");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_ASSET_BCKD_FL", "ph.u4.regaction.drp.question.6", "Debt-Asset Backed");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_CRPRT_FL", "ph.u4.regaction.drp.question.6", "Debt-Corporate");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_GOVT_FL", "ph.u4.regaction.drp.question.6", "Debt-Government");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_MNCPL_FL", "ph.u4.regaction.drp.question.6", "Debt-Municipal");
		rp.verifyCheckBoxFlag(resultSet, "DRVTV_FL", "ph.u4.regaction.drp.question.6", "Derivative");
		rp.verifyCheckBoxFlag(resultSet, "DRCT_NVSMT_DPP_LP_INTRS_FL", "ph.u4.regaction.drp.question.6", "Direct Investment-DPP");
		rp.verifyCheckBoxFlag(resultSet, "EQUIP_LSNG_FL", "ph.u4.regaction.drp.question.6", "Equipment Leasing");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_LSTD_FL", "ph.u4.regaction.drp.question.6", "Equity Listed");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_OTC_FL", "ph.u4.regaction.drp.question.6", "Equity-OTC");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_CMDTY_FL", "ph.u4.regaction.drp.question.6", "Futures Commodity");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_FNNCL_FL", "ph.u4.regaction.drp.question.6", "Futures-Financial");
		rp.verifyCheckBoxFlag(resultSet, "INDX_OPTN_FL", "ph.u4.regaction.drp.question.6", "Index Option");
		rp.verifyCheckBoxFlag(resultSet, "NSRNC_FL", "ph.u4.regaction.drp.question.6", "Insurance");
		rp.verifyCheckBoxFlag(resultSet, "NVSMT_CNTRC_FL", "ph.u4.regaction.drp.question.6", "Investment Contract");
		rp.verifyCheckBoxFlag(resultSet, "MONEY_MKT_FUND_FL", "ph.u4.regaction.drp.question.6", "Money Market Fund");
		rp.verifyCheckBoxFlag(resultSet, "MTL_FUND_FL", "ph.u4.regaction.drp.question.6", "Mutual Fund");
		rp.verifyCheckBoxFlag(resultSet, "OIL_GAS_FL", "ph.u4.regaction.drp.question.6", "Oil");
		rp.verifyCheckBoxFlag(resultSet, "OPTNS_FL", "ph.u4.regaction.drp.question.6", "Options");
		rp.verifyCheckBoxFlag(resultSet, "PNNY_STOCK_FL", "ph.u4.regaction.drp.question.6", "Penny Stock");
		rp.verifyCheckBoxFlag(resultSet, "PRIME_BANK_NTRMT_FL", "ph.u4.regaction.drp.question.6", "Prime Bank Instrument");
		rp.verifyCheckBoxFlag(resultSet, "PRMSY_NOTE_FL", "ph.u4.regaction.drp.question.6", "Promissory Note");
		rp.verifyCheckBoxFlag(resultSet, "RE_SCRTY_FL", "ph.u4.regaction.drp.question.6", "Real Estate Security");
		rp.verifyCheckBoxFlag(resultSet, "SCRTY_FTRS_FL", "ph.u4.regaction.drp.question.6", "Security Futures");
		rp.verifyCheckBoxFlag(resultSet, "UNIT_NVSMT_TRUST_FL", "ph.u4.regaction.drp.question.6", "Unit Investment Trust");
		rp.verifyCheckBoxFlag(resultSet, "VTCL_STLMT_FL", "ph.u4.regaction.drp.question.6", "Viatical Settlement");
		
		// Verify question 8
		rp.verifyOptionalRadioButtonGroup(resultSet,"DSCLR_ST_TYPE_NM","ph.u4.drp.selected.optional.radio.button.item","Current Status?");
		
		// Verify question 9 -- ????
		/*rp.verifyRadioButtonGroup(resultSet,"LMTNS_RSTRN_FL","ph.u4.drp.selected.optional.radio.button","If pending, are there any limitations or restrictions currently in effect?");*/
		
		// Verify question 10
		rp.verifyRadioButtonGroup(resultSet,"APPL_LMTNS_RSTRN_FL","ph.u4.drp.selected.optional.radio.button","Are there any limitations or restrictions currently in effect while on appeal?");
		
		// Verify question 14
		rp.verifyDataWithUI(resultSet,"PH_SM_TX","ph.u4.drp.input.span","Comment (Optional)", gp.getPropertyValue("crd.formtable.container","Regulatory Action DRP"));
	}


	/*
	 * cover 3/10 fields (30% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_RegulatoryAction_MonetaryDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));		
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.regulatoryaction.monetary.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);

		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("ph.u4.drp.child.details.container","Monetary Sanction Details"));
		// Verify question 1
		rp.verifyDataWithUI(resultSet,"MNTRY_SNCTN_TYPE_NM","ph.u4.drp.input.span","Monetary Related Sanction Type:", gp.getPropertyValue("ph.u4.drp.child.details.container","Monetary Sanction Details"));
		
		// Verify question 4
		rp.verifyDataWithUI(resultSet,"MNTRY_SNCTN_PMT_PLAN_TX","ph.u4.drp.input.span","Payment Plan:", gp.getPropertyValue("ph.u4.drp.child.details.container","Monetary Sanction Details"));
		
		// Verify question 6
		rp.verifyDataWithUI(resultSet,"PH_MNTRY_SNCTN_DT_PAID","ph.u4.drp.input.span","Date Paid", gp.getPropertyValue("ph.u4.drp.child.details.container","Monetary Sanction Details"));	
		
	}
	
	/*
	 * cover 8/11 fields (73% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_RegulatoryAction_SanctionDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));		
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.regulatoryaction.sanction.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);

		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("ph.u4.drp.child.details.container","Sanction Details"));
		// Verify question 1
		rp.verifyDataWithUI(resultSet,"SNCTN_TYPE_NM","ph.u4.drp.input.span","Sanction Type:", gp.getPropertyValue("ph.u4.drp.child.details.container","Sanction Details"));
		
		// Verify question 2
		rp.verifyDataWithUI(resultSet,"CPCTY_AFCTD_TX","ph.u4.drp.input.span","Registration Capacities affected", gp.getPropertyValue("ph.u4.drp.child.details.container","Sanction Details"));
		
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"DRTN_TX","ph.u4.drp.input.span","Duration (length of time):", gp.getPropertyValue("ph.u4.drp.child.details.container","Sanction Details"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"DRTN_TX_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Duration (length of time):");
		
		// Verify question 4
		rp.verifyDataWithUI(resultSet,"PH_START_DT","ph.u4.drp.input.span","Start Date (MM/DD/YYYY):", gp.getPropertyValue("ph.u4.drp.child.details.container","Sanction Details"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"START_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Start Date (MM/DD/YYYY):");
		
		// Verify question 5
		rp.verifyDataWithUI(resultSet,"PH_END_DT","ph.u4.drp.input.span","End Date (MM/DD/YYYY):", gp.getPropertyValue("ph.u4.drp.child.details.container","Sanction Details"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"END_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","End Date (MM/DD/YYYY):");
	
	}
	
	
	
	/*
	 * cover 3/5 fields (60% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_RegulatoryAction_RequalificationDRP() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));		
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.regulatoryaction.requalification.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);

		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("ph.u4.drp.child.details.container","Requalification Details"));
		// Verify question 1
		rp.verifyDataWithUI(resultSet,"RQUAL_TYPE_NM","ph.u4.drp.input.span","Requalification Type:", gp.getPropertyValue("ph.u4.drp.child.details.container","Requalification Details"));
		
		// Verify question 2
		rp.verifyDataWithUI(resultSet,"RQUAL_LENGTH_TX","ph.u4.drp.input.span","Length of time given to requalify/retrain:", gp.getPropertyValue("ph.u4.drp.child.details.container","Requalification Details"));
		
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"EXAM_TX","ph.u4.drp.input.span","Type of Exam required:", gp.getPropertyValue("ph.u4.drp.child.details.container","Requalification Details"));

	}
	
	
}
