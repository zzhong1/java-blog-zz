package org.finra.automation.crd.printhistorical.u6;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;



public class PrintHistorical_U6_Org_CivilJudicialDRP{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();


	/*
	 * cover 69/92 fields (75% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U6_Org_CivilJudicialDRP() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U6");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u6.org.civil.2009.05",sqlParameters);
		String org_pk = resultSet.get(0).get("ORG_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("ORG_PK = " + org_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U6 filing search page
		 */
		nav.goToHistoricalU6Filings("CRD/IARD Organization");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Firm CRD Number", org_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","CIVIL JUDICIAL DRP"));
		
		// Verify question 1 
		rp.verifyDataWithUI(resultSet,"INTTR_TX","ph.u6.org.drp.text","Court Action initiated by", gp.getPropertyValue("crd.formtable.container","CIVIL JUDICIAL DRP"));
		
		// Verify question 2
		rp.verifyDataWithUI(resultSet,"CIVIL_JDCL_RLF_TYPE_NM","ph.u6.org.drp.text","Principal Relief Sought", gp.getPropertyValue("crd.formtable.container","CIVIL JUDICIAL DRP"));

		//Verify qustion 4
		rp.verifyDataWithUI(resultSet,"PRDCT_TYPE_NM","ph.u6.org.drp.text","Principal Product Type", gp.getPropertyValue("crd.formtable.container","CIVIL JUDICIAL DRP"));

		// Verify question 5
		rp.verifyDataWithUI(resultSet,"COURT_DTL_TX","ph.u6.org.drp.text","Formal Action was brought in", gp.getPropertyValue("crd.formtable.container","CIVIL JUDICIAL DRP"));

		// Verify question 13
		rp.verifyDataWithUI(resultSet,"SNCTN_DTL_TX","ph.u6.org.drp.text","Sanction detail", gp.getPropertyValue("crd.formtable.container","CIVIL JUDICIAL DRP"));
		
		//Verify qestion 14
		rp.verifyDataWithUI(resultSet,"SM_TX","ph.u6.org.drp.text","Comment (Optional)", gp.getPropertyValue("crd.formtable.container","CIVIL JUDICIAL DRP"));

	}

	
	
}
