package org.finra.automation.crd.formfiling;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.FormFiling;
import org.finra.automation.junit.base.BaseTest;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class U4{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormFiling ff;
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * Submit an U4-Initial filing through WebEFT via HttpRequest
	 */
	@Test
	public void createU4Initial() throws Throwable {
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitU4Initial by parameters are passed
		 */
		ff = new FormFiling("U4_Initial");
		ff.setSubmitDateAsCurrentDate();
		ff.submitU4Initial();
		String indvl_pk = ff.getIndvl_pk();
		String flng_pk = ff.getFlng_pk();
		// do whatever you want
	}

	/*
	 * Submit an U4-Amendment filing through WebEFT via HttpRequest
	 */
	@Test
	public void createU4Amendment() throws Throwable {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FLNG_TYPE_CD", "INITIAL");
		sqlParameters.put("INDVL_FIRM_ST_CD", "ACTIVE");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("find.u4.indvl.without.drp",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String ssn_nb = resultSet.get(0).get("SSN_NB");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("SSN_NB = " + ssn_nb);
		
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitU4Amendment by parameters are passed
		 */
		ff = new FormFiling("U4_Amendment");
		ff.setSubmitDateAsCurrentDate();
		ff.submitU4Amendment(indvl_pk, ssn_nb);
		// do whatever you want
	}

}
