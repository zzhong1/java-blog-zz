package org.finra.automation.crd.printhistorical.u4;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_U4_JudgmentLienDRP{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	/*
	 * cover 10/17 fields (59% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_JudementLienDRP() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.judgementlien.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Judgment Lien DRP"));
		// Verify checkboxes of 14M
		rp.verifyCheckBoxFlag(resultSet, "U4_FNNCL_DSCLR_M_FL", "ph.u4.drp.question", "14M");

		// Verify question 2
		rp.verifyDataWithUI(resultSet,"LIEN_HLDR_NM","ph.u4.drp.input.span","Judgment/Lien Holder", gp.getPropertyValue("crd.formtable.container","Judgment Lien DRP"));
		
		// Verify question 3
		rp.verifyOptionalRadioButtonGroup(resultSet,"JDGMT_LIEN_TYPE_NM","ph.u4.drp.selected.optional.radio.button.item","Judgment/Lien Type");
		
		// Verify question 4
		rp.verifyDataWithUI(resultSet,"PH_JDGMT_LIEN_FILED_DT","ph.u4.drp.input.span","Date Filed",gp.getPropertyValue("crd.formtable.container","Judgment Lien DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"JDGMT_LIEN_FILED_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date Filed");
		
		// Verify question 5
		rp.verifyOptionalRadioButtonGroup(resultSet,"COURT_ACTN_TYPE_NM","ph.u4.drp.selected.optional.radio.button.item","Court action brought in:");
		
		// Verify question 6
		rp.verifyYesNoButtonGroup(resultSet,"JDGMT_LIEN_OSTDG_FL","ph.u4.drp.yesno.radiogroup","Is Judgment/Lien Outstanding?");
		
		// Verify question 7
		rp.verifyDataWithUI(resultSet,"PH_ST_DT","ph.u4.drp.input.span","Status Date", gp.getPropertyValue("crd.formtable.container","Judgment Lien DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"ST_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Status Date");
		
		// Verify question 8
		rp.verifyDataWithUI(resultSet,"SM_TX","ph.u4.drp.input.span","Comment (Optional)", gp.getPropertyValue("crd.formtable.container","Judgment Lien DRP"));
	}

	
}
