package org.finra.automation.crd.formfiling;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.FormFiling;
import org.finra.automation.junit.base.BaseTest;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class BR{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormFiling ff;
	
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * Submit an BR-Initial filing through WebEFT via HttpRequest
	 */
	@Test
	public void createBRInitial() throws Throwable {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("find.supervisor.for.br.initial",sqlParameters);
		String supervisor = resultSet.get(0).get("SUPERVISOR");
		String org_pk = resultSet.get(0).get("ORG_PK");
		System.out.println("supervisor = " + supervisor);
		
		Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
		sqlParameters1.put("ORG_PK", "877");
		sqlParameters1.put("SUPERVISOR", supervisor);
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet1 = se1.executeForStrings("find.associate.for.br.initial",sqlParameters1);
		
		String associate = resultSet1.get(0).get("ASSOINDVL");
		System.out.println("associate = " + associate);
		System.out.println("ORG_PK = " + org_pk);
		
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitNRFInitial by parameters are passed
		 */
		ff = new FormFiling("BR_Initial");
		ff.setSubmitDateAsCurrentDate();
		ff.submitBRInitial(supervisor, associate, org_pk);
		String brnch_ofc_pk = ff.getBrnch_ofc_pk();
		String flng_pk = ff.getFlng_pk();
		// do whatever you want
	}

	/*
	 * Submit an BR-Amendment filing through WebEFT via HttpRequest
	 */
	@Test
	public void createBRAmendment() throws Throwable {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", 877);
		sqlParameters.put("FORM_TYPE_CD", "BR");
		sqlParameters.put("FLNG_TYPE_CD", "INITIAL");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("find.br.for.amend",sqlParameters);
		String org_pk = resultSet.get(0).get("ORG_PK");
		String brnch_ofc_pk = resultSet.get(0).get("BRNCH_OFC_PK");
		System.out.println("ORG_PK = " + org_pk);
		System.out.println("BRNCH_OFC_PK = " + brnch_ofc_pk);
		
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitBRAmendment by parameters are passed
		 */
		ff = new FormFiling("BR_Amendment");
		ff.setSubmitDateAsCurrentDate();
		ff.submitBRAmendment(brnch_ofc_pk, org_pk, "false");
		// do whatever you want
	}

}
