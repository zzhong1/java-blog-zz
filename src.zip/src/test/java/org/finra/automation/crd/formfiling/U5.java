package org.finra.automation.crd.formfiling;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.FormFiling;
import org.finra.automation.junit.base.BaseTest;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class U5{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormFiling ff; 
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * Submit an U5-Partial filing through WebEFT via HttpRequest
	 */
	@Test
	public void createU5Partial() throws Throwable {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("find.indvl.for.u5.partial",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String ssn_nb = resultSet.get(0).get("SSN_NB");
		String rgltr_cd = resultSet.get(0).get("RGLTR_CD");
		String pstn = resultSet.get(0).get("RGSTN_CTGRY_CD");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("SSN_NB = " + ssn_nb);
		
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitU5Partial by parameters are passed
		 */
		ff = new FormFiling("U5_Partial");
		ff.setSubmitDateAsCurrentDate();
		ff.submitU5Partial(indvl_pk, ssn_nb, rgltr_cd, pstn);
		// do whatever you want
	}

	
	/*
	 * Submit an U5-Full filing through WebEFT via HttpRequest
	 */
	@Test
	public void createU5Full() throws Throwable {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FLNG_TYPE_CD", "INITIAL");
		sqlParameters.put("INDVL_FIRM_ST_CD", "ACTIVE");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("find.u4.indvl.without.drp",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String ssn_nb = resultSet.get(0).get("SSN_NB");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("SSN_NB = " + ssn_nb);
		
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitU5Full by parameters are passed
		 */
		ff = new FormFiling("U5_Full");
		ff.setSubmitDateAsCurrentDate();
		ff.submitU5Full(indvl_pk, ssn_nb);
		// do whatever you want
	}

}
