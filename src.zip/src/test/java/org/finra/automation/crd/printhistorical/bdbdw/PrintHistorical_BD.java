package org.finra.automation.crd.printhistorical.bdbdw;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_BD{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * RAD-81858. Verify some fields in the BR PH mode using page router url
	 */
	@Test
	public void verifyPrintHistorical_BD_BankruptcyDRP() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "BD");
		sqlParameters.put("FORM_VRSN_TX", "07/1999");
		sqlParameters.put("FLNG_TYPE_CD", "AMENDMENT");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.bd.bankruptcy.1999.07",sqlParameters);
		String org_pk = resultSet.get(0).get("ORG_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("ORG_PK = " + org_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		String extraUrl = "/PGM/PageRouter.aspx?Action=ShowCRDFiling&FilingPK="+flng_pk;
		crd.crdLogin("crd.application.url","ARTFINRAJR", extraUrl);

		LeftNavigation leftNav = new LeftNavigation();
		leftNav.selectItem("DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Bankrupcty DRP"));
		// Verify checkboxes of 11I(1) and 11I(2)
		rp.verifyCheckBoxFlag(resultSet, "BD_FNNCL_DSCLR_I1_FL", "ph.bd.drp.question", "11I(1)");
		rp.verifyCheckBoxFlag(resultSet, "BD_FNNCL_DSCLR_I2_FL", "ph.bd.drp.question", "11I(2)");
		
	}


	/*
	 * RAD-81828. Verify some fields in the BR RedLine mode using page router url
	 */
	@Test
	public void verifyPrintHistorical_BR_PageRoutingRedLine() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "BD");
		sqlParameters.put("FORM_VRSN_TX", "07/1999");
		sqlParameters.put("FLNG_TYPE_CD", "AMENDMENT");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.bd.bankruptcy.1999.07",sqlParameters);
		String org_pk = resultSet.get(0).get("ORG_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("ORG_PK = " + org_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		String extraUrl = "/PGM/PageRouter.aspx?Action=ShowCRDFiling&FilingPK="+flng_pk;
		crd.crdLogin("crd.application.url","ARTFINRAJR", extraUrl);

		LeftNavigation leftNav = new LeftNavigation();
		leftNav.selectItem("View Changes on Filing");
		leftNav.selectItem("DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Bankrupcty DRP"));
		// Verify checkboxes of 11I(1) and 11I(2)
		rp.verifyCheckBoxFlag(resultSet, "BD_FNNCL_DSCLR_I1_FL", "ph.bd.drp.question", "11I(1)");
		rp.verifyCheckBoxFlag(resultSet, "BD_FNNCL_DSCLR_I2_FL", "ph.bd.drp.question", "11I(2)");
	}
	
	
}
