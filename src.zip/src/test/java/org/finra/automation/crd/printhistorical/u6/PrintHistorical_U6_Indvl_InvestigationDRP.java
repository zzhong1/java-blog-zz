package org.finra.automation.crd.printhistorical.u6;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_U6_Indvl_InvestigationDRP{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	

	/*
	 * cover 6/13 fields (51% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U6_InvesigationDRP() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U6");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.investigation.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U6 filing search page
		 */
		nav.goToHistoricalU6Filings("CRD Individual");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Investigation DRP"));

		// Verify question 2
		rp.verifyDataWithUI(resultSet,"PH_NTC_DT","ph.u4.drp.input.span","Notice Date", gp.getPropertyValue("crd.formtable.container","Investigation DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"NTC_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Notice Date");
		
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"NVSGN_NTR_DESC","ph.u4.drp.input.span","Describe briefly the nature of the", gp.getPropertyValue("crd.formtable.container","Investigation DRP"));
		
		// Verify question 4
		rp.verifyDataWithUI(resultSet,"PH_RSLTN_DT","ph.u4.drp.input.span","Date Closed/Resolved", gp.getPropertyValue("crd.formtable.container","Investigation DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"RSLTN_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date Closed/Resolved");
		
	}

	
}
