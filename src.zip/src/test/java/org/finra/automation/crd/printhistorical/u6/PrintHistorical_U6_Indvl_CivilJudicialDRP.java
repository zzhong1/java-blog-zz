package org.finra.automation.crd.printhistorical.u6;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_U6_Indvl_CivilJudicialDRP{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * cover 69/92 fields (75% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U6_Indvl_CivilJudicialDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U6");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.civil.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U6 filing search page
		 */
		nav.goToHistoricalU6Filings("CRD Individual");

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		// Verify question 1 
		rp.verifyDataWithUI(resultSet,"INTTR_TX","ph.u4.drp.input.span","Court Action initiated by", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		
		// Verify question 2
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_CEASE_FL", "ph.u4.civil.drp.question2.checkbox.group", "Cease and Desist");
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_FINES_FL", "ph.u4.civil.drp.question2.checkbox.group", "Civil and Administrative Penalty(ies)/Fine(s)");
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_DSGRT_FL", "ph.u4.civil.drp.question2.checkbox.group", "Disgorgement");
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_INJTN_FL", "ph.u4.civil.drp.question2.checkbox.group", "Injunction");
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_MNTRY_PNLTY_FL", "ph.u4.civil.drp.question2.checkbox.group", "Monetary Penalty other than fines");
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_RSTTN_FL", "ph.u4.civil.drp.question2.checkbox.group", "Restitution");
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_RO_FL", "ph.u4.civil.drp.question2.checkbox.group", "Restraining Order");
		rp.verifyCheckBoxFlag(resultSet, "RLF_TYPE_OTHER_FL", "ph.u4.civil.drp.question2.checkbox.group", "Other");
	
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"PH_COURT_FLNG_DT","ph.u4.drp.input.span","Filing Date of Court Action", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"COURT_FLNG_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Filing Date of Court Action");
		
		//Verify qustion 4
		rp.verifyCheckBoxFlag(resultSet, "NO_PRDCT_FL", "ph.u4.drp.question", "No Product");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_CHTBL_FL", "ph.u4.drp.question", "Annuity-Charitable");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_FIXED_FL", "ph.u4.drp.question", "Annuity-Fixed");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_VRBL_FL", "ph.u4.drp.question", "Annuity-Variable");
		rp.verifyCheckBoxFlag(resultSet, "BANKG_PRDCT_NO_CD_FL", "ph.u4.drp.question", "Banking Products (other than CDs)");
		rp.verifyCheckBoxFlag(resultSet, "CMDTY_OPTN_FL", "ph.u4.drp.question", "Commodity Option");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_ASSET_BCKD_FL", "ph.u4.drp.question", "Debt-Asset Backed");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_CRPRT_FL", "ph.u4.drp.question", "Debt-Corporate");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_GOVT_FL", "ph.u4.drp.question", "Debt-Government");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_MNCPL_FL", "ph.u4.drp.question", "Debt-Municipal");
		rp.verifyCheckBoxFlag(resultSet, "DRVTV_FL", "ph.u4.drp.question", "Derivative");
		rp.verifyCheckBoxFlag(resultSet, "DRCT_NVSMT_DPP_LP_INTRS_FL", "ph.u4.drp.question", "Direct Investment-DPP");
		rp.verifyCheckBoxFlag(resultSet, "EQUIP_LSNG_FL", "ph.u4.drp.question", "Equipment Leasing");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_LSTD_FL", "ph.u4.drp.question", "Equity Listed");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_OTC_FL", "ph.u4.drp.question", "Equity-OTC");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_CMDTY_FL", "ph.u4.drp.question", "Futures Commodity");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_FNNCL_FL", "ph.u4.drp.question", "Futures-Financial");
		rp.verifyCheckBoxFlag(resultSet, "INDX_OPTN_FL", "ph.u4.drp.question", "Index Option");
		rp.verifyCheckBoxFlag(resultSet, "NSRNC_FL", "ph.u4.drp.question", "Insurance");
		rp.verifyCheckBoxFlag(resultSet, "NVSMT_CNTRC_FL", "ph.u4.drp.question", "Investment Contract");
		rp.verifyCheckBoxFlag(resultSet, "MONEY_MKT_FUND_FL", "ph.u4.drp.question", "Money Market Fund");
		rp.verifyCheckBoxFlag(resultSet, "MTL_FUND_FL", "ph.u4.drp.question", "Mutual Fund");
		rp.verifyCheckBoxFlag(resultSet, "OIL_GAS_FL", "ph.u4.drp.question", "Oil");
		rp.verifyCheckBoxFlag(resultSet, "OPTNS_FL", "ph.u4.drp.question", "Options");
		rp.verifyCheckBoxFlag(resultSet, "PNNY_STOCK_FL", "ph.u4.drp.question", "Penny Stock");
		rp.verifyCheckBoxFlag(resultSet, "PRIME_BANK_NTRMT_FL", "ph.u4.drp.question", "Prime Bank Instrument");
		rp.verifyCheckBoxFlag(resultSet, "PRMSY_NOTE_FL", "ph.u4.drp.question", "Promissory Note");
		rp.verifyCheckBoxFlag(resultSet, "RE_SCRTY_FL", "ph.u4.drp.question", "Real Estate Security");
		rp.verifyCheckBoxFlag(resultSet, "SCRTY_FTRS_FL", "ph.u4.drp.question", "Security Futures");
		rp.verifyCheckBoxFlag(resultSet, "UNIT_NVSMT_TRUST_FL", "ph.u4.drp.question", "Unit Investment Trust");
		rp.verifyCheckBoxFlag(resultSet, "VTCL_STLMT_FL", "ph.u4.drp.question", "Viatical Settlement");
	
		// Verify question 5
		rp.verifyOptionalRadioButtonGroup(resultSet,"COURT_ACTN_TYPE_NM","ph.u4.drp.selected.optional.radio.button.item","Formal Action was brought in");
		rp.verifyDataWithUI(resultSet,"COURT_NM_TX","ph.u4.drp.input.span","Name of Court:", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		rp.verifyDataWithUI(resultSet,"COURT_LOC_TX","ph.u4.drp.input.span","Location of Court", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		rp.verifyDataWithUI(resultSet,"COURT_CASE_NB_TX","ph.u4.drp.input.span","Docket/Case#:", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		
		// Verify question 6
		rp.verifyDataWithUI(resultSet,"MPLYG_FIRM_TX","ph.u4.drp.input.span","Employing", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		
		// Verify question 7
		rp.verifyDataWithUI(resultSet,"ALGTN_TX","ph.u4.drp.input.span","Describe the allegations related to this civil action", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		
		// Verify question 8
		rp.verifyOptionalRadioButtonGroup(resultSet,"DSCLR_ST_TYPE_NM","ph.u4.drp.selected.optional.radio.button.item","Current Status");
		
		// Verify question 10
		rp.verifyDataWithUI(resultSet,"APPL_DTL_TX","ph.u4.drp.input.span","Action appealed to (provide name of court):", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		rp.verifyDataWithUI(resultSet,"COURT_DTL_TX","ph.u4.drp.input.span","Court Location:", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		rp.verifyDataWithUI(resultSet,"APPL_COURT_FLNG_DT","ph.u4.drp.input.span","Date appeal filed (MM/DD/YYYY):", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"APPL_COURT_FLNG_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date appeal filed (MM/DD/YYYY):");
		rp.verifyDataWithUI(resultSet,"APPL_DTL_TX","ph.u4.drp.input.span","Appeal details (including status):", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		rp.verifyDataWithUI(resultSet,"APPL_LMTNS_TX","ph.u4.drp.input.span","If on Appeal and any limitations or restrictions are currently in", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));		

		// Verify question 11
		rp.verifyOptionalRadioButtonGroup(resultSet,"CIVIL_JDCL_RSLTN_TYPE_NM","ph.u4.drp.selected.optional.radio.button.item","Resolution Detail:");

		// VCerify question 12
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_CIVIL_FINES_FL", "ph.u4.civil.drp.question12.checkbox.group", "Civil and Administrative Penalty(ies)/Fine(s)");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_CEASE_DSST_FL", "ph.u4.civil.drp.question12.checkbox.group", "Cease and Desist");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_DSGRT_FL", "ph.u4.civil.drp.question12.checkbox.group", "Disgorgement");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_MNTRY_PNLTY_FL", "ph.u4.civil.drp.question12.checkbox.group", "Monetary Penalty other than fines");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_RSTTN_FL", "ph.u4.civil.drp.question12.checkbox.group", "Restitution");
		rp.verifyCheckBoxFlag(resultSet, "SNCTN_INJTN_FL", "ph.u4.civil.drp.question12.checkbox.group", "Injunction");
		
		// Verify question 13
		rp.verifyDataWithUI(resultSet,"SM_TX","ph.u4.drp.input.span","Comment (Optional)", gp.getPropertyValue("crd.formtable.container","Civil Judicial DRP"));
		
	}

	
	/*
	 * cover 6/10 fields (60% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U6_Indvl_CivilJudicial_InjunctionDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U6");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.civil.injunction.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U6 filing search page
		 */
		nav.goToHistoricalU6Filings("CRD Individual");

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("ph.u4.drp.child.details.container","Injunction Details"));
		// Verify question 1 
		rp.verifyDataWithUI(resultSet,"DRTN_TX","ph.u4.drp.input.span","Duration (length of time):", gp.getPropertyValue("ph.u4.drp.child.details.container","Injunction Details"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"DRTN_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Duration (length of time):");
		
		// Verify question 2
		rp.verifyDataWithUI(resultSet,"START_DT","ph.u4.drp.input.span","Start Date (MM/DD/YYYY):", gp.getPropertyValue("ph.u4.drp.child.details.container","Injunction Details"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"START_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Start Date (MM/DD/YYYY):");
	
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"END_DT","ph.u4.drp.input.span","End Date (MM/DD/YYYY):", gp.getPropertyValue("ph.u4.drp.child.details.container","Injunction Details"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"END_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","End Date (MM/DD/YYYY):");
		
	}
	
	
	/*
	 * cover 3/9 fields (33% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U6_Indvl_CivilJudicial_MonetaryDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U6");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.civil.monetary.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U6 filing search page
		 */
		nav.goToHistoricalU6Filings("CRD Individual");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("ph.u4.drp.child.details.container","Monetary Related Sanction Details"));
		// Verify question 1
		rp.verifyDataWithUI(resultSet,"MNTRY_SNCTN_TYPE_NM","ph.u4.drp.input.span","Monetary Related Sanction Type:", gp.getPropertyValue("ph.u4.drp.child.details.container","Monetary Related Sanction Details"));
		
		// Verify question 4 
		rp.verifyDataWithUI(resultSet,"PH_MNTRY_SNCTN_CLLCT_DT","ph.u4.drp.input.span","Date paid by", gp.getPropertyValue("ph.u4.drp.child.details.container","Monetary Related Sanction Details"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"MNTRY_SNCTN_CLLCT_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date paid by");

	}
	
}
