package org.finra.automation.crd.printhistorical.u5;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_U5_TerminationDRP extends BaseTest {

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
    private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	@Test
	public void verifyTerminationDRPU5DRP05_2009() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U5");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.termination.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");	
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");	
		
		/*
		 * Use FormNavigation class to go to historical U5 filing search page
		 */
		nav.goToHistoricalU5Filings();

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		rp.verifyCheckBoxFlag(resultSet,"U5_TRMNN_DSCLR_F1_FL", "U5.historical.checkboxgroup", "7F(1)");
		rp.verifyCheckBoxFlag(resultSet,"U5_TRMNN_DSCLR_F2_FL", "U5.historical.checkboxgroup", "7F(2)");
		rp.verifyCheckBoxFlag(resultSet,"U5_TRMNN_DSCLR_F3_FL", "U5.historical.checkboxgroup", "7F(3)");
		rp.verifyDataWithUI(resultSet,"TRMNN_FIRM_NM","ph.u4.drp.input.span","Firm Name",gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		rp.verifyDataWithUI(resultSet,"TRMNN_TYPE_NM","ph.u4.drp.input.span","Termination Type", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		rp.verifyDataWithUI(resultSet,"ALGTN_TX","ph.u4.drp.input.span","Allegation", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		
		//rp.verifyDataWithUI(resultSet,"SM_TX","ph.u4.drp.input.span","brief summary of the circumstances leading to the termination", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
					
		  
	}
	@Test
	public void verifyTerminationDRPU5DRP_2003() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U5");
		sqlParameters.put("FORM_VRSN_TX", "06/2003");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.termination.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");	
		
		/*
		 * Login CRD as FINRA user
		 */
		String extraUrl = "/PGM/PageRouter.aspx?Action=ShowCRDFiling&FilingPK="+flng_pk;
		crd.crdLogin("crd.application.url","ARTFINRAJR", extraUrl);

			
		/*
		 * Go to DRP page
		 */
		LeftNavigation leftNav = new LeftNavigation();
		leftNav.selectItem("DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		rp.verifyCheckBoxFlag(resultSet,"U5_TRMNN_DSCLR_F1_FL", "U5.historical.checkboxgroup", "7F(1)");
		rp.verifyCheckBoxFlag(resultSet,"U5_TRMNN_DSCLR_F2_FL", "U5.historical.checkboxgroup", "7F(2)");
		rp.verifyCheckBoxFlag(resultSet,"U5_TRMNN_DSCLR_F3_FL", "U5.historical.checkboxgroup", "7F(3)");
		rp.verifyDataWithUI(resultSet,"TRMNN_FIRM_NM","ph.u4.drp.bankruptcy.br.text","Firm Name",gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		rp.verifyDataWithUI(resultSet,"TRMNN_TYPE_NM","ph.u4.drp.bankruptcy.br.text","Termination Type", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		rp.verifyDataWithUI(resultSet,"ALGTN_TX","ph.u4.drp.bankruptcy.br.text","Allegation", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		
		//rp.verifyDataWithUI(resultSet,"SM_TX","ph.u4.drp.input.span","brief summary of the circumstances leading to the termination", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
					
		  
	}

	
}
