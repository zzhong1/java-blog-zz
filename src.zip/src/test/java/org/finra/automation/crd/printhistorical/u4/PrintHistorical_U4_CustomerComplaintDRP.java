package org.finra.automation.crd.printhistorical.u4;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;



public class PrintHistorical_U4_CustomerComplaintDRP{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	/*
	 * cover 23/28 fields (82% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_CustomerComplaintDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.customercomplaint.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		// Verify checkboxes of 14I(1)(a), 14I(1)(b), 14I(1)(c), 14I(1)(d), 14I(2)(a), 14I(2)(b), 14I(3)(a), 14I(3)(b), 14I(4)(a), 14I(4)(b), 14I(5)(a), 14I(5)(b) 
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I1A_FL", "ph.u4.customer.complaint.drp.1", "1");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I1B_FL", "ph.u4.customer.complaint.drp.1", "2");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I1C_FL", "ph.u4.customer.complaint.drp.1", "3");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I1D_FL", "ph.u4.customer.complaint.drp.1", "4");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I2A_FL", "ph.u4.customer.complaint.drp.2", "1");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I2B_FL", "ph.u4.customer.complaint.drp.2", "2");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I3A_FL", "ph.u4.customer.complaint.drp.3", "1");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I3B_FL", "ph.u4.customer.complaint.drp.3", "2");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I4A_FL", "ph.u4.customer.complaint.drp.4", "1");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I4B_FL", "ph.u4.customer.complaint.drp.4", "2");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I5A_FL", "ph.u4.customer.complaint.drp.5", "1");
		rp.verifyCheckBoxFlag(resultSet, "U4_CSTMR_CMPLN_I5B_FL", "ph.u4.customer.complaint.drp.5", "2");
		
		// Verify question 1 
		rp.verifyDataWithUI(resultSet,"CSTMR_NM_TX","ph.u4.drp.input.span","Customer Name(s)", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		
		// Verify question 2
		rp.verifyDataWithUI(resultSet,"PH_STATE_NM","ph.u4.drp.input.span","Customer(s) State of Residence", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"MPLYG_FIRM_TX","ph.u4.drp.input.span","Employing", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		
		// Verify question 5
		rp.verifyCheckBoxFlag(resultSet, "NO_PRDCT_FL", "ph.u4.drp.question", "No Product");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_CHTBL_FL", "ph.u4.drp.question", "Annuity-Charitable");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_FIXED_FL", "ph.u4.drp.question", "Annuity-Fixed");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_VRBL_FL", "ph.u4.drp.question", "Annuity-Variable");
		rp.verifyCheckBoxFlag(resultSet, "BANKG_PRDCT_NO_CD_FL", "ph.u4.drp.question", "Banking Products");
		rp.verifyCheckBoxFlag(resultSet, "CMDTY_OPTN_FL", "ph.u4.drp.question", "Commodity Option");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_ASSET_BCKD_FL", "ph.u4.drp.question", "Debt-Asset Backed");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_CRPRT_FL", "ph.u4.drp.question", "Debt-Corporate");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_GOVT_FL", "ph.u4.drp.question", "Debt-Government");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_MNCPL_FL", "ph.u4.drp.question", "Debt-Municipal");
		rp.verifyCheckBoxFlag(resultSet, "DRVTV_FL", "ph.u4.drp.question", "Derivative");
		rp.verifyCheckBoxFlag(resultSet, "DRCT_NVSMT_DPP_LP_INTRS_FL", "ph.u4.drp.question", "Direct Investment-DPP");
		rp.verifyCheckBoxFlag(resultSet, "EQUIP_LSNG_FL", "ph.u4.drp.question", "Equipment Leasing");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_LSTD_FL", "ph.u4.drp.question", "Equity Listed");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_OTC_FL", "ph.u4.drp.question", "Equity-OTC");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_CMDTY_FL", "ph.u4.drp.question", "Futures Commodity");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_FNNCL_FL", "ph.u4.drp.question", "Futures-Financial");
		rp.verifyCheckBoxFlag(resultSet, "INDX_OPTN_FL", "ph.u4.drp.question", "Index Option");
		rp.verifyCheckBoxFlag(resultSet, "NSRNC_FL", "ph.u4.drp.question", "Insurance");
		rp.verifyCheckBoxFlag(resultSet, "NVSMT_CNTRC_FL", "ph.u4.drp.question", "Investment Contract");
		rp.verifyCheckBoxFlag(resultSet, "MONEY_MKT_FUND_FL", "ph.u4.drp.question", "Money Market Fund");
		rp.verifyCheckBoxFlag(resultSet, "MTL_FUND_FL", "ph.u4.drp.question", "Mutual Fund");
		rp.verifyCheckBoxFlag(resultSet, "OIL_GAS_FL", "ph.u4.drp.question", "Oil");
		rp.verifyCheckBoxFlag(resultSet, "OPTNS_FL", "ph.u4.drp.question", "Options");
		rp.verifyCheckBoxFlag(resultSet, "PNNY_STOCK_FL", "ph.u4.drp.question", "Penny Stock");
		rp.verifyCheckBoxFlag(resultSet, "PRIME_BANK_NTRMT_FL", "ph.u4.drp.question", "Prime Bank Instrument");
		rp.verifyCheckBoxFlag(resultSet, "PRMSY_NOTE_FL", "ph.u4.drp.question", "Promissory Note");
		rp.verifyCheckBoxFlag(resultSet, "RE_SCRTY_FL", "ph.u4.drp.question", "Real Estate Security");
		rp.verifyCheckBoxFlag(resultSet, "SCRTY_FTRS_FL", "ph.u4.drp.question", "Security Futures");
		rp.verifyCheckBoxFlag(resultSet, "UNIT_NVSMT_TRUST_FL", "ph.u4.drp.question", "Unit Investment Trust");
		rp.verifyCheckBoxFlag(resultSet, "VTCL_STLMT_FL", "ph.u4.drp.question", "Viatical Settlement");
		
		// Verify question 7
		rp.verifyYesNoButtonGroup(resultSet,"ORAL_CMPLN_FL","ph.u4.drp.yesno.radiogroup","Is this an oral complaint?");
		rp.verifyYesNoButtonGroup(resultSet,"WRITTEN_CMPLN_FL","ph.u4.drp.yesno.radiogroup","Is this a written complaint?");
		rp.verifyYesNoButtonGroup(resultSet,"ARBTN_LTGTN_FL","ph.u4.drp.yesno.radiogroup","Is this an arbitration/CFTC reparation or civil litigation?");
		rp.verifyDataWithUI(resultSet,"ARBTN_LTGTN_COURT_NM_LOC_TX","ph.u4.drp.input.span","If yes, provide:", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		rp.verifyDataWithUI(resultSet,"PH_ARBTN_LTGTN_FLNG_DT","ph.u4.drp.input.span","Filing date of arbitration/CFTC reparation", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		rp.verifyDataWithUI(resultSet,"PH_RCVD_DT","ph.u4.drp.input.span","Date received by/served on", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"RCVD_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date received by/served on");
		
		// Verify question 9
		rp.verifyCheckBoxFlag(resultSet, "CLSD_NO_ACTN_RSLTN_FL", "ph.u4.drp.question", "Closed/No Action");
		rp.verifyCheckBoxFlag(resultSet, "WTHDN_RSLTN_FL", "ph.u4.drp.question", "Withdrawn");
		rp.verifyCheckBoxFlag(resultSet, "DND_RSLTN_FL", "ph.u4.drp.question", "Denied");
		rp.verifyCheckBoxFlag(resultSet, "STTLD_RSLTN_FL", "ph.u4.drp.question", "Settled");
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_AWRD_CLMNTS_RSLTN_FL", "ph.u4.drp.question", "Arbitration Award/Monetary Judgment (for claimants/plaintiffs)");
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_AWRD_RSPDT_RSLTN_FL", "ph.u4.drp.question", "Arbitration Award/Monetary Judgment (for respondents/defendants)");
		rp.verifyCheckBoxFlag(resultSet, "EVLVD_ARBTN_RSLTN_FL", "ph.u4.drp.question", "Evolved into Arbitration/CFTC reparation (you are a named party)");
		rp.verifyCheckBoxFlag(resultSet, "EVLVD_LTGTN_RSLTN_FL", "ph.u4.drp.question", "Evolved into Civil litigation (you are a named party)");
		
		// Verify question 10
		rp.verifyDataWithUI(resultSet,"PH_ST_DT","ph.u4.drp.input.span","Status Date", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"ST_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Status Date");
		
		// Verify question 11
		rp.verifyDataWithUI(resultSet,"ARBTN_CLAIM_FILED_WITH_TX","ph.u4.drp.input.span","Arbitration/CFTC reparation claim filed with (FINRA, AAA, CFTC, etc.)", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		rp.verifyDataWithUI(resultSet,"PH_ARBTN_SRVC_DT","ph.u4.drp.input.span","Date notice/process was served", gp.getPropertyValue("crd.formtable.container","Customer Complaint DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"ARBTN_SRVC_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Date notice/process was served");
		
		// Verify question 12
		rp.verifyYesNoButtonGroup(resultSet,"ARBTN_PNDNG_FL","ph.u4.drp.yesno.radiogroup","Is arbitration/ CFTC reparation pending");
		
		// Verify question 14
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_DPSTN_AWRD_APLCT_FL", "ph.u4.drp.question", "Award to Applicant (Agent/Representative)");
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_DPSTN_AWRD_CUST_FL", "ph.u4.drp.question", "Award to Customer");
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_DPSTN_DND_FL", "ph.u4.drp.question", "Denied");
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_DPSTN_DSMSD_FL", "ph.u4.drp.question", "Dismissed");
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_DPSTN_JDGMT_FL", "ph.u4.drp.question", "Judgment (other than monetary)");
		rp.verifyCheckBoxFlag(resultSet, "ARBTN_DPSTN_NOACTN_FL", "ph.u4.drp.question", "No Action");

		
		
		
	}

	
}