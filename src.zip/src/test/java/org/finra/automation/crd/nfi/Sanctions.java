package org.finra.automation.crd.nfi;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.command.VerifyPageTitleCmd;
import org.finra.automation.crd_automation.common.CRDExtendedTable;
import org.finra.automation.crd_automation.datagen.RandomDataGenerator_CRD;

import org.finra.automation.crd_automation.ui.widget.CRDDropDown;
import org.finra.automation.crd_automation.ui.widget.CRDInput;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.ModalPopupButton;
import org.finra.automation.crd_automation.ui.widget.TopNavigation;
import org.finra.automation.crd_automation.ui.widget.TopNavigation.MenuBar;
import org.finra.automation.crd_automation.ui.widget.form.BDFormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.PopupPageContent;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.automation.radautomationcommon.widgets.WidgetTimer;
import org.finra.automation.radautomationcommon.widgets.WidgetTimer.IWidgetTimerCallback;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;

import qc.automation.framework.widget.WidgetException;
import qc.automation.framework.widget.element.Element;
import qc.automation.framework.widget.element.html.HyperLink;

public class Sanctions {
	
	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private LeftNavigation leftNav = new LeftNavigation();
	private FormNavigation nav = new FormNavigation();
	private TopNavigation tn = new TopNavigation();
	private MenuBar mb;
	private RandomDataGenerator_CRD randomData = new RandomDataGenerator_CRD();
	private PopupPageContent ppc;
	private FormMainContent fmc = new FormMainContent();
	private BDFormMainContent bmc = new BDFormMainContent();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	@Test
	public void verifyAddEditDeleteSanctionRR() throws Exception {
		System.out.println("***** Starting Test NFI Sanction Page ****");
		System.out.println("***** Verify that a sanction can be added, edited and deleted successfully for a RR Individual ****");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.snctn.find.rr.indvl",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");

		
//		String indvl_pk = "6411509";
		System.out.println("Indvl_pk = " + indvl_pk);
		
		verifySanction(indvl_pk);
			
	}
	
	@Test
	public void verifyAddEditDeleteSanctionJoint() throws Exception {
		System.out.println("***** Starting Test NFI Sanction Page ****");
		System.out.println("***** Verify that a sanction can be added, edited and deleted successfully for a Joint Individual ****");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.snctn.find.joint.indvl",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");

		
//		String indvl_pk = "6411509";
		System.out.println("Indvl_pk = " + indvl_pk);
		
		verifySanction(indvl_pk);
			
	}
	
	@Test
	public void verifyAddEditDeleteSanctionIAOnly() throws Exception {
		System.out.println("***** Starting Test NFI Sanction Page ****");
		System.out.println("***** Verify that a sanction can be added, edited and deleted successfully for a IA Only Individual ****");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.snctn.find.ia.indvl",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");

		
//		String indvl_pk = "6411509";
		System.out.println("Indvl_pk = " + indvl_pk);
		
		verifySanction(indvl_pk);
			
	}
	
	@Test
	public void verifyAddEditDeleteSanctionPage2() throws Exception {
		System.out.println("***** Starting Test NFI Sanction Page ****");
		System.out.println("***** Verify that a sanction can be added, edited and deleted successfully for a Page2 Individual ****");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "249");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.snctn.find.page2.indvl",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");

		
//		String indvl_pk = "6411509";
		System.out.println("Indvl_pk = " + indvl_pk);
		
		verifySanction(indvl_pk);
			
	}
	
	@Test
	public void verifyAddEditDeleteSanctionBackOfc() throws Exception {
		System.out.println("***** Starting Test NFI Sanction Page ****");
		System.out.println("***** Verify that a sanction can be added, edited and deleted successfully for a Back Office Individual ****");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.snctn.find.backoffice.indvl",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");

		
//		String indvl_pk = "6411509";
		System.out.println("Indvl_pk = " + indvl_pk);
		
		verifySanction(indvl_pk);
			
	}
	
	public void verifySanction(String indvl_pk) throws Exception {
		System.out.println("***** Verify that a sanction can be added successfully ****");
		
		String initiatingRegulator = "FINRA";
		String sanctionType = "Full Bar (FINRA)";
		String capacityType = "All Capacity";
		String startDate = randomData.currentDate("MM/DD/YYYY", 1);
		String endDate = randomData.currentDate("MM/DD/YYYY", 2);
		String comments = "Comment" + randomData.number(5);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to individual NFI Page
		 */
		
		nav.goToIndividualPage();
		mb = tn.getSubMenuBar();
		mb.selectItem("Non-Filing Info");

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		CRDSearch crdSearch = new CRDSearch("CRD Individual Search");
		crdSearch.doSearch(searchCriteria);
		/*
		 * Navigate to Sanctions Page
		 */
		leftNav.selectItem("Sanctions");				
		
		/*
		 * Add new sanction
		 */		
		bmc.clickButton("Add");	
		
		addSanctions(initiatingRegulator,sanctionType,capacityType,startDate,endDate,comments);
		
		/*
		 * Verify in DB that the sanction has been successfully added
		 */
		Map<String, Object> sqlParameters2 = new HashMap<String, Object>();
		sqlParameters2.put("INDVL_PK", indvl_pk);
		sqlParameters2.put("COMMENT_TEXT", comments);
		SqlExecutor se2 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet2 = se2.executeForStrings("nfi.indvl.snctn.count",sqlParameters2);
		int record_count = Integer.parseInt(resultSet2.get(0).get("record_count"));		
		
		Assert.assertEquals("Failed !! The new sanction was NOT added successfully", 1, record_count);
		
		/*
		 * Verify in DB that the capacity is set as expected
		 */
		Map<String, Object> sqlParameters_recVerification = new HashMap<String, Object>();
		sqlParameters_recVerification.put("INDVL_PK", indvl_pk);
		sqlParameters_recVerification.put("COMMENT_TEXT", comments);
		SqlExecutor se_recVerification = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> rs_recVerification = se_recVerification.executeForStrings("nfi.indvl.snctn.record.verification",sqlParameters_recVerification);
		String capacity_Type = rs_recVerification.get(0).get("CAPACITY");		
		
		Assert.assertTrue("Failed !! The Capacity is NOT set correctly. Actual " + capacity_Type + " Expected : ALL", capacity_Type.equalsIgnoreCase("ALL"));
		
//		//verify sanctions table on UI
//		Map<String, Object> sqlParameters3 = new HashMap<String, Object>();
//		sqlParameters3.put("ORG_PK", org_pk);
//		SqlExecutor se3 = new SqlExecutor("main", System.getProperty("target"));
//		List<Map<String, String>> resultSet3 = se3.executeForStrings("fprd.org.reg.history",sqlParameters3);
//		CRDExtendedTable crdExtendedTable = new CRDExtendedTable(gp.getPropertyValue("fprd.table", "FPContent_grdRegistrationHistory")); 
//		List<Map<String, String>> uiInfo = crdExtendedTable.getTableDataInMap();
//		org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy policy = org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy.valueOf("AnyOrder");
//		org.finra.test.tools.commons.comparator.Assert.assertCompare(uiInfo, resultSet3, policy, "comparisonResult");
		
		System.out.println("***** Verify that a sanction can be edited successfully ****");
		
		
		clickSanctionActionLink(comments,"Edit");
		
		comments = "Comment" + randomData.number(5);
		capacityType = "Principal Capacity";
		addSanctions(initiatingRegulator,sanctionType,capacityType,startDate,endDate,comments);
		
		/*
		 * Verify in DB that the sanction has been successfully edited
		 */
		Map<String, Object> sqlParameters3 = new HashMap<String, Object>();
		sqlParameters3.put("INDVL_PK", indvl_pk);
		sqlParameters3.put("COMMENT_TEXT", comments);
		SqlExecutor se3 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet3 = se3.executeForStrings("nfi.indvl.snctn.count",sqlParameters3);
		int record_count_edit = Integer.parseInt(resultSet3.get(0).get("record_count"));	
		
		Assert.assertEquals("Failed !! The new sanction was NOT edited successfully", 1, record_count_edit);
		
		/*
		 * Verify in DB that the capacity is set as expected
		 */
		Map<String, Object> sqlParameters_recVerification2 = new HashMap<String, Object>();
		sqlParameters_recVerification2.put("INDVL_PK", indvl_pk);
		sqlParameters_recVerification2.put("COMMENT_TEXT", comments);
		SqlExecutor se_recVerification2 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> rs_recVerification2 = se_recVerification2.executeForStrings("nfi.indvl.snctn.record.verification",sqlParameters_recVerification2);
		String capacity_Type2 = rs_recVerification2.get(0).get("CAPACITY");		
		
		Assert.assertTrue("Failed !! The Capacity is NOT set correctly. Actual " + capacity_Type2 + " Expected : PRNCL", capacity_Type2.equalsIgnoreCase("PRNCL"));
		
		
		System.out.println("***** Verify that a sanction can be deleted successfully ****");
		
		clickSanctionActionLink(comments,"Delete");
		
		/*
		 * Verify in DB that the sanction has been successfully edited
		 */
		Map<String, Object> sqlParameters4 = new HashMap<String, Object>();
		sqlParameters4.put("INDVL_PK", indvl_pk);
		sqlParameters4.put("COMMENT_TEXT", comments);
		SqlExecutor se4 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet4 = se4.executeForStrings("nfi.indvl.snctn.delete.verification",sqlParameters4);
		int record_count_delete = Integer.parseInt(resultSet4.get(0).get("record_count"));
		
		Assert.assertEquals("Failed !! The new sanction was NOT deleted successfully", 1, record_count_delete);
		
		System.out.println("***** Ending Test NFI Sanction Page ****");
		System.out.println("***** ***** ***** ***** ***** ***** ***** ***** ****");
			
	}
	
	public void addSanctions(String initiateReg, String sanType, String capacity, String startDate, String endDate, String comments)throws Exception{
		
		String initiateRegListLoc = gp.getPropertyValue("crd.select", "Regulator");
		String sanTypeListLoc = gp.getPropertyValue("crd.select", "SanctionType");
		String capacityListLoc = gp.getPropertyValue("crd.select", "CapacityType");
		String startDateTxtLoc = gp.getPropertyValue("crd.input", "StartDate");
		String endDateTxtLoc = gp.getPropertyValue("crd.input", "EndDate");
		String commentsTxtLoc = gp.getPropertyValue("crd.textarea", "Notes");
		
		
		ModalPopupButton btn = new ModalPopupButton(gp.getPropertyValue("sanction.save.button"));
		
		WidgetTimer waitLoading = new WidgetTimer(new IWidgetTimerCallback() {
			public boolean execute() throws WidgetException {
				
				try {
					Element popupContainer = new Element(gp.getPropertyValue("sanction.popuptitle"));
					return (popupContainer.isElementPresent() && popupContainer.isElementVisible());
				} catch (WidgetException e) {	} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				return false;
			}
			public String toString() {
				return "After clicking the modal popup button, failed to find the modal popup container.";
			}
		});
		waitLoading.waitUntill(60000);
		
		CRDDropDown initiateRegList = new CRDDropDown(initiateRegListLoc);
		CRDDropDown sanTypeList = new CRDDropDown(sanTypeListLoc);
		CRDDropDown capacityList = new CRDDropDown(capacityListLoc);
		
		CRDInput startDateTxt = new CRDInput(startDateTxtLoc);
		CRDInput endDateTxt = new CRDInput(endDateTxtLoc);	
//		CRDInput commentsTxt = new CRDInput(commentsTxtLoc);	
		
		try {
			initiateRegList.selectOption(initiateReg);
			sanTypeList.selectOption(sanType);
			capacityList.selectOption(capacity);
			
//			commentsTxt.setValue(comments);
			fmc.inputText("txtNotes", comments);
			startDateTxt.setValue(startDate);
			endDateTxt.setValue(endDate);
			
//			fmc.inputText("txtStartDate", startDate);
//			fmc.inputText("txtEndDate", endDate);
			
			
			btn.setValue("click");
			waitForMainPageLoading();
			
		} catch (WidgetException e) {e.printStackTrace();}
		
	}
	
	public void clickSanctionActionLink(String uniqueID, String action) throws WidgetException {
		String baseLoc;
		try {
			baseLoc = gp.getPropertyValue("sanction.table");
			String linkLoc = gp.getPropertyValue("sanction.action", baseLoc, uniqueID, action);
			
			HyperLink linkSanctionAction = new HyperLink(linkLoc);
			
			linkSanctionAction.waitForElementPresent();
			linkSanctionAction.click();
			
			if(action.equalsIgnoreCase("delete"))
			{
				clickWarningDialog("Confirm Delete");
				waitForMainPageLoading();
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void clickWarningDialog(String btnName) throws WidgetException {
		String warningLoc;
		try {
			warningLoc = gp.getPropertyValue("sanction.popup.warning.dialog");
			ModalPopupButton btn = new ModalPopupButton(gp.getPropertyValue("sanction.popup.button", warningLoc,  btnName));
			btn.setValue("click");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void waitForMainPageLoading() throws WidgetException {
		WidgetTimer waitLoading = new WidgetTimer(new IWidgetTimerCallback() {
			public boolean execute() throws WidgetException {
				
				try {
					Element popupContainer = new Element(gp.getPropertyValue("sanction.container"));
					return (popupContainer.isElementPresent() && popupContainer.isElementVisible());
				} catch (WidgetException e) {	} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				return false;
			}
			public String toString() {
				return "After closing the modal popup, failed to find the main page container.";
			}
		});
		waitLoading.waitUntill(60000);
		
	}

}
