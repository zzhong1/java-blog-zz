package org.finra.automation.crd.printhistorical.br;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_BR{

	final static GUIProperties gp = new GUIProperties("crd/br.gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * RAD-81828. Verify some fields in the BR PH mode using page router url
	 */
	@Test
	public void verifyPrintHistorical_BR_PageRouting() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_VRSN_TX", "10/2005");
		sqlParameters.put("ACTN_CD", "N");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.br.other.bus.name",sqlParameters);
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		String extraUrl = "/PGM/PageRouter.aspx?Action=ShowCRDFiling&FilingPK="+flng_pk;
		crd.crdLogin("crd.application.url","ARTFINRAJR", extraUrl);

		LeftNavigation leftNav = new LeftNavigation();
		leftNav.selectItem("3. Types of Activities/ Other Business Names/ Websites");
		
		/*
		 * Verify BR Other Business Name UI data in PH mode against with DB
		 */
		ReadOnlyPageWidget rp = new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","3. TYPES OF ACTIVITIES/OTHER BUSINESS NAMES/WEBSITES"));
		
		rp.verifyDataWithUI(resultSet,"OTHER_BUS_NM","ph.br.table.text","grdOtherNames");
	}


	/*
	 * RAD-81828. Verify some fields in the BR RedLine mode using page router url
	 */
	@Test
	public void verifyPrintHistorical_BR_PageRoutingRedLine() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_VRSN_TX", "10/2005");
		sqlParameters.put("ACTN_CD", "U");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.br.other.bus.name",sqlParameters);
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		String extraUrl = "/PGM/PageRouter.aspx?Action=ShowCRDFiling&FilingPK="+flng_pk;
		crd.crdLogin("crd.application.url","ARTFINRAJR", extraUrl);

		LeftNavigation leftNav = new LeftNavigation();
		leftNav.selectItem("View Changes From Previous Filing");
		leftNav.selectItem("3. Types of Activities/ Other Business Names/ Websites");
		
		/*
		 * Verify BR Other Business Name UI data in PH mode against with DB
		 */
		ReadOnlyPageWidget rp = new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","3. TYPES OF ACTIVITIES/OTHER BUSINESS NAMES/WEBSITES"));
		
		rp.verifyDataWithUI(resultSet,"OTHER_BUS_NM","ph.br.table.text","grdOtherNames");
	}
	
	
}
