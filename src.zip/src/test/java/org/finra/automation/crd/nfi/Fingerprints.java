package org.finra.automation.crd.nfi;

/*
 * This VerifyNFIFingerPrintSummary_INDVL class is used for testing the following functionalities on 
 * Individual NFI FingerPrint Page
 *  1)	Verify that the New link is not available for INACTIVE firms as a FINRA user
 *  2)	Verify that the New link is available for INACTIVE firms as a Corrections user
 *  3)	Verify that an audit record is created (FINRA/Corrections) when the user views 
 *      the FP summary page with barcode in active statuses
 * 
 */
/**
 * @author Balaji Kuganesan
 *
 */

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.datagen.RandomDataGenerator_CRD;
import org.finra.automation.crd_automation.ui.widget.FingerPrintSummary;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.TopNavigation;
import org.finra.automation.crd_automation.ui.widget.TopNavigation.MenuBar;
import org.finra.automation.crd_automation.ui.widget.form.PopupPageContent;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;

public class Fingerprints {
	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private LeftNavigation leftNav = new LeftNavigation();
	private FormNavigation nav = new FormNavigation();
	private TopNavigation tn = new TopNavigation();
	private MenuBar mb;
	private FingerPrintSummary fps = new FingerPrintSummary();
	private RandomDataGenerator_CRD randomData = new RandomDataGenerator_CRD();
	private PopupPageContent ppc;
	/*
	 * Login as FINRA user
	 * Navigate to Individual NFI FingerPrint Page 
	 * Verify that the New link is NOT displayed for Inactive firm association
	 */
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	@Test
	public void verifyNewLinkForInactiveIndvl_FINRAuser() throws Exception {
		System.out.println("***** Starting Test NFI FingerPrint Summary Page ****");
		System.out.println("***** Verify that the 'New' link is not available for INACTIVE firms as a FINRA user ****");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.fp.summary.inactiveifa",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");

		System.out.println("Indvl_pk = " + indvl_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		
		nav.goToIndividualPage();
		mb = tn.getSubMenuBar();
		mb.selectItem("Non-Filing Info");

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		CRDSearch crdSearch = new CRDSearch("CRD Individual Search");
		crdSearch.doSearch(searchCriteria);
		/*
		 * Navigate to FingerPrint Card Summary Page
		 */
		leftNav.selectItem("Fingerprint Cards");	
		/*
		 * Check if the New link is not present for a FINRA user
		 */
		Assert.assertFalse("Failed !! The New link is available for FINRA user", fps.checkActionLinkPresent("877"));
		
		System.out.println("***** Ending Test NFI FingerPrint Summary Page ****");
		System.out.println("***** ***** ***** ***** ***** ***** ***** ***** ****");
			
	}
	
	@Test
	public void verifyNewLinkForInactiveIndvl_CorrUser() throws Exception {
		System.out.println("***** Starting Test NFI FingerPrint Summary Page ****");
		System.out.println("***** Verify that the 'New' link is available for INACTIVE firms as a Corrections user ****");
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.fp.summary.inactiveifa",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");

		System.out.println("Indvl_pk = " + indvl_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTCORR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		
		nav.goToIndividualPage();
		mb = tn.getSubMenuBar();
		mb.selectItem("Non-Filing Info");

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		CRDSearch crdSearch = new CRDSearch("CRD Individual Search");
		crdSearch.doSearch(searchCriteria);
		/*
		 * Navigate to FingerPrint Card Summary Page
		 */
		leftNav.selectItem("Fingerprint Cards");	
		/*
		 * Check if the New link is present for a Corrections user for INACTIVE individual
		 */
		Assert.assertTrue("Failed !! The New link is NOT available for Correction user", fps.checkActionLinkPresent("877"));
		System.out.println("***** Ending Test NFI FingerPrint Summary Page ****");
		System.out.println("***** ***** ***** ***** ***** ***** ***** ***** ****");
			
	}
	
	/*
	 * RAD-81889 Verify FP Rap Sheet Upload page
	 */
	@Test
	public void verifyUploadRapSheet_FINRAUser() throws Exception {

		String popupTitleName = "Upload RAP Sheet";
		String expectedMsg = "There is no file selected for upload";
		String expectedMsg1 = "The \"Received Date\" cannot be a future date";
		String expectedMsg2 = "The \"Status Date\" cannot be a future date";
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("nfi.indvl.fp.upload.rapp.sheet");
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String fngpr_card_pk = resultSet.get(0).get("FNGPR_CARD_PK");
		String barcode = resultSet.get(0).get("FNGPR_CARD_BAR_CD");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FNGPR_CARD_PK = " + fngpr_card_pk);
		System.out.println("FNGPR_CARD_BAR_CD = " + barcode);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToIndividualPage();
		mb = tn.getSubMenuBar();
		mb.selectItem("Non-Filing Info");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		CRDSearch crdSearch = new CRDSearch("CRD Individual Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Navigate to FingerPrint Card Summary Page
		 */
		leftNav.selectItem("Fingerprint Cards");
		
		/*
		 * Verify error message : There is no file selected for upload
		 */
		fps.clickFPActionLink(barcode, "Upload");
		fps.verifyPopupTitle(popupTitleName);
		ppc = new PopupPageContent("modalPopupEditor");
		ppc.clickButton("Save");
		fps.waitForModalPageLoading();
		
		fps.clickModalPopupButton("Upload");
		fps.waitForModalPageLoading();
		Assert.assertTrue("Failed to find the error message : " + expectedMsg , fps.getErrorMessage().contains(expectedMsg));
		fps.closeModalPopupPage();
		
		/*
		 * Verify error message : The "Received Date" cannot be a future date
		 */		
		fps.clickFPActionLink(barcode, "Upload");
		fps.waitForModalPageLoading();
		
		fps.enterInputText(randomData.currentDate("MM/DD/YYYY", 1), "txtRecvDate");
		fps.clickModalPopupButton("Upload");
		Assert.assertTrue("Failed to find the error message : " + expectedMsg1 , fps.getErrorMessage().contains(expectedMsg1));
		fps.closeModalPopupPage();
		
		/*
		 * Verify error message : The "Status Date" cannot be a future date
		 */		
		fps.clickFPActionLink(barcode, "Upload");
		fps.waitForModalPageLoading();
		
		fps.enterInputText(randomData.currentDate("MM/DD/YYYY", 1), "txtStatusDate");
		fps.clickModalPopupButton("Upload");
		Assert.assertTrue("Failed to find the error message : " + expectedMsg2 , fps.getErrorMessage().contains(expectedMsg2));
		fps.closeModalPopupPage();
		
		/*
		 * Verify the process of uploading the Rap Sheet
		 */
		fps.clickFPActionLink(barcode, "Upload");
		fps.uploadRapSheet(randomData.currentDate(), randomData.currentDate());
		
		
	}
	
}
