package org.finra.automation.crd.printhistorical.u4;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;



public class PrintHistorical_U4_TerminaionDRP{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	/*
	 * cover 81/113 fields (72% coverage)
	 */
	@Test
	public void verifyPrintHistorical_U4_TerminationDRP() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U4");
		sqlParameters.put("FORM_VRSN_TX", "05/2009");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.termination.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");

		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToHistoricalU4Filings();

		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		//Verify checkboxes of 14J(1), 14J(2), 14J(3)
		rp.verifyCheckBoxFlag(resultSet, "U4_TRMNN_DSCLR_J1_FL", "ph.u4.drp.question", "14J(1)");
		rp.verifyCheckBoxFlag(resultSet, "U4_TRMNN_DSCLR_J2_FL", "ph.u4.drp.question", "14J(2)");
		rp.verifyCheckBoxFlag(resultSet, "U4_TRMNN_DSCLR_J3_FL", "ph.u4.drp.question", "14J(3)");
		
		// Verify question 2
		rp.verifyDataWithUI(resultSet,"TRMNN_TYPE_NM","ph.u4.drp.input.span","Termination Type:", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		
		// Verify question 3
		rp.verifyDataWithUI(resultSet,"PH_TRMNN_DT","ph.u4.drp.input.span","Termination Date", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		rp.verifyExactExplanationRadioButtonGroup(resultSet,"TRMNN_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group","Termination Date");
		
		// Verify question 5
		rp.verifyCheckBoxFlag(resultSet, "NO_PRDCT_FL", "ph.u4.termination.drp.question.5", "No Product");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_CHTBL_FL", "ph.u4.termination.drp.question.5", "Annuity-Charitable");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_FIXED_FL", "ph.u4.termination.drp.question.5", "Annuity-Fixed");
		rp.verifyCheckBoxFlag(resultSet, "ANNTY_VRBL_FL", "ph.u4.termination.drp.question.5", "Annuity-Variable");
		rp.verifyCheckBoxFlag(resultSet, "BANKG_PRDCT_NO_CD_FL", "ph.u4.termination.drp.question.5", "Banking Products (other than CDs)");
		rp.verifyCheckBoxFlag(resultSet, "CMDTY_OPTN_FL", "ph.u4.termination.drp.question.5", "Commodity Option");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_ASSET_BCKD_FL", "ph.u4.termination.drp.question.5", "Debt-Asset Backed");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_CRPRT_FL", "ph.u4.termination.drp.question.5", "Debt-Corporate");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_GOVT_FL", "ph.u4.termination.drp.question.5", "Debt-Government");
		rp.verifyCheckBoxFlag(resultSet, "DEBT_MNCPL_FL", "ph.u4.termination.drp.question.5", "Debt-Municipal");
		rp.verifyCheckBoxFlag(resultSet, "DRVTV_FL", "ph.u4.termination.drp.question.5", "Derivative");
		rp.verifyCheckBoxFlag(resultSet, "DRCT_NVSMT_DPP_LP_INTRS_FL", "ph.u4.termination.drp.question.5", "Direct Investment-DPP");
		rp.verifyCheckBoxFlag(resultSet, "EQUIP_LSNG_FL", "ph.u4.termination.drp.question.5", "Equipment Leasing");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_LSTD_FL", "ph.u4.termination.drp.question.5", "Equity Listed");
		rp.verifyCheckBoxFlag(resultSet, "EQTY_OTC_FL", "ph.u4.termination.drp.question.5", "Equity-OTC");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_CMDTY_FL", "ph.u4.termination.drp.question.5", "Futures Commodity");
		rp.verifyCheckBoxFlag(resultSet, "FTRS_FNNCL_FL", "ph.u4.termination.drp.question.5", "Futures-Financial");
		rp.verifyCheckBoxFlag(resultSet, "INDX_OPTN_FL", "ph.u4.termination.drp.question.5", "Index Option");
		rp.verifyCheckBoxFlag(resultSet, "NSRNC_FL", "ph.u4.termination.drp.question.5", "Insurance");
		rp.verifyCheckBoxFlag(resultSet, "NVSMT_CNTRC_FL", "ph.u4.termination.drp.question.5", "Investment Contract");
		rp.verifyCheckBoxFlag(resultSet, "MONEY_MKT_FUND_FL", "ph.u4.termination.drp.question.5", "Money Market Fund");
		rp.verifyCheckBoxFlag(resultSet, "MTL_FUND_FL", "ph.u4.termination.drp.question.5", "Mutual Fund");
		rp.verifyCheckBoxFlag(resultSet, "OIL_GAS_FL", "ph.u4.termination.drp.question.5", "Oil");
		rp.verifyCheckBoxFlag(resultSet, "OPTNS_FL", "ph.u4.termination.drp.question.5", "Options");
		rp.verifyCheckBoxFlag(resultSet, "PNNY_STOCK_FL", "ph.u4.termination.drp.question.5", "Penny Stock");
		rp.verifyCheckBoxFlag(resultSet, "PRIME_BANK_NTRMT_FL", "ph.u4.termination.drp.question.5", "Prime Bank Instrument");
		rp.verifyCheckBoxFlag(resultSet, "PRMSY_NOTE_FL", "ph.u4.termination.drp.question.5", "Promissory Note");
		rp.verifyCheckBoxFlag(resultSet, "RE_SCRTY_FL", "ph.u4.termination.drp.question.5", "Real Estate Security");
		rp.verifyCheckBoxFlag(resultSet, "SCRTY_FTRS_FL", "ph.u4.termination.drp.question.5", "Security Futures");
		rp.verifyCheckBoxFlag(resultSet, "UNIT_NVSMT_TRUST_FL", "ph.u4.termination.drp.question.5", "Unit Investment Trust");
		rp.verifyCheckBoxFlag(resultSet, "VTCL_STLMT_FL", "ph.u4.termination.drp.question.5", "Viatical Settlement");		
		
		// Verify question 6
		rp.verifyDataWithUI(resultSet,"SM_TX","ph.u4.drp.input.span","Comment (Optional)", gp.getPropertyValue("crd.formtable.container","Termination DRP"));
		
		
		
	}

	
}
