package org.finra.automation.crd.printhistorical.u5;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;



public class PrintHistorical_U5_CustomerComplaintDRP extends BaseTest {

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormNavigation nav = new FormNavigation();
	private Login crd=new Login();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	@Test
	public void verifyCustomerComplaintU5DRP10_2005() throws Exception {
		
		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FORM_TYPE_CD", "U5");
		sqlParameters.put("FORM_VRSN_TX", "10/2005");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("ph.u4u5.customercomplaint.2009.05",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");	
		
		/*
		 * Use FormNavigation class to go to historical U5 filing search page
		 */
		nav.goToHistoricalU5Filings();
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", indvl_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Go to DRP page
		 */
		nav.goToFilingPage(flng_pk, "DRPs");
		
		/*
		 * Start to verify UI data against with DB
		 */
		ReadOnlyPageWidget rp=new ReadOnlyPageWidget(gp.getPropertyValue("crd.formtable.container"));		
		rp.verifyDataWithUI(resultSet, "CSTMR_NM_TX", "u5.historical.drp", "1.");
		rp.verifyDataWithUI(resultSet, "MPLYG_FIRM_TX", "u5.historical.drp", "Employing Firm");

		rp.verifyDataWithUI(resultSet, "ALGTN_TX", "u5.historical.drp", "brief summary of events related to the allegation");

		rp.verifyCheckBoxFlag(resultSet, "ARBTN_RSLTN_FL","U5.historical.checkboxgroup", "Arbitration/Reparation");
		rp.verifyCheckBoxFlag(resultSet, "LTGTN_RSLTN_FL","U5.historical.checkboxgroup", "Litigation");
		rp.verifyCheckBoxFlag(resultSet, "CLSD_NO_ACTN_RSLTN_FL","U5.historical.checkboxgroup", "No Action");
		rp.verifyCheckBoxFlag(resultSet, "WTHDN_RSLTN_FL",	"U5.historical.checkboxgroup", "Withdrawn");
		rp.verifyCheckBoxFlag(resultSet, "DND_RSLTN_FL", "U5.historical.checkboxgroup", "Denied");
		rp.verifyCheckBoxFlag(resultSet, "STTLD_RSLTN_FL","U5.historical.checkboxgroup", "Settled");

		rp.verifyDataWithUI(resultSet, "PH_ST_DT", "u5.historical.drp","Status Date");
		
		rp.verifyExactExplanationRadioButtonGroup(resultSet, "ST_DT_EXACT_FL", "ph.u4.drp.exact.explanation.radio.button.group", "Status Date");
		rp.verifyDataWithUI(resultSet, "ARBTN_CLAIM_FILED_DTL_TX","u5.historical.drp",	"Arbitration/Reparation claim filed with FINRA");
		rp.verifyDataWithUI(resultSet, "PH_ARBTN_SRVC_DT", "u5.historical.drp","process was served");
		rp.verifyExactExplanationRadioButtonGroup(resultSet, "ARBTN_SRVC_DT_EXACT_FL","ph.u4.drp.exact.explanation.radio.button.group", "Date notice");

		rp.verifyDataWithUI(resultSet, "ARBTN_DPSTN_DT", "u5.historical.drp","17.");
		rp.verifyExactExplanationRadioButtonGroup(resultSet, "ARBTN_DPSTN_DT_EXACT_FL",	"ph.u4.drp.exact.explanation.radio.button.group", "Disposition Date");
		rp.verifyDataWithUI(resultSet, "ARBTN_MNTRY_CMPNS_AM","u5.historical.drp", "18.");
		rp.verifyDataWithUI(resultSet, "RSLTN_DPSTN_TX", "u5.historical.drp","28.");
	}
		
	

	

	
}
