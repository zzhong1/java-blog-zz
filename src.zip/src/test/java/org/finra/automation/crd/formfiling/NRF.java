package org.finra.automation.crd.formfiling;


import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.finra.automation.crd.junit.pageobjectmodel.FormFiling;
import org.finra.automation.junit.base.BaseTest;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class NRF{

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private FormFiling ff;
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * Submit an NRF-Initial filing through WebEFT via HttpRequest
	 */
	@Test
	public void createNewNRFInitial() throws Throwable {
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitNRFInitial by parameters are passed
		 */
		ff = new FormFiling("NRF_Initial");
		ff.setSubmitDateAsCurrentDate();
		ff.submitNRFInitial();
		String indvl_pk = ff.getIndvl_pk();
		String flng_pk = ff.getFlng_pk();
		// do whatever you want
	}

	/*
	 * Submit an NRF-Amendment filing through WebEFT via HttpRequest
	 */
	@Test
	public void createNRFAmendment() throws Throwable {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", "877");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("find.nrf.indvl.for.amend",sqlParameters);
		String indvl_pk = resultSet.get(0).get("INDVL_PK");
		String ssn_nb = resultSet.get(0).get("SSN_NB");
		System.out.println("INDVL_PK = " + indvl_pk);
		System.out.println("SSN_NB = " + ssn_nb);
		
		/*
		 * Initiate a FormFiling object by the form type is given
		 * Set the submit date is current date
		 * Call submitNRFAmendment by parameters are passed
		 */
		ff = new FormFiling("NRF_Amendment");
		ff.setSubmitDateAsCurrentDate();
		ff.submitNRFAmendment(indvl_pk, ssn_nb);
		// do whatever you want
	}

}
