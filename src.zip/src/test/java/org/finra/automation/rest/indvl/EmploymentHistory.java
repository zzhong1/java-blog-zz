package org.finra.automation.rest.indvl;

import static com.jayway.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import com.jayway.jsonpath.JsonPath;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.finra.automation.junit.base.BaseTest;
import org.finra.test.tools.db.SqlExecutor;
import org.finra.test.tools.db.exceptions.DatabaseException;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.Response;
import static java.util.concurrent.TimeUnit.*;

import static org.junit.Assert.*;
/**
 * @Author Divya Ganti 
 *
 */

public class EmploymentHistory {

	int port = 5000;

	public static Response response;
	public static String jsonAsString;

	@Before
	public void setUp() {
		RestAssured.port = port;
		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
	}
	
	@Rule
	public BaseTest basetest = new BaseTest();

	@Test
	public void schemaValidationTestendpoint1() throws DatabaseException {

		/*
		 * Prepare sql parameters and execute sql
		 */
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se1
				.executeForStrings("emplthist.dtls");
		String indvl_pk1 = resultSet.get(0).get("INDVL_PK");
		int indvl_pk = Integer.parseInt(indvl_pk1);

		given().when()
				.get("/api/v1/individuals/{individualId}/employment-history",
						indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body(JsonSchemaValidator
						.matchesJsonSchemaInClasspath("EmpHistory.json"));
	}

	@Test
	public void schemaValidationTestendpoint2() throws DatabaseException {

		/*
		 * Prepare sql parameters and execute sql
		 */
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se1
				.executeForStrings("emplthist.dtls");
		String indvl_pk1 = resultSet.get(0).get("INDVL_PK");
		int indvl_pk = Integer.parseInt(indvl_pk1);

		given().when()
				.get("/api/v1/Individuals/{individualId}?section=employment-history",indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body(JsonSchemaValidator
						.matchesJsonSchemaInClasspath("EmpHistory.json"));
	}

	@Test
	public void empHistDtlsTest() throws DatabaseException, ParseException {
		/*
		 * Prepare sql parameters and execute sql
		 */
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se
				.executeForStrings("emplthist.dtls");
		String org_nm = resultSet.get(0).get("MPLYR_NM");
		String indvl_pk1 = resultSet.get(0).get("INDVL_PK");
		int indvl_pk = Integer.parseInt(indvl_pk1);
		String startdate = (resultSet.get(0).get("EMP_START_DT").isEmpty())?null:resultSet.get(0).get("EMP_START_DT");
		String enddate = (resultSet.get(0).get("EMP_END_DT").isEmpty())?null:resultSet.get(0).get("EMP_END_DT");
		String posn = resultSet.get(0).get("PSTN_HELD_TX");
		String invstmntfl = resultSet.get(0).get("NVSMT_RLTD_FL");
		String city = resultSet.get(0).get("MPLYR_CITY_NM");
		String state = resultSet.get(0).get("STATE");
		String cntrycd = resultSet.get(0).get("CNTRY");
		//String cntrynm = resultSet.get(0).get("MPLYR_CNTRY_NM");
		String postalcd = resultSet.get(0).get("MPLYR_POSTL_CD");
		//String street1 = resultSet.get(0).get("STREET1");
		//String street2 = resultSet.get(0).get("STREET2");

		List<Map<String, String>> location = given()
				.when()
				.get("/api/v1/Individuals/{individualId}?section=employment-history",indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body("indvlEmpHistory[0].empStartDt", equalTo(startdate))
				.body("indvlEmpHistory[0].empEndDt", equalTo(enddate))
				.body("indvlEmpHistory[0].empName", equalTo(org_nm))
				.body("indvlEmpHistory[0].position", equalTo(posn))
				.body("indvlEmpHistory[0].isInvestmentRelated",
						equalTo(Boolean.parseBoolean(invstmntfl))).extract()
				.path("indvlEmpHistory.location");

		for (Map<String, String> map : location) {
			// assertEquals(street1, map.get("street1"));
			// assertEquals(street2, map.get("street2"));
			assertEquals(city, map.get("city"));
			assertEquals(state, map.get("state"));
			//assertEquals(cntrynm, map.get("countryName"))
			assertEquals(cntrycd, map.get("country"));
			assertEquals(postalcd, map.get("postalCode"));
		}

	}

	@Test
	public void noEmpHistDtlsTest() throws DatabaseException {
		/*
		 * Prepare sql parameters and execute sql
		 */
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings(
				"emplthist.no.dtls");
		String indvl_pk1 = resultSet.get(0).get("INDVL_PK");
		int indvl_pk = Integer.parseInt(indvl_pk1);

		given().when()
				.get("/api/v1/individuals/{individualId}/employment-history",
						indvl_pk).then().time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON).assertThat().statusCode(200)
				.and().body("indvlEmpHistory.size()", equalTo(0));
	}

	@Test
	public void empHistSizeCompareTest() throws DatabaseException {
		/*
		 * Prepare sql parameters and execute sql
		 */
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se1
				.executeForStrings("emplthist.dtls");
		String indvl_pk1 = resultSet.get(0).get("INDVL_PK");
		int indvl_pk = Integer.parseInt(indvl_pk1);

		Response response = given()
				.when()
				.get("/api/v1/individuals/{individualId}/employment-history",
						indvl_pk).then().time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON).assertThat().statusCode(200)
				.extract().response();

		String jsonAsString = response.asString();
		Map<String, ?> jsonAsMap = com.jayway.restassured.path.json.JsonPath
				.from(jsonAsString).get("");
		List<Map<String, ?>> emplymntHstryList = (List) jsonAsMap
				.get("indvlEmpHistory");
		assertThat(emplymntHstryList.size(), equalTo(resultSet.size()));
	}
}
