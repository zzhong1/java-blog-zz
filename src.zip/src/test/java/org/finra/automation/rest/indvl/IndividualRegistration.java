package org.finra.automation.rest.indvl;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static java.util.concurrent.TimeUnit.*; 

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.junit.base.BaseTest;
import org.finra.test.tools.db.SqlExecutor;
import org.finra.test.tools.db.exceptions.DatabaseException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.module.jsv.JsonSchemaValidator;

/**
 * @author K25032
 *
 */
public class IndividualRegistration {
	//int port = 5000;
	
	@Before
	public void setUp() {
		//RestAssured.port = port;
		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
	}

	@Rule
	public BaseTest basetest = new BaseTest();


	/**
	 * @throws DatabaseException
	 * Verified the count of registrations web services matches with database 
	 * Verified all fields matches for one registration
	 */
	@Test
	public void fieldLevelTest() throws DatabaseException {
		String url = BaseTest.getRunConfig().getApplicationUrl("rest.indvl.url");

		Map<String, Object> sqlParametersEmpty = new HashMap<String, Object>();
		SqlExecutor seIndvl = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> indvl = seIndvl.executeForStrings(
				"indvlRgstn.indvl", sqlParametersEmpty);
		System.out.println(Integer.parseInt(indvl.get(0).get("INDVL_PK")));
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		int indvl_pk = Integer.parseInt(indvl.get(0).get("INDVL_PK"));
		sqlParameters.put("INDVL_PK", indvl_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> rgstns = se.executeForStrings(
				"indvlRgstn.dtls", sqlParameters);
		System.out.println("This individual has " + rgstns.size() + " registrations");
		Map<String, String> rgstn = rgstns.remove(0);
		Map<String, Object> matcher = new HashMap<String, Object>();
		matcher.put("firmId", Integer.parseInt(rgstn.get("firmId")));
		matcher.put("firmName", rgstn.get("firmName"));
		matcher.put("firmAssocSeqNum", Integer.parseInt(rgstn.get("firmAssocSeqNum")));
		matcher.put("regulatorId", Integer.parseInt(rgstn.get("regulatorId")));
		matcher.put("regulatorCd", rgstn.get("regulatorCd"));
		matcher.put("regulatorName", rgstn.get("regulatorName"));
		matcher.put("isActive", Boolean.parseBoolean(rgstn.get("isActive")));
		matcher.put("isApproved", Boolean.parseBoolean(rgstn.get("isApproved")));
		matcher.put("isTermedPostApproval", Boolean.parseBoolean(rgstn.get("isTermedPostApproval")));
		matcher.put("isTermedPriorApproval", Boolean.parseBoolean(rgstn.get("isTermedPriorApproval")));
		matcher.put("isDeficient", Boolean.parseBoolean(rgstn.get("isDeficient")));
		matcher.put("regBeginDt", rgstn.get("regBeginDt").equals("")? null:rgstn.get("regBeginDt"));
		matcher.put("regEndDt", rgstn.get("regEndDt").equals("")? null:rgstn.get("regEndDt"));
		matcher.put("regCategoryCd", rgstn.get("regCategoryCd"));
		matcher.put("regStatusCd", rgstn.get("regStatusCd"));
		matcher.put("regStatusName", rgstn.get("regStatusName"));
		matcher.put("regStatusTypeCd", rgstn.get("regStatusTypeCd"));
		matcher.put("regulatorTableCd", rgstn.get("regulatorTableCd"));
		matcher.put("currentStatusDt", rgstn.get("currentStatusDt").equals("")? null:rgstn.get("currentStatusDt"));
		matcher.put("hasApprovedBD", Boolean.parseBoolean(rgstn.get("hasApprovedBD")));
		matcher.put("hasApprovedIA", Boolean.parseBoolean(rgstn.get("hasApprovedIA")));



		
		
		
		given().when()
				.get(url + "crdrest/api/v1/individuals/{individualId}/registrations",indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS) 
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
			/*	.body("registrations.size()", equalTo(rgstns.size()+1))
				.body("registrations[0].firmId", equalTo(Integer.parseInt(rgstn.get("firmId"))))
				.body("registrations[0].firmName", equalTo(rgstn.get("firmName")))
				.body("registrations[0].firmAssocSeqNum", equalTo(Integer.parseInt(rgstn.get("firmAssocSeqNum"))))
				.body("registrations[0].regulatorId", equalTo(Integer.parseInt(rgstn.get("regulatorId"))))
				.body("registrations[0].regulatorCd", equalTo(rgstn.get("regulatorCd")))
				.body("registrations[0].regulatorName", equalTo(rgstn.get("regulatorName")))
				.body("registrations[0].isActive", equalTo(Boolean.parseBoolean(rgstn.get("isActive"))))
				.body("registrations[0].isApproved", equalTo(Boolean.parseBoolean(rgstn.get("isApproved"))))
				.body("registrations[0].isTermedPostApproval", equalTo(Boolean.parseBoolean(rgstn.get("isTermedPostApproval"))))
				.body("registrations[0].isTermedPriorApproval", equalTo(Boolean.parseBoolean(rgstn.get("isTermedPriorApproval"))))
				.body("registrations[0].isDeficient", equalTo(Boolean.parseBoolean(rgstn.get("isDeficient"))))
				.body("registrations[0].regBeginDt", equalTo(rgstn.get("regBeginDt")))
				.body("registrations[0].regEndDt", equalTo(rgstn.get("regEndDt").equals("")? null:rgstn.get("regEndDt")))
				.body("registrations[0].regCategoryCd", equalTo(rgstn.get("regCategoryCd")))
				.body("registrations[0].regStatusCd", equalTo(rgstn.get("regStatusCd")))
				.body("registrations[0].regStatusName", equalTo(rgstn.get("regStatusName")))
				.body("registrations[0].regStatusTypeCd", equalTo(rgstn.get("regStatusTypeCd")))
				.body("registrations[0].regulatorTableCd", equalTo(rgstn.get("regulatorTableCd")))
				.body("registrations[0].currentStatusDt", equalTo(rgstn.get("currentStatusDt")))
				.body("registrations[0].hasApprovedIA", equalTo(Boolean.parseBoolean(rgstn.get("hasApprovedIA"))))
				.body("registrations[0].hasApprovedBD", equalTo(Boolean.parseBoolean(rgstn.get("hasApprovedBD"))))*/
				.body("registrations", hasItem(matcher));
		System.out.println("All fields matched!");

	}
	
	@Test
	public void fieldLevelTestEndPoint2() throws DatabaseException {
		String url = BaseTest.getRunConfig().getApplicationUrl("rest.indvl.url");

		Map<String, Object> sqlParametersEmpty = new HashMap<String, Object>();
		SqlExecutor seIndvl = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> indvl = seIndvl.executeForStrings(
				"indvlRgstn.indvl", sqlParametersEmpty);
		System.out.println(Integer.parseInt(indvl.get(0).get("INDVL_PK")));
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		int indvl_pk = Integer.parseInt(indvl.get(0).get("INDVL_PK"));
	
		sqlParameters.put("INDVL_PK", indvl_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> rgstns = se.executeForStrings(
				"indvlRgstn.dtls", sqlParameters);
		System.out.println("This individual has " + rgstns.size() + " registrations");
		Map<String, String> rgstn = rgstns.remove(0);
		Map<String, Object> matcher = new HashMap<String, Object>();
		matcher.put("firmId", Integer.parseInt(rgstn.get("firmId")));
		matcher.put("firmName", rgstn.get("firmName"));
		matcher.put("firmAssocSeqNum", Integer.parseInt(rgstn.get("firmAssocSeqNum")));
		matcher.put("regulatorId", Integer.parseInt(rgstn.get("regulatorId")));
		matcher.put("regulatorCd", rgstn.get("regulatorCd"));
		matcher.put("regulatorName", rgstn.get("regulatorName"));
		matcher.put("isActive", Boolean.parseBoolean(rgstn.get("isActive")));
		matcher.put("isApproved", Boolean.parseBoolean(rgstn.get("isApproved")));
		matcher.put("isTermedPostApproval", Boolean.parseBoolean(rgstn.get("isTermedPostApproval")));
		matcher.put("isTermedPriorApproval", Boolean.parseBoolean(rgstn.get("isTermedPriorApproval")));
		matcher.put("isDeficient", Boolean.parseBoolean(rgstn.get("isDeficient")));
		matcher.put("regBeginDt", rgstn.get("regBeginDt"));
		matcher.put("regEndDt", rgstn.get("regEndDt").equals("")? null:rgstn.get("regEndDt"));
		matcher.put("regCategoryCd", rgstn.get("regCategoryCd"));
		matcher.put("regStatusCd", rgstn.get("regStatusCd"));
		matcher.put("regStatusName", rgstn.get("regStatusName"));
		matcher.put("regStatusTypeCd", rgstn.get("regStatusTypeCd"));
		matcher.put("regulatorTableCd", rgstn.get("regulatorTableCd"));
		matcher.put("currentStatusDt", rgstn.get("currentStatusDt"));
		matcher.put("hasApprovedBD", Boolean.parseBoolean(rgstn.get("hasApprovedBD")));
		matcher.put("hasApprovedIA", Boolean.parseBoolean(rgstn.get("hasApprovedIA")));



		
		
		
		given().when()
				.get(url+"crdrest/api/v1/individuals/{individualId}?section=registrations",indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS) 
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
			/*	.body("registrations.size()", equalTo(rgstns.size()+1))
				.body("registrations[0].firmId", equalTo(Integer.parseInt(rgstn.get("firmId"))))
				.body("registrations[0].firmName", equalTo(rgstn.get("firmName")))
				.body("registrations[0].firmAssocSeqNum", equalTo(Integer.parseInt(rgstn.get("firmAssocSeqNum"))))
				.body("registrations[0].regulatorId", equalTo(Integer.parseInt(rgstn.get("regulatorId"))))
				.body("registrations[0].regulatorCd", equalTo(rgstn.get("regulatorCd")))
				.body("registrations[0].regulatorName", equalTo(rgstn.get("regulatorName")))
				.body("registrations[0].isActive", equalTo(Boolean.parseBoolean(rgstn.get("isActive"))))
				.body("registrations[0].isApproved", equalTo(Boolean.parseBoolean(rgstn.get("isApproved"))))
				.body("registrations[0].isTermedPostApproval", equalTo(Boolean.parseBoolean(rgstn.get("isTermedPostApproval"))))
				.body("registrations[0].isTermedPriorApproval", equalTo(Boolean.parseBoolean(rgstn.get("isTermedPriorApproval"))))
				.body("registrations[0].isDeficient", equalTo(Boolean.parseBoolean(rgstn.get("isDeficient"))))
				.body("registrations[0].regBeginDt", equalTo(rgstn.get("regBeginDt")))
				.body("registrations[0].regEndDt", equalTo(rgstn.get("regEndDt").equals("")? null:rgstn.get("regEndDt")))
				.body("registrations[0].regCategoryCd", equalTo(rgstn.get("regCategoryCd")))
				.body("registrations[0].regStatusCd", equalTo(rgstn.get("regStatusCd")))
				.body("registrations[0].regStatusName", equalTo(rgstn.get("regStatusName")))
				.body("registrations[0].regStatusTypeCd", equalTo(rgstn.get("regStatusTypeCd")))
				.body("registrations[0].regulatorTableCd", equalTo(rgstn.get("regulatorTableCd")))
				.body("registrations[0].currentStatusDt", equalTo(rgstn.get("currentStatusDt")))
				.body("registrations[0].hasApprovedIA", equalTo(Boolean.parseBoolean(rgstn.get("hasApprovedIA"))))
				.body("registrations[0].hasApprovedBD", equalTo(Boolean.parseBoolean(rgstn.get("hasApprovedBD"))))*/
				.body("registrations", hasItem(matcher));
		System.out.println("All fields matched!");

	}
	
	/**
	 * Verified response json matches schema 
	 */
	@Test
	public void schemaTest() {
		String url = BaseTest.getRunConfig().getApplicationUrl("rest.indvl.url");

		int indvl_pk = 249;

		given().when()
				.get(url + "crdrest/api/v1/individuals/{individualId}/registrations",indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS) 
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body(JsonSchemaValidator
						.matchesJsonSchemaInClasspath("IndividualRegistrations.json"));
	}
	
	/**
	 * Verified response with no registration for individual with no registration 
	 */
	@Test
	public void noDataTest() {
		String url = BaseTest.getRunConfig().getApplicationUrl("rest.indvl.url");

		int indvl_pk = 0;

		given().when()
				.get(url + "crdrest/api/v1/individuals/{individualId}/registrations",indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS) 
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body("registrations.size()", equalTo(0));
	}
	
	/**
	 * Verified response with invalid request get 400 status code
	 */
	@Test
	public void invalidDataTest() {
		String url = BaseTest.getRunConfig().getApplicationUrl("rest.indvl.url");

		String indvl_pk = "invalid";

		given().when()
				.get(url + "crdrest/api/v1/individuals/{individualId}/registrations",indvl_pk)
				.then()
				.time(lessThan(5L), SECONDS) 
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(400);
				
	}
	

}