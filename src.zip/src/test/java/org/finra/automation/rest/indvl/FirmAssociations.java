package org.finra.automation.rest.indvl;

import static com.jayway.restassured.RestAssured.given;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.Assert.assertEquals;

import java.util.*;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import org.finra.automation.junit.base.BaseTest;
import org.finra.jtaf.ewd.widget.element.InteractiveElement;
import org.finra.test.tools.commons.utils.DateUtil;
import org.finra.test.tools.db.SqlExecutor;
import org.finra.test.tools.db.exceptions.DatabaseException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.module.jsv.JsonSchemaValidator;

public class FirmAssociations {
	int port = 62629;

	@Before
	public void setUp() {
		RestAssured.port = port;
		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
	}

	@Rule
	public BaseTest basetest = new BaseTest();


	@Test
	public void fieldLevelTestIFA() throws DatabaseException {
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		int indvl_pk;
		int IFACount = 3;

		/* Find Indvl to test */
		sqlParameters.put("CHILD_REC_COUNT", IFACount);
		sqlParameters.put("ADD_FILTER", " 1=1");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("firmasctn.get.indvl", sqlParameters);
		indvl_pk = Integer.valueOf(resultSet.get(0).get("INDVL_PK"));
		System.out.println("INDVL_PK = " + indvl_pk);

		//  Get IFA from CRDREST
		List<Map<String, String>> JSONFirmAssoc = given().when()
				.get("/api/v1/Individuals/" + indvl_pk + "/firm-associations")
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.root("firmAssociations")
				.body("size()", equalTo(IFACount)).extract().path("firmAssociations");

		/* Get Indvl's IFA records from DB */
		sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("INDVL_PK", indvl_pk);
		se = new SqlExecutor("main", System.getProperty("target"));
		resultSet = se.executeForStrings("firmasctn.get.IFA", sqlParameters);
		org.junit.Assert.assertTrue("IFA count in DB do not match IFA count in REST", resultSet.size() == JSONFirmAssoc.size());

		for (Map<String, String> JSONCurrentIFA : JSONFirmAssoc) {

			// Find IFA from DB that matches IFA in JSON
			int iMatchRec = -1;
			String JSONfirmID;
			String JSONfirmSeq;
			String DBfirmID;
			String DBfirmSeq;
			JSONfirmID = String.valueOf(JSONCurrentIFA.get("firmId"));
			JSONfirmSeq = String.valueOf(JSONCurrentIFA.get("firmAssocSeqNum"));
			for (int iKtr2 = 0; iKtr2 < resultSet.size(); iKtr2++) {
				DBfirmID = resultSet.get(iKtr2).get("ORG_PK");
				DBfirmSeq = resultSet.get(iKtr2).get("REC_SEQ_NB");

				if ( JSONfirmID.equals(DBfirmID) && JSONfirmSeq.equals(DBfirmSeq) ) {
					iMatchRec = iKtr2;
				}
			}
			org.junit.Assert.assertTrue("IFA keys in DB do not Match IFA keys in REST", iMatchRec != -1);
			HashMap DBCurrentIFA = (HashMap)resultSet.get(iMatchRec);

			// Compare fields
			assertEquals(DBCurrentIFA.get("EMP_BLLNG_CD"), JSONCurrentIFA.get("empFirmBillingCd"));

			assertEquals(JSONCurrentIFA.get("isIndependentContractor"), DBCurrentIFA.get("NDPNT_CNTRCR_FL").equals("")?null:Boolean.parseBoolean(DBCurrentIFA.get("NDPNT_CNTRCR_FL").toString()));

			assertEquals(DBCurrentIFA.get("INDVL_FIRM_ASCTN_BEGIN_DT"), JSONCurrentIFA.get("beginDt"));

			assertEquals(DBCurrentIFA.get("INDVL_FIRM_ASCTN_END_DT"), JSONCurrentIFA.get("endDt")==null?"":JSONCurrentIFA.get("endDt"));

			// Validate the number of child records
			org.junit.Assert.assertTrue("IFA fields in DB do not Match IFA fields in REST - ELA Count",
					( ((ArrayList)((HashMap)JSONCurrentIFA).get("empLocations")).size() == Integer.parseInt(DBCurrentIFA.get("ELA_COUNT").toString()))) ;


			/**
			 Fields need to determine if we're validating them
					"firmName": "PERFORMANCE TRUST CAPITAL PARTNERS, LLC",
					"historicalFirmName": "PERFORMANCE TRUST CAPITAL PARTNERS, LLC",
					"terminationEventId": null,
					"terminationComment": null,
					"terminationReasonCd": "",
					"terminationReasonName": null,
					"terminationReasonDesc": "",
					"everApprovedIA": false,
					"everApprovedBD": false,
			 **/

			// remove record from resultset
			resultSet.remove(iMatchRec);
		}
	}

	@Test
	public void fieldLevelTestELA() throws DatabaseException {
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		int indvl_pk;
		int IFACount = 1;

		/* Find Indvl to test END DATE NOT NULL*/
		sqlParameters.put("CHILD_REC_COUNT", IFACount);
		sqlParameters.put("ADD_FILTER", " exists (select 1 from EMPLT_LOC_ASCTN ELA where ela.indvl_pk = I.indvl_pk and END_DT is not null)");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("firmasctn.get.indvl", sqlParameters);
		indvl_pk = Integer.valueOf(resultSet.get(0).get("INDVL_PK"));
		System.out.println("INDVL_PK = " + indvl_pk);
		TestFieldsForOneELA(indvl_pk);

		/* Find Indvl to test STREET2 NOT NULL*/
		sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("CHILD_REC_COUNT", IFACount);
		sqlParameters.put("ADD_FILTER", " exists (select 1 from EMPLT_LOC_ASCTN ELA, brnch_ofc BO where ela.indvl_pk = I.indvl_pk and ELA.BRNCH_OFC_PK = BO.BRNCH_OFC_PK AND BO.STRT2_NM is not null)");
		se = new SqlExecutor("main", System.getProperty("target"));
		resultSet = se.executeForStrings("firmasctn.get.indvl", sqlParameters);
		indvl_pk = Integer.valueOf(resultSet.get(0).get("INDVL_PK"));
		System.out.println("INDVL_PK = " + indvl_pk);
		TestFieldsForOneELA(indvl_pk);

		/* Find Indvl to test NRO FIRM_BLLNG_CD NOT NULL*/
		sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("CHILD_REC_COUNT", IFACount);
		sqlParameters.put("ADD_FILTER", " exists (select 1 from EMPLT_LOC_ASCTN ELA, non_rgstd_ofc NRO where ela.indvl_pk = I.indvl_pk and ela.non_rgstd_ofc_pk = nro.non_rgstd_ofc_pk and FIRM_BLLNG_CD is not null)");
		se = new SqlExecutor("main", System.getProperty("target"));
		resultSet = se.executeForStrings("firmasctn.get.indvl", sqlParameters);
		indvl_pk = Integer.valueOf(resultSet.get(0).get("INDVL_PK"));
		System.out.println("INDVL_PK = " + indvl_pk);
		TestFieldsForOneELA(indvl_pk);

	}

	private void TestFieldsForOneELA(int indvl_pk) throws DatabaseException {
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		SqlExecutor se;
		List<Map<String, String>> resultSet;
		int IFACount = 1;


		// Get IFA data from REST
		Response JSONFirmAssoc = given().when()
				.get("/api/v1/Individuals/" + indvl_pk + "/firm-associations");
		JSONFirmAssoc.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.root("firmAssociations")
				.body("size()", equalTo(IFACount));

		// Get ELA sub list from JSON obejct
		List<Map<String,Object>> ELAList =JsonPath.read(JSONFirmAssoc.asString(),"$.firmAssociations[*].empLocations[*]");
		Map<String,Object> ELA =  ELAList.get(0);

		/* Get Indvl's ELA records from DB */
		sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("INDVL_PK", indvl_pk);
		se = new SqlExecutor("main", System.getProperty("target"));
		resultSet = se.executeForStrings("firmasctn.get.ELA", sqlParameters);

		String DBStartDate = (resultSet.get(0).get("BEGIN_DT").isEmpty())?null:resultSet.get(0).get("BEGIN_DT");
		String DBEndDate = (resultSet.get(0).get("END_DT").isEmpty())?null:resultSet.get(0).get("END_DT");
		String DBBillCode = resultSet.get(0).get("BRNCH_FIRM_BLLNG_CD");
		Integer DBBranchPK = (resultSet.get(0).get("BRNCH_OFC_PK").isEmpty())?null: Integer.parseInt(resultSet.get(0).get("BRNCH_OFC_PK"));
		String DBBranchCode = resultSet.get(0).get("BRNCH_CD_NB");
		String DBLocationType="";
		if (resultSet.get(0).get("SPRVD_FROM_FL").equals("Y") ) {
			DBLocationType = "Supervised From";
		}
		if (resultSet.get(0).get("LCTD_AT_FL").equals("Y") ) {
			DBLocationType = "Located At";
		}
		String DBLocationTypeDesc = resultSet.get(0).get("CRD_BRNCH");
		boolean DBIsRegLoca = false;
		if (resultSet.get(0).get("RGSTD_OFC").equals("true")) {
			DBIsRegLoca = true;
		}
		boolean DBIsPrivate = false;
		if (resultSet.get(0).get("PRVT_RSDNC_FL").equals("Y")) {
			DBIsPrivate = true;
		}
		String DBAdrStrt1 = resultSet.get(0).get("STRT1_NM");
		String DBAdrStrt2 = resultSet.get(0).get("STRT2_NM");
		String DBAdrCity = resultSet.get(0).get("CITY_NM");
		String DBAdrState = resultSet.get(0).get("STATE_CD");
		String DBAdrPostalCode = resultSet.get(0).get("POSTL_CD");
		String DBAdrCountry = resultSet.get(0).get("CNTRY_NM");

		// Compare all the ELA fields from DB to REST
		assertEquals(DBStartDate, ELA.get("empLocationStartDt"));
		assertEquals(DBEndDate, ELA.get("empLocationEndDt"));
		assertEquals(DBBillCode, ELA.get("empLocationFirmBillingCd") );
		assertEquals(DBBranchPK, ELA.get("branchId"));
		assertEquals(DBBranchCode, ELA.get("branchCd"));
		assertEquals(DBLocationType, ELA.get("locationType"));
		assertEquals(DBLocationTypeDesc, ELA.get("locationTypeDesc"));
		assertEquals(DBIsRegLoca, ELA.get("isRegisteredLocation"));
		assertEquals(DBIsPrivate, ELA.get("isPrivateResidence"));

		HashMap JSONAddr = (HashMap)ELA.get("address");
		assertEquals(DBAdrStrt1, JSONAddr.get("street1") );
		assertEquals(DBAdrStrt2, JSONAddr.get("street2") );
		assertEquals(DBAdrCity, JSONAddr.get("city") );
		assertEquals(DBAdrState, JSONAddr.get("state"));
		assertEquals(DBAdrPostalCode, JSONAddr.get("postalCode"));
		assertEquals(DBAdrCountry, JSONAddr.get("country"));
	}

	@Test
	public void schemaTest() throws DatabaseException {
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		int indvl_pk;

		/* Find Indvl to test */
		sqlParameters.put("CHILD_REC_COUNT", 3);
		sqlParameters.put("ADD_FILTER", " 1=1");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("firmasctn.get.indvl", sqlParameters);
		indvl_pk = Integer.valueOf(resultSet.get(0).get("INDVL_PK"));
		System.out.println("INDVL_PK = " + indvl_pk);

		given().when()
				.get("/api/v1/Individuals/" + indvl_pk + "/firm-associations")
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body(JsonSchemaValidator
						.matchesJsonSchemaInClasspath("Firmassociations.json"));
	}

	@Test
	public void SecondURLtest() throws DatabaseException {
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		int indvl_pk;

		/* Find Indvl to test */
		sqlParameters.put("CHILD_REC_COUNT", 2);
		sqlParameters.put("ADD_FILTER", " 1=1");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("firmasctn.get.indvl", sqlParameters);
		indvl_pk = Integer.valueOf(resultSet.get(0).get("INDVL_PK"));
		System.out.println("INDVL_PK = " + indvl_pk);

		given().when()
				.get("/api/v1/Individuals/" + indvl_pk + "?section=firm-associations")
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body(JsonSchemaValidator
						.matchesJsonSchemaInClasspath("Firmassociations.json"));
	}

	@Test
	public void noDataTest() {
		given().when()
				.get("/api/v1/Individuals/0/firm-associations")
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body("firmAssociations.size()", equalTo(0));
	}

	@Test
	public void invalidDataTest() {
		given().when()
				.get("/api/v1/Individuals/bogus/firm-associations")
				.then()
				.time(lessThan(5L), SECONDS)
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(400);
	}

}
