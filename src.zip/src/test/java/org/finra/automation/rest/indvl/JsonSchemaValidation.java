package org.finra.automation.rest.indvl;

import static com.jayway.restassured.RestAssured.given;

import org.finra.test.tools.db.SqlExecutor;
import org.finra.test.tools.db.exceptions.DatabaseException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.module.jsv.JsonSchemaValidator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonSchemaValidation {

	int port = 62629;

	@Before
	public void setUp() {
		RestAssured.port = port;
		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
	}

	@Rule
	public org.finra.automation.junit.base.BaseTest basetest = new org.finra.automation.junit.base.BaseTest();

	@Test
	public void SampleTest() throws DatabaseException {
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		int indvl_pk;

		/* Find Indvl to test */
		sqlParameters.put("CHILD_REC_COUNT", 3);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("firmasctn.get.indvl", sqlParameters);
		indvl_pk = Integer.valueOf(resultSet.get(0).get("INDVL_PK"));
		System.out.println("INDVL_PK = " + indvl_pk);

		given().when()
				.get("/api/v1/Individuals/" + indvl_pk + "/firm-associations")
				.then()
				.contentType(ContentType.JSON)
				.assertThat()
				.statusCode(200)
				.and()
				.body(JsonSchemaValidator
						.matchesJsonSchemaInClasspath("Firmassociations.json"));
		
		/*@Test
		public void schemaValidationTest() {
			given().when()
					.get("/api/v1/Individuals/249/employment-history")
					.then()
					.contentType(ContentType.JSON)
					.assertThat()
					.statusCode(200)
					.and()
					.body(JsonSchemaValidator
							.matchesJsonSchemaInClasspath("EmploymentHistory.json")); */
	}
}
