package org.finra.automation.rest.indvl;

import org.junit.Test;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

public class JsonPathSample {

	@Test
	public void testJson()
	{
		
	String j="{\"store\": {\"book\": [{\"category\": \"fiction\",\"author\": \"Evelyn Waugh\", \"title\": \"Sword of Honour\", \"price\": 12.99}]}}";
	Object document = Configuration.defaultConfiguration().jsonProvider().parse(j);
	String author = JsonPath.read(document, "$.store.book[0].author");
	System.out.println(author);
		
    }
}	
				
	

