package org.finra.automation.voi;

import java.util.HashMap;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.CRDToPSLink;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.junit.Rule;
import org.junit.Test;

public class VerifyCRDToPSLink_ORG {

	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private LeftNavigation leftNav = new LeftNavigation();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	@Test
	public void verifyCRDToAAOLink() throws Exception {
		BaseTest.getLogger().info("***** Starting Test for CRD To AAO for ORG-5167");
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToOrganizationPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Short Text", "5167");
		CRDSearch crdSearch = new CRDSearch("CRD/IARD Organization Search");
		crdSearch.doSearch(searchCriteria);
		
		leftNav.selectItem("Disclosures");
		
		CRDToPSLink lnk = new CRDToPSLink();
		lnk.goCRDToPSLink("617602", "94-16");
	}
	
	@Test
	public void verifyCRDToFDALink() throws Exception {
		BaseTest.getLogger().info("***** Starting Test for CRD To FDA for ORG-7654");
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToOrganizationPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Short Text", "7654");
		CRDSearch crdSearch = new CRDSearch("CRD/IARD Organization Search");
		crdSearch.doSearch(searchCriteria);
		
		leftNav.selectItem("Disclosures");
		
		CRDToPSLink lnk = new CRDToPSLink();
		lnk.goCRDToPSLink("1286937", "E112004018901");
	}
}
