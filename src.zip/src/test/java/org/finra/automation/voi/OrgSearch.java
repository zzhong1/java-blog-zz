package org.finra.automation.voi;

import java.util.HashMap;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.CommonControls;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;

public class OrgSearch {

	private final static GUIProperties GUI = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private LeftNavigation leftNav = new LeftNavigation();
	
	@Rule
	public BaseTest base=new BaseTest();
	
	@Test
	public void searchOrgByCrdNo() throws Exception
	{
		String basepath=GUI.getPropertyValue("crd.base");
		String xpath=GUI.getPropertyValue("crd.voi.text");
		CommonControls fmc = new CommonControls(basepath);
		
		BaseTest.getLogger().info("***** Org Search by Org CRD#***********");
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to VOI
		 */
		nav.goToOrganizationPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Short Text", "877");
		CRDSearch crdSearch = new CRDSearch("NFI Search");
		crdSearch.doSearch(searchCriteria);
		
		//Click Other Business in Left navigation
		leftNav.selectItem("Other Business Names");
		//System.out.println(fmc.getTitle());
		Assert.assertTrue("Left Navigation not Found in VOI", fmc.getTitle(xpath).equals("Other Business Names"));
	}
}



