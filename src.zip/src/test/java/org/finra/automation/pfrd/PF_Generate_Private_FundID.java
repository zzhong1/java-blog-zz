package org.finra.automation.pfrd;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.net.aso.a;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.PFReadOnlyPageWidget;
import org.finra.automation.crd_automation.datagen.RandomDataGenerator_CRD;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.TopNavigation;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.FormTable;
import org.finra.automation.crd_automation.ui.widget.form.PopupPageContent;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PF_Generate_Private_FundID{

	final static GUIProperties gp = new GUIProperties("pfrd/pf.gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private FormTable ft = new FormTable();
	
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * 
	 */
	@Test
	public void verifyFormPF() throws Exception {

		
		/*
		 * Login CRD as Firm user
		 */
		crd.crdLogin("crd.application.url","JOINT877");

		/*
		 * Use FormNavigation class to go to Generate Private FundID
		 */
		nav.goToPFRDPage("Form Filing", "Generate a Private Fund Identification Number");
		
		/*
		 * Use FormMainContent methods to click radio buttons/enter text
		 */
		FormMainContent fmc = new FormMainContent();
		fmc.clickButton("Generate a Private Fund ID", "1");												// Click "Create" button
		
		
		//Thread.sleep(3000);
		/*
		 * Prepare sql parameters and execute sql
		 */
	    Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
	    SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
	    List<Map<String, String>> dbData1 = se1.executeForStrings("pf.Generate.FundID",sqlParameters1);
		String headerLoc = gp.getPropertyValue("pf.ph.table", "tblData");
		PFReadOnlyPageWidget pf = new PFReadOnlyPageWidget(headerLoc);
		pf.verifyTdDataWithUI(dbData1, "FUND_ID", "pf.ph.text.following.td", "Private Fund ID");

		
	}
	
	
	
}
