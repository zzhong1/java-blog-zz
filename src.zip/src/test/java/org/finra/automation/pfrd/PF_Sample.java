package org.finra.automation.pfrd;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.net.aso.a;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.PFReadOnlyPageWidget;
import org.finra.automation.crd_automation.datagen.RandomDataGenerator_CRD;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.TopNavigation;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.FormTable;
import org.finra.automation.crd_automation.ui.widget.form.PopupPageContent;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PF_Sample{

	final static GUIProperties gp = new GUIProperties("pfrd/pf.gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private FormTable ft = new FormTable();
	
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * 
	 */
	@Test
	public void verifyFormPFSample() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
/*		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("OOO", "XXX");
		sqlParameters.put("UUU", "YYY");
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("XXXXXXX",sqlParameters);
		String org_pk = resultSet.get(0).get("ORG_PK");
		String flng_pk = resultSet.get(0).get("FLNG_PK");
*/
		
		/*
		 * Login CRD as Firm user
		 */
		crd.crdLogin("crd.application.url","JOINT6220");

		/*
		 * Use FormNavigation class to go to New/Draft PF filing page
		 */
		nav.goToPFRDPage("Form Filing", "New/Draft Web Filing");
		
		/*
		 * Use FormMainContent methods to click radio buttons/enter text
		 */
		FormMainContent fmc = new FormMainContent();
		
		/*
		 * Use RandomDataGenerator_CRD methods to get current date/ random phone number/ random ssn etc.
		 */
		RandomDataGenerator_CRD random = new RandomDataGenerator_CRD();
		
		/*
		 * Create a Quarterly Initial
		 */
		fmc.selectRadioButton("rbgFirstFilings", "1", "rbFirstQuarterly");			// Select Quarterly Filing
		fmc.inputText("txtFirstQuarterlyPeriodEndedDate", random.currentDate());	// Enter current date as end date
		fmc.selectOption("cbQuarter", "1");											// Select first Quarter
		fmc.clickButton("Create", "1");												// Click "Create" button
		
		/*
		 * Navigation to any page by clicking left navigation items
		*/
		LeftNavigation leftNav = new LeftNavigation();
		leftNav.selectItem("Section 1a - Information about you and your related persons"); 
		
		/*
		 * Remove Pending Filing 
		*/
		nav.goToIARDForm("Form ADV");
		nav.goToPFRDPage("Form Filing", "New/Draft Web Filing");
		fmc.clickButton("Delete Filing", "1");

		
	}


	
	
	
}
