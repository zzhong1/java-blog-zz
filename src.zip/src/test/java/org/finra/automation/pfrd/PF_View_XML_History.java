package org.finra.automation.pfrd;

import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.ViewIndividual;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.crd_automation.ui.widget.form.FormTable;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.db.CommitBehavior;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;
import org.finra.jtaf.ewd.ExtWebDriver;
import org.finra.jtaf.ewd.session.SessionManager;

/**
 * Created by mccabej on 3/10/2016.
 */
public class PF_View_XML_History {

    @Rule
    public BaseTest base= new BaseTest();
    Login pfrd = new Login();
    private FormNavigation nav = new FormNavigation();
    private static final GUIProperties GUI = new GUIProperties("crd/gui.properties");

    @Test
    public void PerformXMLUploadHistory() throws Exception {
        FormTable ft = new FormTable();
        ExtWebDriver ewd;

        BaseTest.getLogger().info("Starting PFRD Org Search Test - Login");
        pfrd.crdLogin("crd.application.url","PFRD107105");

        BaseTest.getLogger().info("Starting PFRD XML History Test - Setup Upload to show Schema Failure");
        Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
        sqlParameters1.put("ORG_PK", "107105");
        SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
        se1.executeUpdate("pf.ph.Upload.XML.UpdateUploadstatus",sqlParameters1, CommitBehavior.COMMIT);
        sqlParameters1.put("ERR_TX", "BAD BAD Leroy Brown");
        se1 = new SqlExecutor("main", System.getProperty("target"));
        se1.executeUpdate("pf.ph.Upload.XML.InsertUploadIssue",sqlParameters1, CommitBehavior.COMMIT);

        BaseTest.getLogger().info("Starting PFRD XML History Test - SiteMap link");
        nav.goToPFRDPage("XML Filing Upload", "XML Upload History");
        FormMainContent fmc = new FormMainContent();

        BaseTest.getLogger().info("Starting PFRD XML History Test - Verify XML data shown");
        ft.clickLink("View","2");
        ewd = SessionManager.getInstance().getCurrentSession();
        String webPageHTML = ewd.getPageSource();
        org.junit.Assert.assertTrue("PFRD View XML link did not return XML data", webPageHTML.contains("<PFXMLFiling"));

        BaseTest.getLogger().info("Starting PFRD XML History Test - Verify Issues shown");
        ewd.navigate().back();
        ft.openPageInSameBrowser("View Details");
        webPageHTML = ewd.getPageSource();
        org.junit.Assert.assertTrue("PFRD View Issues link did not return issue data", webPageHTML.contains("BAD BAD Leroy Brown"));


    }

}
