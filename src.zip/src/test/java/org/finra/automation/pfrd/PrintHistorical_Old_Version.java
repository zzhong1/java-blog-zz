package org.finra.automation.pfrd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.ui.widgets.PFReadOnlyPageWidget;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.crd_automation.ui.widget.ViewIndividual;
import org.finra.automation.crd_automation.ui.widget.form.FormTable;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.automation.rad.comparator.ListMapFilter;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.test.tools.commons.comparator.Assert;
import org.finra.test.tools.db.SqlExecutor;
import org.junit.Rule;
import org.junit.Test;


public class PrintHistorical_Old_Version{

	final static GUIProperties gp = new GUIProperties("pfrd/pf.gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private FormTable ft = new FormTable();
	private ViewIndividual vi = new ViewIndividual();
	private LeftNavigation leftNav = new LeftNavigation();
	private PFReadOnlyPageWidget pf;
	
	@Rule
	public BaseTest basetest=new BaseTest();

	/*
	 * Verify Form PF Filing History table
	 */
	@Test
	public void verifyPrintHistorical_PF_Filing_History_Current_Version() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
		sqlParameters1.put("FORM_VRSN_NM", "04/2012");
		sqlParameters1.put("FUND_TYPE_CD", "HEDGE");
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> dbData1 = se1.executeForStrings("pf.ph.filing.fund",sqlParameters1);
		String org_pk = dbData1.get(0).get("ORG_PK");
		String flng_pk = dbData1.get(0).get("FLNG_PK");
		System.out.print("ORG_PK = " + org_pk);
		System.out.print("FLNG_PK = " + flng_pk);
		
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", org_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> dbData = se.executeForStrings("pf.ph.filing.history",sqlParameters);
				
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTSEC");

		/*
		 * Use FormNavigation class to go to historical PF filing search page
		 */
		nav.goToPFRDPage("View Organization", "Organization Search - Filing History");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", org_pk);

		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Get UI table data
		 */
		List<Map<String, String>> uiData = new ArrayList<Map<String, String>>();
		uiData = vi.getTableDataInfo("grdHistList", "1");
		
		/*
		 * Remove View XML column from uiInfo
		 */
		ListMapFilter modifiedUIData = new ListMapFilter(uiData);
		String[] removedKey = {"Submission Method", "View XML"};
		modifiedUIData.removeColumns(removedKey);

		/*
		 * Compare both UI and DB data
		 * Compare Policy: AsIs, AnyOrder, AnyOrderPartial
		 */
        org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy policy = org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy.valueOf("AnyOrder");
        Assert.assertCompare(modifiedUIData.getListMap(), dbData, policy, "PF_Hisotircal Filing");		
	}

	/*
	 * 
	 */
	@Test
	public void verifyPrintHistorical_PF_Section_1a_Current_Version() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
		sqlParameters1.put("FORM_VRSN_NM", "04/2012");
		sqlParameters1.put("FUND_TYPE_CD", "HEDGE");
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> dbData1 = se1.executeForStrings("pf.ph.filing.fund",sqlParameters1);
		String org_pk = dbData1.get(0).get("ORG_PK");
		String flng_pk = dbData1.get(0).get("FLNG_PK");
		System.out.print("ORG_PK = " + org_pk);
		System.out.print("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");

		/*
		 * Use FormNavigation class to go to historical PF filing search page
		 */
		nav.goToPFRDPage("View Organization", "Organization Search - Filing History");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", org_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Click filing id link
		 */
		ft.openPageInSameBrowser(flng_pk);
		
		/*
		 * Verify header
		 */

		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FLNG_PK", flng_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("pf.ph.section.1a",sqlParameters);
	
		
		String headerLoc = gp.getPropertyValue("pf.ph.table", "frmHeader");
		pf = new PFReadOnlyPageWidget(headerLoc);
		pf.verifyDataWithUI(resultSet, "Legal Name", "pf.ph.text.span", pf.getLocator(), "lblOrgName");
		pf.verifyDataWithUI(resultSet, "Filing Type", "pf.ph.text.span", pf.getLocator(), "lblFilingType");
		pf.verifyDataWithUI(resultSet, "Report Period", "pf.ph.text.span", pf.getLocator(), "lblReportPeriod");

		/*
		 * Verify section 1a - Item A - Information about you
		 */
		String section1a_ItemALoc = gp.getPropertyValue("pf.ph.section.table.container", "Section 1a - Item A - Information about you");
		PFReadOnlyPageWidget pf1 = new PFReadOnlyPageWidget(section1a_ItemALoc);
		pf1.verifyTdDataWithUI(resultSet, "Legal Name", "pf.ph.text.following.td", "Legal name");
		pf1.verifyTdDataWithUI(resultSet, "CRD Number", "pf.ph.text.following.td", "CRD Number");
		pf1.verifyTdDataWithUI(resultSet, "SEC 801-Number", "pf.ph.text.following.td", "SEC 801-Number");
		pf1.verifyTdDataWithUI(resultSet, "NFA ID Number, if any", "pf.ph.text.following.td", "NFA ID Number, if any");
		pf1.verifyTdDataWithUI(resultSet, "Large trader ID, if any", "pf.ph.text.following.td", "Large trader ID, if any");
		pf1.verifyTdDataWithUI(resultSet, "Large trader ID suffix, if any", "pf.ph.text.following.td", "Large trader ID suffix, if any");
		
		/*
		 * Verify Section 1a - Item A - Signatures
		 */
		String section1a_ItemALoc1 = gp.getPropertyValue("pf.ph.section.table.container", "Section 1a - Item A - Signatures");
		PFReadOnlyPageWidget pf2 = new PFReadOnlyPageWidget(section1a_ItemALoc1);
		pf2.verifyTdDataWithUI(resultSet, "Name of individual", "pf.ph.text.following.td", "Name of individual");
		pf2.verifyTdDataWithUI(resultSet, "Signature", "pf.ph.text.following.td", "Signature");
		pf2.verifyTdDataWithUI(resultSet, "Title", "pf.ph.text.following.td", "Title");
		pf2.verifyTdDataWithUI(resultSet, "Email address", "pf.ph.text.following.td", "Email address");
		pf2.verifyTdDataWithUI(resultSet, "Telephone contact number:", "pf.ph.text.following.td", "Telephone contact number");
		pf2.verifyTdDataWithUI(resultSet, "Date", "pf.ph.text.following.td", "Date");
		

	}


	/*
	 * Verify View Fund table
	 */
	@Test
	public void verifyPrintHistorical_PF_View_Fund_Current_Version() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
		sqlParameters1.put("FORM_VRSN_NM", "04/2012");
		sqlParameters1.put("FUND_TYPE_CD", "HEDGE");
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> dbData = se1.executeForStrings("pf.ph.filing.fund",sqlParameters1);
		String org_pk = dbData.get(0).get("ORG_PK");
		String flng_pk = dbData.get(0).get("FLNG_PK");
		System.out.print("ORG_PK = " + org_pk);
		System.out.print("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","HISTORYALL");

		/*
		 * Use FormNavigation class to go to historical PF filing search page
		 */
		nav.goToPFRDPage("View Organization", "Organization Search - Filing History");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", org_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Click filing id link
		 */
		ft.openPageInSameBrowser(flng_pk);
		leftNav.selectItem("View Fund");
		
		/*
		 * Get database data
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FLNG_PK", flng_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("pf.ph.view.fund",sqlParameters);
		
		FormTable ft = new FormTable();
		String headerLoc = gp.getPropertyValue("pf.ph.table", "Section1bItemBQs5_7");
		pf = new PFReadOnlyPageWidget(headerLoc);
		
		if(resultSet.size() > 0){
			ft.clickLink(resultSet.get(0).get("Private Fund ID").toString(),"1");
			pf.verifyTdDataWithUI(resultSet.get(0).get("Private Fund Name").toString(), resultSet.get(0).get("Private Fund ID").toString(), "pf.ph.text.following.td", "Private fund identification number of the reporting fund");
		}
		else {
			throw new Exception("No private fund is existed.");
		}

	}

	/*
	 * Verify Section 2a � Aggregated information about hedge funds that you advise:Q28
	 */
	@Test
	public void verifyPrintHistorical_PF_Q28_Current_Version() throws Exception {

		/*
		 * Prepare sql parameters and execute sql
		 */
		Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
		sqlParameters1.put("FORM_VRSN_NM", "04/2012");
		sqlParameters1.put("FUND_TYPE_CD", "HEDGE");
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> dbData = se1.executeForStrings("pf.ph.filing.fund",sqlParameters1);
		String org_pk = dbData.get(0).get("ORG_PK");
		String flng_pk = dbData.get(0).get("FLNG_PK");
		System.out.print("ORG_PK = " + org_pk);
		System.out.print("FLNG_PK = " + flng_pk);
		
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","HISTORYALL");

		/*
		 * Use FormNavigation class to go to historical PF filing search page
		 */
		nav.goToPFRDPage("View Organization", "Organization Search - Filing History");
		
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("CRD Number", org_pk);
		
		CRDSearch crdSearch = new CRDSearch("Historical Filing Search");
		crdSearch.doSearch(searchCriteria);
		
		/*
		 * Click filing id link
		 */
		ft.openPageInSameBrowser(flng_pk);
		leftNav.selectItem("Section 2a � Aggregated information about hedge funds that you advise");
		
		/*
		 * Get database data-Region
		 */
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("FLNG_PK", flng_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("pf.ph.q28.region",sqlParameters);
	
		/*
		 * Verify UI data
		 */
		String headerLoc = gp.getPropertyValue("pf.ph.table", "Section2aItemAHedgeFundQs27Qs28");
		pf = new PFReadOnlyPageWidget(headerLoc);
		for(int i=0; i<resultSet.size(); i++){
			switch(resultSet.get(i).get("INVMT_RGN_NM")){
			case "AFRICA":{
				pf.verifyTdDataWithUI("AFRICA", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "Africa");
				break;
			}
			case "ASIA AND PACIFIC (OTHER THAN THE MIDDLE EAST)":{
				pf.verifyTdDataWithUI("ASIA AND PACIFIC (OTHER THAN THE MIDDLE EAST)", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "Asia and Pacific (other than the Middle East)");
				break;
			}
			case "EUROPE (EEA)":{
				pf.verifyTdDataWithUI("EUROPE (EEA)", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "Europe (EEA)");
				break;
			}
			case "MIDDLE EAST":{
				pf.verifyTdDataWithUI("MIDDLE EAST", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "Middle East");
				break;
			}
			case "NORTH AMERICA":{
				pf.verifyTdDataWithUI("NORTH AMERICA", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "North America");
				break;
			}
			case "EUROPE (OTHER THAN EEA)":{
				pf.verifyTdDataWithUI("EUROPE (OTHER THAN EEA)", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "Europe (other than EEA)");
				break;
			}
			case "SOUTH AMERICA":{
				pf.verifyTdDataWithUI("SOUTH AMERICA", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "South America");
				break;
			}
			case "SUPRANATIONAL":{
				pf.verifyTdDataWithUI("SUPRANATIONAL", resultSet.get(i).get("INVMT_RGN_NAV_PCT").toString(), "pf.ph.text.following.td", "Supranational");
				break;
			}
			default:{
				throw new Exception("Invalid region name is given.");	
				}
			}
		
			
			/*
			 * Get database data-Country
			 */
			Map<String, Object> sqlParameters2 = new HashMap<String, Object>();
			sqlParameters2.put("FLNG_PK", flng_pk);
			SqlExecutor se2 = new SqlExecutor("main", System.getProperty("target"));
			List<Map<String, String>> resultSet1 = se2.executeForStrings("pf.ph.q28.country",sqlParameters);
		
			/*
			 * Verify UI data
			 */
			for(int j=0; j<resultSet1.size(); j++){
				switch(resultSet1.get(j).get("INVMT_CNTRY_NM")){
				case "BRAZIL":{
					pf.verifyTdDataWithUI("BRAZIL", resultSet1.get(j).get("CNTRY_NAV_PCT").toString(), "pf.ph.text.following.td", "Brazil");
					break;
				}
				case "CHINA (INCLUDING HONG KONG)":{
					pf.verifyTdDataWithUI("CHINA (INCLUDING HONG KONG)", resultSet1.get(j).get("CNTRY_NAV_PCT").toString(), "pf.ph.text.following.td", "China (including Hong Kong)");
					break;
				}
				case "INDIA":{
					pf.verifyTdDataWithUI("INDIA", resultSet1.get(j).get("CNTRY_NAV_PCT").toString(), "pf.ph.text.following.td", "India");
					break;
				}
				case "JAPAN":{
					pf.verifyTdDataWithUI("JAPAN", resultSet1.get(j).get("CNTRY_NAV_PCT").toString(), "pf.ph.text.following.td", "Japan");
					break;
				}
				case "RUSSIA":{
					pf.verifyTdDataWithUI("RUSSIA", resultSet1.get(j).get("CNTRY_NAV_PCT").toString(), "pf.ph.text.following.td", "Russia");
					break;
				}
				case "UNITED STATES":{
					pf.verifyTdDataWithUI("UNITED STATES", resultSet1.get(j).get("CNTRY_NAV_PCT").toString(), "pf.ph.text.following.td", "United States");
					break;
				}
				default:{
					throw new Exception("Invalid county name is given.");	
					}
				}
			
			}
		}
	}	

	
	
	
	
}
