package org.finra.automation.pfrd;

import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.ViewIndividual;
import org.finra.automation.crd_automation.ui.widget.form.FormMainContent;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.junit.Rule;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by mccabej on 3/9/2016.
 */
public class PF_OrgSearch {

    @Rule
    public BaseTest base= new BaseTest();
    Login pfrd = new Login();
    private FormNavigation nav = new FormNavigation();
    private ViewIndividual vi = new ViewIndividual();
    private static final GUIProperties GUI = new GUIProperties("crd/gui.properties");

    @Test
    public void PerformOrgSearch() throws Exception {

        BaseTest.getLogger().info("Starting PFRD Org Search Test - Login");
        pfrd.crdLogin("crd.application.url","ARTFINRAJR");

        BaseTest.getLogger().info("Starting PFRD Org Search Test - SiteMap link");
        nav.goToPFRDPage("View Organization", "Organization Search - Filing History");
        FormMainContent fmc = new FormMainContent();

        BaseTest.getLogger().info("Starting PFRD Org Search Test - Search Param Page");
        fmc.inputText("txtCRDNo", "105377");
        fmc.clickButton("Search", "1");

        List<Map<String, String>> uiData = new ArrayList<Map<String, String>>();
        List<Map<String, String>> matchFiling = new ArrayList<Map<String, String>>();
        uiData = vi.getTableDataInfo("grdHistList", "1");
        for (Map m : uiData) {
        	if (m.containsValue("650687")) {
        		matchFiling.add(m);
        	}
        }
        //use old way instead of cool lambda to avoid maven install error
        //matchFiling = uiData.stream().filter(f -> f.containsValue("650687")).collect(Collectors.toList());
        org.junit.Assert.assertTrue("PFRD Filing History did not return for FINRA user", matchFiling.size() == 1 );

    }

}
