package org.finra.automation.vii;

import java.util.HashMap;
import java.util.Map;
import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.ExtWebDriver;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.jtaf.ewd.session.SessionManager;
import org.junit.Rule;
import org.junit.Test;

public class IndividualSearch {
	private final static GUIProperties GP = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private LeftNavigation leftNav = new LeftNavigation();
		
	@Rule
	public BaseTest basetest=new BaseTest();
	
	@Test
	public void searchIndvlByCRDNo() throws Exception {
		//FormMainContent fmc = new FormMainContent();
		//BaseTest.getLogger().info("***** Individual Search by Individual CRD#***********");
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to VII
		 */
		nav.goToIndividualPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Short Text", "2580477");
		CRDSearch crdSearch = new CRDSearch("CRD Individual Search");
		crdSearch.doSearch(searchCriteria);
		
		//Click Other Business in Left navigation
		leftNav.selectItem("Other Business");
			
					
	}
	
	@Test
	public void searchIndvlBySSN() throws Exception {
		
		//BaseTest.getLogger().info("***** Individual Search by Individual CRD#***********");
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to VII
		 */
		nav.goToIndividualPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("SSN", "114-55-7317");
		CRDSearch crdSearch = new CRDSearch("Advanced Search");
		crdSearch.doSearch(searchCriteria);
		
		//Click Other Business in Left Navigation
		leftNav.selectItem("Other Business");
			
					
	}
	
}
