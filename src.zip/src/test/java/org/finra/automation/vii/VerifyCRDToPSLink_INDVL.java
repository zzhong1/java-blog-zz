package org.finra.automation.vii;

import java.util.HashMap;
import java.util.Map;

import org.finra.automation.crd.junit.pageobjectmodel.CRDSearch;
import org.finra.automation.crd.junit.pageobjectmodel.CRDToPSLink;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd_automation.ui.widget.LeftNavigation;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.junit.Rule;
import org.junit.Test;

public class VerifyCRDToPSLink_INDVL {
	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	private Login crd=new Login();
	private FormNavigation nav = new FormNavigation();
	private LeftNavigation leftNav = new LeftNavigation();
	
	@Rule
	public BaseTest basetest=new BaseTest();
	
	@Test
	public void verifyCRDToAAOLink() throws Exception {
		BaseTest.getLogger().info("***** Starting Test for CRD To FDA for INDVL-2580477");
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToIndividualPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Short Text", "2580477");
		CRDSearch crdSearch = new CRDSearch("CRD Individual Search");
		crdSearch.doSearch(searchCriteria);
		
		leftNav.selectItem("Disclosures");	
		
		CRDToPSLink lnk = new CRDToPSLink();
		lnk.goCRDToPSLink("1251263", "00-04055");		
	}
	
	@Test
	public void verifyCRDToFDALink() throws Exception {
		BaseTest.getLogger().info("***** Starting Test for CRD To FDA for INDVL-5184808");
		/*
		 * Login CRD as FINRA user
		 */
		crd.crdLogin("crd.application.url","ARTFINRAJR");
		/*
		 * Use FormNavigation class to go to historical U4 filing search page
		 */
		nav.goToIndividualPage();
		/*
		 * Prepare search criteria and search it
		 */
		Map<String, String> searchCriteria = new HashMap<String, String>();
		searchCriteria.put("Short Text", "5184808");
		CRDSearch crdSearch = new CRDSearch("CRD Individual Search");
		crdSearch.doSearch(searchCriteria);
		
		leftNav.selectItem("Disclosures");	
		
		CRDToPSLink lnk = new CRDToPSLink();
		lnk.goCRDToPSLink("1463763", "2007010685801");
	}
}
