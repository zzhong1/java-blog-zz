package org.finra.automation.firmgateway.fprd;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;























import org.junit.*;
import org.apache.commons.lang.RandomStringUtils;
import org.finra.automation.crd.junit.pageobjectmodel.FormNavigation;
import org.finra.automation.crd.junit.pageobjectmodel.SuperAccount;
import org.finra.automation.crd.junit.ui.widgets.ReadOnlyPageWidget;
import org.finra.automation.crd_automation.common.CRDColumnHeaderTable;
import org.finra.automation.crd_automation.common.CRDExtendedTable;
import org.finra.automation.crd_automation.ui.widget.ViewIndividual;
import org.finra.automation.junit.base.BaseTest;
import org.finra.automation.junit.base.Login;
import org.finra.jtaf.ewd.properties.GUIProperties;
import org.finra.jtaf.ewd.widget.element.html.Button;
import org.finra.test.tools.db.SqlExecutor;
import org.finra.test.tools.db.exceptions.DatabaseException;
import org.junit.Rule;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import qc.automation.framework.properties.PropertiesReader;

//import qc.automation.framework.properties.PropertiesReader;


public class FirmGateWay_FPRD_Firm_User extends BaseTest {
	final static GUIProperties gp = new GUIProperties("crd/gui.properties");
	WebDriver driver;

	@Rule
	public BaseTest basetest=new BaseTest();
	
	@Test
	public void verifyOrgInfo() throws Throwable{
		String org_pk = fprdFirmSetUp();
		nav.goToFirmGatewayFPRD();
		/*String ui = getDataFromUI("fprd.voi.text","CIK");
		Tuple sqlParams = new Tuple("ORG_PK", org_pk);
		String db = getDataFromDB("fprd.org.info","SEC_CIK_NB",sqlParams);
		Assert.assertEquals(ui,db);*/
		
		//verify org info
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", org_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("fprd.org.info",sqlParameters);
		ReadOnlyPageWidget rp = new ReadOnlyPageWidget("/");
		rp.verifyDataWithUI(resultSet, "ORG_PK", "fprd.voi.text", "Organization ID Number:","1");
		//rp.verifyDataWithUI(resultSet, "SEC_NB", "fprd.voi.text", "SEC File Number:");
		rp.verifyDataWithUI(resultSet, "SEC_CIK_NB", "fprd.voi.text", "CIK","1");
		rp.verifyDataWithUI(resultSet, "ORG_NM", "fprd.voi.text", "Organization/Agency Name:","1");
		
		//Verify main contact info
		Map<String, Object> sqlParameters1 = new HashMap<String, Object>();
		sqlParameters1.put("ORG_PK", org_pk);
		sqlParameters1.put("CONTRACT_TYPE", "MAIN");
		SqlExecutor se1 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet1 = se1.executeForStrings("fprd.org.contract",sqlParameters1);
		rp.verifyDataWithUI(resultSet1, "PHONE_NB", "fprd.voi.text", "Phone Number:", "1");
		rp.verifyDataWithUI(resultSet1, "EMAIL", "fprd.voi.text", "Email:", "1");

		//verify financial contact info
		Map<String, Object> sqlParameters2 = new HashMap<String, Object>();
		sqlParameters2.put("ORG_PK", org_pk);
		sqlParameters2.put("CONTRACT_TYPE", "FNNC");
		SqlExecutor se2 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet2 = se2.executeForStrings("fprd.org.contract",sqlParameters2);
		rp.verifyDataWithUI(resultSet2, "PHONE_NB", "fprd.voi.text", "Phone Number:", "2");
		rp.verifyDataWithUI(resultSet2, "EMAIL", "fprd.voi.text", "Email:", "2");
		rp.verifyDataWithUI(resultSet2, "CONTRACT_NM", "fprd.voi.text", "Contact Name: ", "1");
		rp.verifyDataWithUI(resultSet2, "TITLE_TX", "fprd.voi.text", "Contact Title:", "1");

		 
		//verify registration history table
		Map<String, Object> sqlParameters3 = new HashMap<String, Object>();
		sqlParameters3.put("ORG_PK", org_pk);
		SqlExecutor se3 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet3 = se3.executeForStrings("fprd.org.reg.history",sqlParameters3);
		CRDExtendedTable crdExtendedTable = new CRDExtendedTable(gp.getPropertyValue("fprd.table", "FPContent_grdRegistrationHistory")); 
		List<Map<String, String>> uiInfo = crdExtendedTable.getTableDataInMap();
		org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy policy = org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy.valueOf("AnyOrder");
		org.finra.test.tools.commons.comparator.Assert.assertCompare(uiInfo, resultSet3, policy, "comparisonResult");

		//Verify associated indvl
		CRDExtendedTable crdExtendedTable1 = new CRDExtendedTable(gp.getPropertyValue("fprd.table", "FPContent_grdFingerprintedIndvls")); 
		int UICount = crdExtendedTable1.getTableRowCount();
		Map<String, Object> sqlParameters4 = new HashMap<String, Object>();
		sqlParameters4.put("ORG_PK", org_pk);
		SqlExecutor se4 = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet4 = se4.executeForStrings("fprd.org.reg.associated.indvl",sqlParameters3);
		int DBCount = resultSet4.size();
		Assert.assertEquals(UICount,DBCount);
		
		//Verify show ssn
		WebElement show = driver.findElement(By.xpath(gp.getPropertyValue("fprd.button", "View SSN")));
			show.click();
		
		Assert.assertTrue(driver.getPageSource().contains("Hide SSN"));
		
		//Verify Hide SSN
		WebElement hide = driver.findElement(By.xpath(gp.getPropertyValue("fprd.button", "Hide SSN")));
			hide.click();
		
		Assert.assertTrue(driver.getPageSource().contains("View SSN"));
		
		//verify show status
		WebElement status = driver.findElement(By.xpath(gp.getPropertyValue("fprd.button", "Show Status")));			
		status.click();
		Assert.assertTrue(driver.getPageSource().contains("Fingerprint CHRI Terms and Conditions"));
		
		//verify accept condition
		WebElement accept = driver.findElement(By.xpath(gp.getPropertyValue("fprd.button", "Accept")));			
			accept.click();
			
		
		

	}
	
	

	private String getDataFromDB(String sql, String targetCloumn, Tuple... sqlParams) throws DatabaseException {
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));

		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		for (Tuple tp : sqlParams) {
			sqlParameters.put(tp.key, tp.value);
		}

		
		List<Map<String, String>> resultSet = se.executeForStrings(sql,sqlParameters);
		System.out.println( resultSet.get(0).get("SEC_CIK_NB"));
		return resultSet.get(0).get(targetCloumn);
		
	}
	private String getDataFromUI(String xpath, String... xpathParams) throws Exception {
		WebElement e = driver.findElement(By.xpath(gp.getPropertyValue(xpath, xpathParams)));
		return e.getText();
		
	}
	@Test
	public  void verifyFingerPrint() throws Throwable{
		String org_pk = fprdFirmSetUp();
		nav.goToFirmGatewayFPRD_fpCard();
		Thread.sleep(1000);
		
		//Verify Sort
		WebElement sortByCRD = driver.findElement(By.linkText("CRD Number"));			
		sortByCRD.click();
		
		Thread.sleep(1000);
		WebElement status = driver.findElement(By.xpath(gp.getPropertyValue("fprd.button", "Show Status")));			
		status.click();
		Assert.assertTrue(driver.getPageSource().contains("Fingerprint CHRI Terms and Conditions"));
		

		
		//verify accept condition
		WebElement accept = driver.findElement(By.xpath(gp.getPropertyValue("fprd.button", "Accept")));			
		Thread.sleep(1000);
		accept.click();
		
		
		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		sqlParameters.put("ORG_PK", org_pk);
		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));
		List<Map<String, String>> resultSet = se.executeForStrings("fprd.org.reg.fpCard",sqlParameters);
		CRDExtendedTable crdExtendedTable = new CRDExtendedTable(gp.getPropertyValue("fprd.table", "FPContent_grdFingerprintCards")); 
		List<Map<String, String>> uiInfo = crdExtendedTable.getTableDataInMap();
		org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy policy = org.finra.test.tools.commons.comparator.ListMapComparatorFactory.Policy.valueOf("AnyOrder");
		for (Map<String, String> m : resultSet) {
			for (String key : m.keySet()) {
				String value = m.get(key);
				m.put( key,  value.trim());
				
			}
		}
		System.out.println(uiInfo.toString());
		System.err.println(resultSet.toString());
		System.out.println(resultSet.get(1).get("Name"));
		org.finra.test.tools.commons.comparator.Assert.assertCompare(uiInfo, resultSet, policy, "comparisonResult");
		
	}
	@Test
	public void verifySDEvents() throws Throwable{
		String org_pk = fprdFirmSetUp();
		nav.goToFirmGatewayFPRD_SDEvents();
		Thread.sleep(1000);
		List<WebElement> list = driver.findElements(By.xpath(gp.getPropertyValue("fprd.input.add")));
		for (WebElement e : list) {
			String detialsText = RandomStringUtils.randomAlphabetic(10);
			String titleText = RandomStringUtils.randomAlphabetic(10);
			e.click();
			Thread.sleep(3000);
			WebElement date = driver.findElement(By.id("ctl00_ctl00_cphMainContent_FPContent_ucOrgSDIndividualEventItem_txtSDIndividualItemEventDate"));
			date.sendKeys(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
			
			WebElement detials = driver.findElement(By.id("ctl00_ctl00_cphMainContent_FPContent_ucOrgSDIndividualEventItem_txtEventDetails"));
			detials.sendKeys(detialsText);
			
			WebElement title = driver.findElement(By.id("ctl00_ctl00_cphMainContent_FPContent_ucOrgSDIndividualEventItem_txtRoleText"));
			title.sendKeys(titleText);
			
/*			WebElement save = driver.findElement(By.xpath(gp.getPropertyValue("fprd.button", "Save")));
*/			WebElement save = driver.findElement(By.id("ctl00_ctl00_cphMainContent_FPContent_ucOrgSDIndividualEventItem_btnSave"));
			save.click();
			Thread.sleep(2000);
			Assert.assertTrue(driver.getPageSource().contains(detialsText));
			Assert.assertTrue(driver.getPageSource().contains(titleText));

		}
	}
	
	private String fprdFirmSetUp() throws Throwable{
		
/*		SqlExecutor se = new SqlExecutor("main", System.getProperty("target"));

		Map<String, Object> sqlParameters = new HashMap<String, Object>();
		List<Map<String, String>> resultSet = se.executeForStrings("fg.fprd.org",sqlParameters);
		String org_pk = resultSet.get(0).get("ORG_PK");
		SuperAccount account= new SuperAccount("artfinrasu",PropertiesReader.getString("ews.url"));
		account.cloneAccount(org_pk, "fp249");
		System.out.println("ORG_PK = " + org_pk);
		crd.crdLogin("fg.application.url",account.getNewAccountID(),account.getNewAccountPass(),account.getNewAccountAnswer());*/
		
		crd.crdLogin("fg.application.url","OmrpCzELBG");

		ReadOnlyPageWidget rp = new ReadOnlyPageWidget("/");
		driver = rp.getGUIDriver().getWrappedDriver();
		//return org_pk;
		return "203594";
	}
	public class Tuple { 
		  public final String key; 
		  public final String value; 
		  public Tuple(String key, String value) { 
		    this.key = key; 
		    this.value = value; 
		  } 
		}
	
}
 
